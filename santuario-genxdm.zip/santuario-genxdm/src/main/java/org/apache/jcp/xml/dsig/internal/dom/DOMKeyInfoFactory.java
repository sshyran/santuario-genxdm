/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMKeyInfoFactory.java 1333869 2012-05-04 10:42:44Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import java.math.BigInteger;
import java.security.KeyException;
import java.security.PublicKey;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.util.List;
import javax.xml.crypto.*;
import javax.xml.crypto.dom.DOMCryptoContext;
import javax.xml.crypto.dsig.keyinfo.*;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.NodeKind;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;

/**
 * DOM-based implementation of KeyInfoFactory.
 *
 * @author Sean Mullan
 */
public final class DOMKeyInfoFactory extends KeyInfoFactory {

    public DOMKeyInfoFactory() { }

    @SuppressWarnings("rawtypes")
    public KeyInfo newKeyInfo(List content) {
        return newKeyInfo(content, null);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public KeyInfo newKeyInfo(List content, String id) {
        return new DOMKeyInfo(content, id);
    }

    public KeyName newKeyName(String name) {
        return new DOMKeyName(name);
    }

    public KeyValue newKeyValue(PublicKey key)  throws KeyException {
        String algorithm = key.getAlgorithm();
        if (algorithm.equals("DSA")) {
            return new DOMKeyValue.DSA((DSAPublicKey) key);
        } else if (algorithm.equals("RSA")) {
            return new DOMKeyValue.RSA((RSAPublicKey) key);
        } else if (algorithm.equals("EC")) {
            return new DOMKeyValue.EC((ECPublicKey) key);
        } else {
            throw new KeyException("unsupported key algorithm: " + algorithm);
        }
    }

    public PGPData newPGPData(byte[] keyId) {
        return newPGPData(keyId, null, null);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public PGPData newPGPData(byte[] keyId, byte[] keyPacket, List other) {
        return new DOMPGPData(keyId, keyPacket, other);
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public PGPData newPGPData(byte[] keyPacket, List other) {
        return new DOMPGPData(keyPacket, other);
    }

    public RetrievalMethod newRetrievalMethod(String uri) {
        return newRetrievalMethod(uri, null, null);
    }

    @SuppressWarnings("rawtypes")
    public RetrievalMethod newRetrievalMethod(String uri, String type,
        List transforms) {
        if (uri == null) {
            throw new NullPointerException("uri must not be null");
        }
        // TODO - this is weird - the retrieval method is being instantiated without
        // reference to any nodes, so why should the type of the underlying tree matter?
        return new DOMRetrievalMethod(uri, type, transforms);
    }

    @SuppressWarnings("rawtypes")
    public X509Data newX509Data(List content) {
        return new DOMX509Data(content);
    }

    public X509IssuerSerial newX509IssuerSerial(String issuerName, 
        BigInteger serialNumber) {
        return new DOMX509IssuerSerial(issuerName, serialNumber);
    }

    public boolean isFeatureSupported(String feature) {
        if (feature == null) {
            throw new NullPointerException();
        } else {
            return false;
        }
    }

    public URIDereferencer getURIDereferencer() {
        return DOMURIDereferencer.INSTANCE;
    }

    public KeyInfo unmarshalKeyInfo(XMLStructure xmlStructure) 
        throws MarshalException {
        if (xmlStructure == null || !(xmlStructure instanceof javax.xml.crypto.dom.DOMStructure)) {
            throw new ClassCastException("xmlStructure must be of type DOMStructure");
        }
        return internalUnmarshalKeyInfo(xmlStructure);
    }

	private <N> KeyInfo internalUnmarshalKeyInfo(XMLStructure xmlStructure) throws MarshalException {
	    
	    DocumentHandlerFactory<N> docFactory = GenXDMStructure.getDocumentHandlerFactory(xmlStructure);
		MutableModel<N> model = GenXDMStructure.getModel(xmlStructure);
        N node = GenXDMStructure.getNode(model, xmlStructure);
        // Official project calls "normalize", but with the GenXDM API, that normalize call should
        // be unnecessary.
        //node.normalize();

        N element = null;
        if (model.getNodeKind(node) == NodeKind.DOCUMENT) {
            element = model.getFirstChildElement(node);
        } else if (model.getNodeKind(node) == NodeKind.ELEMENT) {
            element = node;
        } else {
            throw new MarshalException
                ("xmlStructure does not contain a proper Node");
        }

        // check tag
        String tag = model.getLocalName(element);
        if (tag == null) {
            throw new MarshalException("Document implementation must " +
                "support DOM Level 2 and be namespace aware");
        }
        if (tag.equals("KeyInfo")) {
            return new DOMKeyInfo(docFactory, model, element, new UnmarshalContext(), getProvider());
        } else {
            throw new MarshalException("invalid KeyInfo tag: " + tag);
        }
    }
    
    private static class UnmarshalContext extends DOMCryptoContext {
        UnmarshalContext() {}
    }

}
