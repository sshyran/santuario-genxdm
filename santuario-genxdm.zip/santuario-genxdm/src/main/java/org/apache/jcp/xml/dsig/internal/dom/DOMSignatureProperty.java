/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMSignatureProperty.java 1333415 2012-05-03 12:03:51Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;

import java.util.*;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.mutable.MutableModel;

/**
 * DOM-based implementation of SignatureProperty.
 *
 * @author Sean Mullan
 */
public final class DOMSignatureProperty extends BaseStructure
    implements SignatureProperty {
 
    private final String id;
    private final String target;
    private final List<XMLStructure> content;

    /**
     * Creates a <code>SignatureProperty</code> from the specified parameters.
     *
     * @param content a list of one or more {@link XMLStructure}s. The list
     *    is defensively copied to protect against subsequent modification.
     * @param target the target URI
     * @param id the Id (may be <code>null</code>)
     * @return a <code>SignatureProperty</code>
     * @throws ClassCastException if <code>content</code> contains any
     *    entries that are not of type {@link XMLStructure}
     * @throws IllegalArgumentException if <code>content</code> is empty
     * @throws NullPointerException if <code>content</code> or 
     *    <code>target</code> is <code>null</code>
     */
    public DOMSignatureProperty(List<? extends XMLStructure> content,
                                String target, String id)
    {
        if (target == null) {
            throw new NullPointerException("target cannot be null");
        } else if (content == null) {
            throw new NullPointerException("content cannot be null");
        } else if (content.isEmpty()) {
            throw new IllegalArgumentException("content cannot be empty");
        } else {
            this.content = Collections.unmodifiableList(
                new ArrayList<XMLStructure>(content));
            for (int i = 0, size = this.content.size(); i < size; i++) {
                if (!(this.content.get(i) instanceof XMLStructure)) {
                    throw new ClassCastException
                        ("content["+i+"] is not a valid type");
                }
            }
        }
        this.target = target;
        this.id = id;
    }

    /**
     * Creates a <code>DOMSignatureProperty</code> from an element.
     *
     * @param propElem a SignatureProperty element
     */
    public <N> DOMSignatureProperty(MutableModel<N> model, N propElem)
        throws MarshalException
    {
        // unmarshal attributes
        target = DOMUtils.getAttributeValue(model, propElem, "Target");
        if (target == null) {
            throw new MarshalException("target cannot be null");
        }
        id = DOMUtils.getIdAttributeValue(model, propElem, "Id");

        List<XMLStructure> content = new ArrayList<XMLStructure>();

        for (N child : model.getChildAxis(propElem)) {
            content.add(new GenXDMStructure<N>(model, child));
        }
        if (content.isEmpty()) {
            throw new MarshalException("content cannot be empty");
        } else {
            this.content = Collections.unmodifiableList(content);
        }
    }

    public List<XMLStructure> getContent() {
        return content;
    }

    public String getId() {
        return id;
    }

    public String getTarget() {
        return target;
    }

    public static void marshal(XmlWriter<?> xwriter, SignatureProperty sigProp, String dsPrefix, XMLCryptoContext context)
        throws MarshalException
    {
        xwriter.writeStartElement(dsPrefix, "SignatureProperty", XMLSignature.XMLNS);

        // set attributes
        xwriter.writeIdAttribute("", "", "Id", sigProp.getId());
        xwriter.writeAttribute("", "", "Target", sigProp.getTarget());

        // create and append any elements and mixed content
        List<XMLStructure> content = getContent(sigProp);
        for (XMLStructure property : content) {
            Marshaller.marshal(xwriter, property, dsPrefix, context);
        }
        
        xwriter.writeEndElement(); // "SignatureProperty"
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (!(o instanceof SignatureProperty)) {
            return false;
        }
        SignatureProperty osp = (SignatureProperty)o;

        boolean idsEqual = (id == null ? osp.getId() == null
                                       : id.equals(osp.getId()));

        @SuppressWarnings("unchecked")
        List<XMLStructure> ospContent = osp.getContent();
        return (equalsContent(ospContent) &&
                target.equals(osp.getTarget()) && idsEqual);
    }
    
    @Override
    public int hashCode() {
        assert false : "hashCode not designed";
        return 42; // any arbitrary constant will do 
    }

    @SuppressWarnings("unchecked")
	private static List<XMLStructure> getContent(SignatureProperty prop) {
    	return prop.getContent();
    }
    private boolean equalsContent(List<XMLStructure> otherContent) {
        return DOMXMLObject.equalsContent(content, otherContent);
    }
}