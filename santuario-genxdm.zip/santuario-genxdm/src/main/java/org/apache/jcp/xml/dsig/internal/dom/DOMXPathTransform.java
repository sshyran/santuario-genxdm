/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMXPathTransform.java 1203789 2011-11-18 18:46:07Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.crypto.dsig.spec.XPathFilterParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.genxdm.mutable.NodeFactory;
import org.genxdm.names.NamespaceBinding;

/**
 * DOM-based implementation of XPath Filtering Transform.
 * (Uses Apache XML-Sec Transform implementation)
 *
 * @author Sean Mullan
 */
public final class DOMXPathTransform<N> extends ApacheTransform<N> {
 
    public void init(TransformParameterSpec params)
        throws InvalidAlgorithmParameterException
    {
        if (params == null) {
            throw new InvalidAlgorithmParameterException("params are required");
        } else if (!(params instanceof XPathFilterParameterSpec)) {
            throw new InvalidAlgorithmParameterException
                ("params must be of type XPathFilterParameterSpec");
        }
        this.params = params;
    }

    public void init(XMLStructure parent, XMLCryptoContext context)
        throws InvalidAlgorithmParameterException
    {
        super.init(parent, context);
        unmarshalParams(model.getFirstChildElement(transformElem));
    }

    private void unmarshalParams(N paramsElem) {
        String xPath = BaseStructure.textOfNode(model, paramsElem);
        // create a Map of namespace prefixes
        Map<String, String> namespaceMap = new HashMap<String, String>();
        for (NamespaceBinding nsDecl : model.getNamespaceBindings(paramsElem)) {
        	namespaceMap.put( nsDecl.getPrefix(), nsDecl.getNamespaceURI());
        }
        this.params = new XPathFilterParameterSpec(xPath, namespaceMap);
    }

    @SuppressWarnings("unchecked")
	private static Map<String, String> getParamSpecNamespaceMap(XPathFilterParameterSpec paramSpec) {
    	return paramSpec.getNamespaceMap();
    }

    public void marshalParams(XMLStructure parent, XMLCryptoContext context)
        throws MarshalException
    {
        super.marshalParams(parent, context);
        XPathFilterParameterSpec xp = 
            (XPathFilterParameterSpec)getParameterSpec();
        NodeFactory<N> factory = model.getFactory(transformElem);
        N xpathElem = factory.createElement(XMLSignature.XMLNS, "XPath",
            DOMUtils.getSignaturePrefix(context));
        model.appendChild(transformElem, xpathElem);
        model.appendChild(xpathElem, factory.createText(xp.getXPath()));

        // add namespace attributes, if necessary
        Set<Map.Entry<String, String>> entries =
            getParamSpecNamespaceMap(xp).entrySet();
        for (Map.Entry<String, String> entry : entries) {
            model.insertNamespace(xpathElem, entry.getKey(), entry.getValue());
        }            
    }
}
