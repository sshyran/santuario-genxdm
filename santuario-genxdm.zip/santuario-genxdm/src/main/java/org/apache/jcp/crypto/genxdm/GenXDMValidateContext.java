package org.apache.jcp.crypto.genxdm;

import java.security.Key;

import javax.xml.crypto.KeySelector;
import javax.xml.crypto.dsig.XMLValidateContext;
import javax.xml.crypto.dsig.dom.DOMValidateContext;

import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;

/**
 * A GenXDM counterpart to {@link DOMValidateContext}
 */
public class GenXDMValidateContext<N> extends GenXDMCryptoContext<N> implements XMLValidateContext {

    @SuppressWarnings("unchecked")
    public static <NT> NT getNode(XMLValidateContext xvCtx) {
        if (xvCtx instanceof DOMValidateContext) {
            return (NT) ( (DOMValidateContext) xvCtx).getNode();
        }
        else if (xvCtx instanceof GenXDMValidateContext) {
            return ( (GenXDMValidateContext<NT>) xvCtx).getNode();
        }
        
        throw new ClassCastException("Unrecognized subclass of XMLValidateContext. Must be either a DOMValidateContext or a GenXDMValidateContext");
    }

	private N node;
	
    public GenXDMValidateContext(Key validatingKey, DocumentHandlerFactory<N> docFactory, MutableModel<N> model, N node) {

        super(docFactory, model);
        this.node = node;
        setKeySelector(KeySelector.singletonKeySelector(validatingKey));
    }
    
	public GenXDMValidateContext(KeySelector ks, DocumentHandlerFactory<N> docFactory, MutableModel<N> model, N node) {

	    super(docFactory, model);
	    this.node = node;
	    setKeySelector(ks);
	}
	
    public void setNode(N node) {
        if (node == null) {
            throw new NullPointerException();
        }
        this.node = node;
    }
    
	public N getNode() {
	    return node;
	}
}
