package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.XMLStructure;

import org.genxdm.Model;

/**
 * Implements an abstract base class for all classes of XMLStructure
 */
public abstract class BaseStructure implements XMLStructure {

    /**
     * Since the behavior of {@link Model#getStringValue(Object)} returns the value
     * of all descendant text nodes of an element, whereas we just want the immediate children.
     * 
     * @param <N>
     * @param model
     * @param node
     * @return
     */
    public static <N> String textOfNode(Model<N> model, N node) {
    	return model.getStringValue(model.getFirstChild(node));
    }

    public final boolean isFeatureSupported(String feature) {
        if (feature == null) {
            throw new NullPointerException();
        } else {
            return false;
        }
    }

}
