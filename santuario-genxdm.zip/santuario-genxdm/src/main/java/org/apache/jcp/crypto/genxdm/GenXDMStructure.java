package org.apache.jcp.crypto.genxdm;

import javax.xml.crypto.XMLStructure;

import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;

/**
 * Corresponds to a {@link javax.xml.crypto.dom.DOMStructure}, but for GenXDM structure
 * references to XML.
 *
 * @param <N> The type of node.
 */
public class GenXDMStructure<N> implements XMLStructure {

    private final N node;
    private final MutableModel<N> model;
    private final DocumentHandlerFactory<N> factory;
    
    /**
     * Get the "model" from an XML Structure, regardless of its heritage.
     * 
     * @param <N>
     * @param struct the {@link XMLStructure} from which to get the model.
     * @return
     */
	@SuppressWarnings("unchecked")
	public static <N> MutableModel<N> getModel(XMLStructure struct) {
		
		if (struct instanceof javax.xml.crypto.dom.DOMStructure) {
			return (MutableModel<N>) XmlContext.getDomModel();
		}
		else if (struct instanceof GenXDMStructure<?>) {
			return (MutableModel<N>) ( (GenXDMStructure<?>) struct).getModel();
		}
		else {
			throw new IllegalArgumentException("Unrecognized structure of type " + struct.getClass().getName());
		}
	}
	
    /**
     * Get the "model" from an XML Structure, regardless of its heritage.
     * 
     * @param <N>
     * @param struct the {@link XMLStructure} from which to get the model.
     * @return
     */
	@SuppressWarnings("unchecked")
	public static <N> DocumentHandlerFactory<N> getDocumentHandlerFactory(XMLStructure struct) {
		
		if (struct instanceof javax.xml.crypto.dom.DOMStructure) {
			return (DocumentHandlerFactory<N>) XmlContext.getContext().docHandlerFactory;
		}
		else if (struct instanceof GenXDMStructure<?>) {
			return (DocumentHandlerFactory<N>) ( (GenXDMStructure<?>) struct).getDocumentHandlerFactory();
		}
		else {
			throw new IllegalArgumentException("Unrecognized structure of type " + struct.getClass().getName());
		}
	}
	
	/**
	 * Get the node from an {@link XMLStructure}
	 * 
	 * @param <N> The type of node.
	 * @param model    Used to eliminate warnings, triggered by the need to do an explicit cast.
	 * @param struct	The structure from which to derive the node.
	 * @return	The node.
	 */
	@SuppressWarnings("unchecked")
	public static <N> N getNode(MutableModel<N> model, XMLStructure struct) {
		if (struct instanceof javax.xml.crypto.dom.DOMStructure) {
			return (N) ( (javax.xml.crypto.dom.DOMStructure) struct).getNode();
		}
		else if (struct instanceof GenXDMStructure<?>) {
			return (N) ( (GenXDMStructure<?>) struct).getNode();
		}
		else {
			throw new IllegalArgumentException("Unrecognized structure of type " + struct.getClass().getName());
		}
	}
	
    /**
     * Creates a <code>GenXDMStructure</code> containing the specified node and its model.
     *
     * @param node the node
     * @throws NullPointerException if <code>node</code> is <code>null</code>
     */
    public GenXDMStructure(DocumentHandlerFactory<N> factory, MutableModel<N> model, N node) {
    	this.model = model;
    	this.factory = factory;
        if (node == null) {
        	throw new NullPointerException("node cannot be null");
        }
        this.node = node;
    }

    /**
     * Creates a <code>GenXDMStructure</code> containing the specified node and its model.
     *
     * @param node the node
     * @throws NullPointerException if <code>node</code> is <code>null</code>
     */
    public GenXDMStructure(MutableModel<N> model, N node) {
    	this(null, model, node);
    }

    /**
     * Returns the node contained in this <code>DOMStructure</code>.
     *
     * @return the node
     */
    public N getNode() {
    	return node;
    }
    
    public MutableModel<N> getModel() {
    	return model;
    }

    public DocumentHandlerFactory<N> getDocumentHandlerFactory() {
    	return factory;
    }
    
    
     public boolean isFeatureSupported(String feature) {
        if (feature == null) {
            throw new NullPointerException();
        } else {
            return false;
        }
	}

    @Override
    /**
     * @see {@link org.apache.jcp.xml.dsig.internal.dom.DOMUtils#nodesEqual}, and how that is used.
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (! (obj instanceof GenXDMStructure) ) {
            return false;
        }
        
        // Technically, we don't know if this is of type "N", but the method we're calling
        // is written for two types, so it doesn't matter.
        @SuppressWarnings("unchecked")
        GenXDMStructure<N> other = (GenXDMStructure<N>) obj;
        return internalEquals(model, node, other.model, other.node);

    }

    private static <N, ON> boolean internalEquals(Model<N> model, N node, Model<ON> otherModel, ON otherNode) {
        if (!model.equals(otherModel)) {
            return false;
        }
        
        // This isn't precisely accurate, but it is what the original DOMUtils method did/does.
        if (model.getNodeKind(node) != otherModel.getNodeKind(otherNode)) {
            return false;
        }
        
        switch (model.getNodeKind(node)) {
        
        case ATTRIBUTE:
        case NAMESPACE:
            return equalName(model, node, otherModel, otherNode)
            && equalValue(model, node, otherModel, otherNode);
        case COMMENT:
        case TEXT:
        case PROCESSING_INSTRUCTION:
            return equalValue(model, node, otherModel, otherNode);
        case ELEMENT:
            return equalName(model, node, otherModel, otherNode);
        case DOCUMENT:
            // just going to assume that docs are equal.
            return true;
        }
        return true;
    }

    private static <ON, N> boolean equalValue(Model<N> model, N node, Model<ON> otherModel,
            ON otherNode) {
        return model.getStringValue(node).equals(otherModel.getStringValue(otherNode));
    }

    private static <ON, N> boolean equalName(Model<N> model, N node, Model<ON> otherModel,
            ON otherNode) {
        return model.getNamespaceURI(node).equals(otherModel.getNamespaceURI(otherNode))
        && model.getLocalName(node).equals(otherModel.getLocalName(otherNode));
    }

}
