package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Manifest;
import javax.xml.crypto.dsig.SignatureProperties;
import javax.xml.crypto.dsig.SignatureProperty;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyName;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.keyinfo.PGPData;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.Model;
import org.genxdm.NodeKind;
import org.genxdm.mutable.MutableModel;

class Marshaller {

    public static <N> void marshal(XmlWriter<N> xwriter, XMLStructure toMarshal, String dsPrefix, 
            XMLCryptoContext context) throws MarshalException {
        
        if (toMarshal instanceof KeyName) {
            DOMKeyName.marshal(xwriter, (KeyName) toMarshal, dsPrefix);
        }
        else if (toMarshal instanceof KeyInfo) {
            DOMKeyInfo.marshal(xwriter, (KeyInfo) toMarshal, dsPrefix, context);
        }
        else if (toMarshal instanceof KeyValue) {
            // Since DOMKeyValue allows for deserializing unrecognized keys, and that
            // capability isn't available via the KeyValue interface, this must continue
            // to cast to DOMKeyValue.
            DOMKeyValue dkv = (DOMKeyValue) toMarshal;
            dkv.marshal( xwriter, dsPrefix, context);
        }
        else if (toMarshal instanceof X509IssuerSerial) {
            DOMX509IssuerSerial.marshal( xwriter, (X509IssuerSerial) toMarshal, dsPrefix);
        }
        else if (toMarshal instanceof X509Data) {
            DOMX509Data.marshal( xwriter, (X509Data) toMarshal, dsPrefix, context);
        }
        else if (toMarshal instanceof DigestMethod) {
            DOMDigestMethod.marshal( xwriter, (DigestMethod) toMarshal, dsPrefix);
        }
        else if (toMarshal instanceof PGPData) {
            DOMPGPData.marshal( xwriter, (PGPData) toMarshal, dsPrefix, context);
        }
        else if (toMarshal instanceof SignatureProperty) {
            DOMSignatureProperty.marshal(xwriter, (SignatureProperty) toMarshal, dsPrefix, context);
        }
        else if (toMarshal instanceof SignatureProperties) {
            DOMSignatureProperties.marshal(xwriter, (SignatureProperties) toMarshal, dsPrefix, context);
        }
        else if (toMarshal instanceof DOMSignatureMethod) {
            ( (DOMSignatureMethod) toMarshal).marshal(xwriter, dsPrefix);
        }
        else if (toMarshal instanceof DOMTransform) {
            ( (DOMTransform) toMarshal).marshal(xwriter, dsPrefix, context);
        }
        else if (toMarshal instanceof Manifest) {
            DOMManifest.marshal(xwriter, (Manifest) toMarshal, dsPrefix, context);
        }
        else if (toMarshal instanceof DOMStructure) {
            // Note - this assumes that the N type of the structure matches the model.
            @SuppressWarnings("unchecked")
            DOMStructure<N> struct = (DOMStructure<N>) toMarshal;
            struct.marshal(xwriter, dsPrefix, context);
        }
        else if (toMarshal instanceof javax.xml.crypto.dom.DOMStructure || toMarshal instanceof GenXDMStructure) {
            marshalGenericNode(xwriter, toMarshal);
        }
        else {
            throw new IllegalArgumentException("Unexpected object of class " + toMarshal.getClass().toString());
        }
    }

    private static <NS> void marshalGenericNode(XmlWriter<?> xwriter, XMLStructure xmlStruct) {
        MutableModel<NS> structModel = GenXDMStructure.getModel(xmlStruct);
        NS node = GenXDMStructure.getNode(structModel, xmlStruct);
        
        // if it is a namespace, make a copy.
        if (structModel.isNamespace(node)) {
            xwriter.writeNamespace(structModel.getLocalName(node), structModel.getStringValue(node));
        }
        else if (structModel.isAttribute(node)) {
            sendAttributeToWriter(xwriter, structModel, node);
        }
        else {
            marshalGenericNode(xwriter, structModel, node);
        }
    }
    
    private static <N> void marshalGenericNode(XmlWriter<?> xwriter, Model<N> model, N node) {
        if (model.isNamespace(node)) {
            xwriter.writeNamespace(model.getLocalName(node), model.getStringValue(node));
        }
        else if (model.isAttribute(node)) {
            // if it is an attribute, make a copy.
            sendAttributeToWriter(xwriter, model, node);
        }
        else {
            NodeKind kind = model.getNodeKind(node);
            switch (kind) {
            case ELEMENT:
                xwriter.writeStartElement(model.getPrefix(node), model.getLocalName(node), model.getNamespaceURI(node));
                
                // now, for an element, marshal the namespaces, attributes, and children.
                for (N nsDecl : model.getNamespaceAxis(node, false)) {
                    xwriter.writeNamespace(model.getLocalName(nsDecl), model.getStringValue(nsDecl));
                }
                for (N attr : model.getAttributeAxis(node, false)) {
                    sendAttributeToWriter(xwriter, model, attr);
                }
                for (N child : model.getChildAxis(node)) {
                    marshalGenericNode(xwriter, model, child);
                }
                xwriter.writeEndElement();
                break;
            case COMMENT:
                xwriter.writeComment(model.getStringValue(node));
                break;
            case TEXT:
                xwriter.writeCharacters(model.getStringValue(node));
                break;
            default:
                // unhandled - don't care to deal with processing instructions.
                break;
            }
        }
    }

    private static <N> void sendAttributeToWriter(XmlWriter<?> xwriter, Model<N> model, N node) {
        if (model.isId(node)) {
            xwriter.writeIdAttribute(model.getPrefix(node), model.getNamespaceURI(node),
                    model.getLocalName(node), model.getStringValue(node));
        }
        else {
            xwriter.writeAttribute(model.getPrefix(node), model.getNamespaceURI(node),
                    model.getLocalName(node), model.getStringValue(node));
        }
    }
    
}
