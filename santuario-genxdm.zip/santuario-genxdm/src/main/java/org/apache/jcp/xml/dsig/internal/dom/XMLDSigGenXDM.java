package org.apache.jcp.xml.dsig.internal.dom;

import java.security.AccessController;
import java.security.Provider;
import java.util.Map;

/**
 * Provides the entry point for clients specifically looking for GenXDM support,
 * instead of looking for something that happens to support GenXDM, but also supports
 * DOM.
 * 
 * <p>Note that this could be done slightly more simply by way of a base class,
 * but that would make side-by-side comparison with the official version more difficult.
 * </p>
 */
public class XMLDSigGenXDM extends Provider {

    private static final long serialVersionUID = 7771056201768266964L;

    public XMLDSigGenXDM() {
        super("ApacheXMLDSig-GenXDM", 1.50, XMLDSigRI.INFO);

        final Map<String, String> map = XMLDSigRI.providerEntries("GenXDM");
        AccessController.doPrivileged(new java.security.PrivilegedAction<Object>() {
            public Object run() {
                putAll(map);
                return null;
            }
        });
        
    }

}
