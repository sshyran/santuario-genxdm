/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: ApacheCanonicalizer.java 1333869 2012-05-04 10:42:44Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.security.spec.AlgorithmParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.util.Collections;
import java.util.Set;
import javax.xml.crypto.*;
import javax.xml.crypto.dom.DOMCryptoContext;
import javax.xml.crypto.dsig.TransformException;
import javax.xml.crypto.dsig.TransformService;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.Transform;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Node;

public abstract class ApacheCanonicalizer<N> extends TransformService {

    static {
        org.apache.xml.security.Init.init();
    }

    private static org.apache.commons.logging.Log log =
        org.apache.commons.logging.LogFactory.getLog(ApacheCanonicalizer.class);
    protected Canonicalizer apacheCanonicalizer;
    private Transform<N> apacheTransform;
    protected String inclusiveNamespaces;
    protected C14NMethodParameterSpec params;
    protected MutableModel<N> model;
    protected N ownerDoc;
    protected N transformElem;
    
    public final AlgorithmParameterSpec getParameterSpec()
    {
        return params;
    }

    public void init(XMLStructure parent, XMLCryptoContext context)
        throws InvalidAlgorithmParameterException
    {
        validateContext(parent, context);
        membersFromStructure(parent);
    }

    private void membersFromStructure(XMLStructure parent) {
        model = GenXDMStructure.getModel(parent);
        transformElem = GenXDMStructure.getNode(model, parent);
        ownerDoc = model.getRoot(transformElem);
    }

    public void marshalParams(XMLStructure parent, XMLCryptoContext context)
	throws MarshalException {
        validateContext(parent, context);
	    membersFromStructure(parent);
    }

    /**
     * Make sure we validate the context parameter consistently.
     * @param context
     */
    private void validateContext(XMLStructure parent, XMLCryptoContext context) {
        if (context != null && !(context instanceof DOMCryptoContext) && !(context instanceof GenXDMCryptoContext)) {
            throw new ClassCastException
                ("context must be of type DOMCryptoContext or GenXDMCryptoContext");
        }
        if (parent == null || (!(parent instanceof javax.xml.crypto.dom.DOMStructure) && !(parent instanceof GenXDMStructure))) {
            throw new ClassCastException("parent must be of type DOMStructure");
        }
    }
    
    public Data canonicalize(Data data, XMLCryptoContext xc) 
        throws TransformException
    {
        return canonicalize(data, xc, null);
    }

    public Data canonicalize(Data data, XMLCryptoContext xc, OutputStream os) 
        throws TransformException
    {
        if (apacheCanonicalizer == null) {
            try {
                apacheCanonicalizer = Canonicalizer.getInstance(getAlgorithm());
                if (log.isDebugEnabled()) {
                    log.debug("Created canonicalizer for algorithm: " + getAlgorithm());
                }
            } catch (InvalidCanonicalizerException ice) {
                throw new TransformException
                    ("Couldn't find Canonicalizer for: " + getAlgorithm() +
                     ": " + ice.getMessage(), ice);
            }
        }

        if (os != null) {
            apacheCanonicalizer.setWriter(os);
        } else {
            apacheCanonicalizer.setWriter(new ByteArrayOutputStream());
        }

        try {
            Set<N> nodeSet = null;
            if (data instanceof ApacheData) {
                @SuppressWarnings("unchecked")
                XMLSignatureInput<N> in = 
                    ((ApacheData<N>)data).getXMLSignatureInput();
                if (in.isElement()) {
                    if (inclusiveNamespaces != null) {
                        return new OctetStreamData(new ByteArrayInputStream
                            (apacheCanonicalizer.canonicalizeSubtree
                                (in.getContext().mutableModel, in.getSubNodeN(), inclusiveNamespaces)));
                    } else {
                        return new OctetStreamData(new ByteArrayInputStream
                            (apacheCanonicalizer.canonicalizeSubtree
                                (in.getContext().mutableModel, in.getSubNodeN())));
                    }
                } else if (in.isNodeSet()) {
                    nodeSet = in.getNodeSet();
                } else {
                    return new OctetStreamData(new ByteArrayInputStream(
                        apacheCanonicalizer.canonicalize(
                            Utils.readBytesFromStream(in.getOctetStream()))));
                }
            } else if (data instanceof DOMSubTreeData) {
                @SuppressWarnings("unchecked")
                DOMSubTreeData<N> subTree = (DOMSubTreeData<N>) data;
                if (inclusiveNamespaces != null) {
                    return new OctetStreamData(new ByteArrayInputStream
                        (apacheCanonicalizer.canonicalizeSubtree
                         (subTree.getModel(), subTree.getRoot(), inclusiveNamespaces)));
                } else {
                    return new OctetStreamData(new ByteArrayInputStream
                        (apacheCanonicalizer.canonicalizeSubtree
                         (subTree.getModel(), subTree.getRoot())));
                }
            } else if (data instanceof NodeSetData) {
	            // TODO - this makes no sense to attempt to work with an unknown NodeSetData type
                NodeSetData nsd = (NodeSetData)data;
                // convert Iterator to Set
                @SuppressWarnings("unchecked")
                Set<N> ns = (Set<N>) Utils.toNodeSet(ApacheNodeSetData.getNodeSetDataIterator(nsd));
                nodeSet = ns;
                if (log.isDebugEnabled()) {
                    log.debug("Canonicalizing " + nodeSet.size() + " nodes");
                }
            } else {
                return new OctetStreamData(new ByteArrayInputStream(
                    apacheCanonicalizer.canonicalize(
                        Utils.readBytesFromStream(
                        ((OctetStreamData)data).getOctetStream()))));
            }
            if (inclusiveNamespaces != null) {
                return new OctetStreamData(new ByteArrayInputStream(
                    apacheCanonicalizer.canonicalizeXPathNodeSet
                        (model, nodeSet, inclusiveNamespaces)));
            } else {
                return new OctetStreamData(new ByteArrayInputStream(
                    apacheCanonicalizer.canonicalizeXPathNodeSet(model, nodeSet)));
            }
        } catch (Exception e) {
            throw new TransformException(e);
        }
    }

    public Data transform(Data data, XMLCryptoContext xc, OutputStream os)
        throws TransformException
    {
        if (data == null) {
            throw new NullPointerException("data must not be null");
        }
        if (os == null) {
            throw new NullPointerException("output stream must not be null");
        }

        if (ownerDoc == null) {
            throw new TransformException("transform must be marshalled");
        }

        if (apacheTransform == null) {
            try {
                Iterable<N> empty = Collections.emptyList();
                // TODO - Can we fix the following to use an alternate constructor
                // rather than creating a new element that we then discard?
                apacheTransform =
                    new Transform<N>(model, ownerDoc, getAlgorithm(), empty);
                apacheTransform.setElementNode(transformElem, xc.getBaseURI());
                if (log.isDebugEnabled()) {
                    log.debug("Created transform for algorithm: " + getAlgorithm());            
                }
            } catch (Exception ex) {
                throw new TransformException
                    ("Couldn't find Transform for: " + getAlgorithm(), ex);
            }
        }

        XMLSignatureInput<N> in;
        if (data instanceof ApacheData) {
            if (log.isDebugEnabled()) {
                log.debug("ApacheData = true");
            }
            @SuppressWarnings("unchecked")
            XMLSignatureInput<N> tempIn = ((ApacheData<N>) data).getXMLSignatureInput(); 
            in = tempIn;
        } else if (data instanceof NodeSetData) {
            if (log.isDebugEnabled()) {
                log.debug("isNodeSet() = true");
            }
            if (data instanceof DOMSubTreeData) {
                @SuppressWarnings("unchecked")
                DOMSubTreeData<N> subTree = (DOMSubTreeData<N>) data;
                XmlContext<N> xmlCtx = new XmlContext<N>(subTree.getDocumentHandlerFactory(), subTree.getModel());
                in = new XMLSignatureInput<N>(xmlCtx, subTree.getRoot());
                in.setExcludeComments(subTree.excludeComments());
            } else {
                // TODO - the following is a folly to assume that it is a NodeSetData that holds DOM,
                // but that's how the official project does it.
                @SuppressWarnings("unchecked")
                Set<Node> nodeSet =
                    Utils.toNodeSet(ApacheNodeSetData.getNodeSetDataIterator((NodeSetData) data));
                @SuppressWarnings("unchecked")
                XMLSignatureInput<N> tempIn = (XMLSignatureInput<N>) new XMLSignatureInput<Node>(XmlContext.getContext(), nodeSet);
                in = tempIn;
            }
        } else {
            if (log.isDebugEnabled()) {
                log.debug("isNodeSet() = false");
            }
            try {
                DocumentHandlerFactory<N> docFactory = GenXDMCryptoContext.getDocumentHandlerFactory(xc);
                XmlContext<N> xmlCtx = new XmlContext<N>(docFactory, model);
                in = new XMLSignatureInput<N>
                    (xmlCtx, ((OctetStreamData)data).getOctetStream());
            } catch (Exception ex) {
                throw new TransformException(ex);
            }
        }

        try {
            in = apacheTransform.performTransform(in, os);
            if (!in.isNodeSet() && !in.isElement()) {
                return null;
            }
            if (in.isOctetStream()) {
                return new ApacheOctetStreamData<N>(in);
            } else {
                return new ApacheNodeSetData<N>(in);
            }
        } catch (Exception ex) {
            throw new TransformException(ex);
        }
    }

    public final boolean isFeatureSupported(String feature) {
        if (feature == null) {
            throw new NullPointerException();
        } else {
            return false;
        }
    }
}
