/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMSignedInfo.java 1333415 2012-05-03 12:03:51Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.security.Provider;
import java.util.*;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.apache.xml.security.utils.Base64;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.UnsyncBufferedOutputStream;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Element;

/**
 * DOM-based implementation of SignedInfo.
 *
 * @author Sean Mullan
 */
public final class DOMSignedInfo<N> extends DOMStructure<N> implements SignedInfo {
    
    /**
     * The maximum number of references per Manifest, if secure validation is enabled.
     */
    public static final int MAXIMUM_REFERENCE_COUNT = 30;

    private static org.apache.commons.logging.Log log =
        org.apache.commons.logging.LogFactory.getLog(DOMSignedInfo.class);
    
    /** Signature - NOT Recommended RSAwithMD5 */
    private static final String ALGO_ID_SIGNATURE_NOT_RECOMMENDED_RSA_MD5 = 
        Constants.MoreAlgorithmsSpecNS + "rsa-md5";
    
    /** HMAC - NOT Recommended HMAC-MD5 */
    private static final String ALGO_ID_MAC_HMAC_NOT_RECOMMENDED_MD5 = 
        Constants.MoreAlgorithmsSpecNS + "hmac-md5";
    
    private List<Reference> references;
    private CanonicalizationMethod canonicalizationMethod;
    private SignatureMethod signatureMethod;
    private String id;
    private N localSiElem;
    private MutableModel<N> model;
    private InputStream canonData;

    /**
     * Creates a <code>DOMSignedInfo</code> from the specified parameters. Use
     * this constructor when the <code>Id</code> is not specified.
     *
     * @param cm the canonicalization method
     * @param sm the signature method
     * @param references the list of references. The list is copied.
     * @throws NullPointerException if
     *    <code>cm</code>, <code>sm</code>, or <code>references</code> is 
     *    <code>null</code>
     * @throws IllegalArgumentException if <code>references</code> is empty
     * @throws ClassCastException if any of the references are not of
     *    type <code>Reference</code>
     */
    public DOMSignedInfo(CanonicalizationMethod cm, SignatureMethod sm,
                         List<? extends Reference> references) {
        if (cm == null || sm == null || references == null) {
            throw new NullPointerException();
        }
        this.canonicalizationMethod = cm;
        this.signatureMethod = sm;
        this.references = Collections.unmodifiableList(
            new ArrayList<Reference>(references));
        if (this.references.isEmpty()) {
            throw new IllegalArgumentException("list of references must " +
                "contain at least one entry");
        }
        for (int i = 0, size = this.references.size(); i < size; i++) {
            Object obj = this.references.get(i);
            if (!(obj instanceof Reference)) {
                throw new ClassCastException("list of references contains " +
                    "an illegal type");
            }
        }
    }

    /**
     * Creates a <code>DOMSignedInfo</code> from the specified parameters.
     *
     * @param cm the canonicalization method
     * @param sm the signature method
     * @param references the list of references. The list is copied.
     * @param id an optional identifer that will allow this
     *    <code>SignedInfo</code> to be referenced by other signatures and
     *    objects
     * @throws NullPointerException if <code>cm</code>, <code>sm</code>,
     *    or <code>references</code> is <code>null</code>
     * @throws IllegalArgumentException if <code>references</code> is empty
     * @throws ClassCastException if any of the references are not of
     *    type <code>Reference</code>
     */
    public DOMSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, 
                         List<? extends Reference> references, String id) {
        this(cm, sm, references);
        this.id = id;
    }

    /**
     * Creates a <code>DOMSignedInfo</code> from an element.
     *
     * @param siElem a SignedInfo element
     */
    public DOMSignedInfo(MutableModel<N> model, N siElem, XMLCryptoContext context, Provider provider)
        throws MarshalException {
        this.model = model;
        localSiElem = siElem;

        // get Id attribute, if specified
        id = DOMUtils.getAttributeValue(model, siElem, "Id");

        // unmarshal CanonicalizationMethod
        N cmElem = model.getFirstChildElement(siElem);
        canonicalizationMethod = new DOMCanonicalizationMethod(model, cmElem, context, provider);

        // unmarshal SignatureMethod
        N smElem = model.getNextSiblingElement(cmElem);
        signatureMethod = DOMSignatureMethod.unmarshal(model, smElem);
        
        Boolean secureValidation = (Boolean)
            context.getProperty("org.apache.jcp.xml.dsig.secureValidation");
        boolean secVal = false;
        if (secureValidation != null && secureValidation.booleanValue()) {
            secVal = true;
        }

        String signatureMethodAlgorithm = signatureMethod.getAlgorithm();
        if (secVal && ((ALGO_ID_MAC_HMAC_NOT_RECOMMENDED_MD5.equals(signatureMethodAlgorithm)
                || ALGO_ID_SIGNATURE_NOT_RECOMMENDED_RSA_MD5.equals(signatureMethodAlgorithm)))) {
            throw new MarshalException(
                "It is forbidden to use algorithm " + signatureMethod + " when secure validation is enabled"
            );
        }
        
        // unmarshal References
        ArrayList<Reference> refList = new ArrayList<Reference>(5);
        N refElem = model.getNextSiblingElement(smElem);
        
        int refCount = 0;
        while (refElem != null) {
            refList.add(new DOMReference<N>(model, refElem, context, provider));
            refElem = model.getNextSiblingElement(refElem);
            
            refCount++;
            if (secVal && (refCount > MAXIMUM_REFERENCE_COUNT)) {
                String error = "A maxiumum of " + MAXIMUM_REFERENCE_COUNT + " " 
                    + "references per Manifest are allowed with secure validation";
                throw new MarshalException(error);
            }
        }
        references = Collections.unmodifiableList(refList);
    }

    /**
     * Creates a <code>DOMSignedInfo</code> from an element.
     *
     * @param siElem a SignedInfo element
     * 
     * @deprecated New clients should use {@link #DOMSignedInfo(MutableModel, Object, XMLCryptoContext, Provider)}
     */
    @SuppressWarnings("unchecked")
    public DOMSignedInfo(Element siElem, XMLCryptoContext context, Provider provider)
        throws MarshalException {
        this( (MutableModel<N>) XmlContext.getDomModel(), (N) siElem, context, provider); 
    }
    
    public CanonicalizationMethod getCanonicalizationMethod() {
        return canonicalizationMethod;
    }

    public SignatureMethod getSignatureMethod() {
        return signatureMethod;
    }

    public String getId() {
        return id;
    }

    public List<Reference> getReferences() {
        return references;
    }

    public InputStream getCanonicalizedData() {
        return canonData;
    }

    public void canonicalize(XMLCryptoContext context, ByteArrayOutputStream bos)
        throws XMLSignatureException {
        if (context == null) {
            throw new NullPointerException("context cannot be null");
        }

        OutputStream os = new UnsyncBufferedOutputStream(bos);
        try {
            os.close();
        } catch (IOException e) {
            if (log.isDebugEnabled()) {
                log.debug(e);
            }
            // Impossible
        }

        DocumentHandlerFactory<N> docFactory = GenXDMCryptoContext.getDocumentHandlerFactory(context);
        DOMSubTreeData<N> subTree = new DOMSubTreeData<N>(docFactory, model, localSiElem, true);

        try {
            ((DOMCanonicalizationMethod) 
                canonicalizationMethod).canonicalize(subTree, context, bos);
        } catch (TransformException te) {
            throw new XMLSignatureException(te);
        }

        byte[] signedInfoBytes = bos.toByteArray();

        // this whole block should only be done if logging is enabled
        if (log.isDebugEnabled()) {
            log.debug("Canonicalized SignedInfo:"); 
            StringBuilder sb = new StringBuilder(signedInfoBytes.length);
            for (int i = 0; i < signedInfoBytes.length; i++) {
                sb.append((char)signedInfoBytes[i]);
            }
            log.debug(sb.toString());
            log.debug("Data to be signed/verified:" + Base64.encode(signedInfoBytes));
        }

        this.canonData = new ByteArrayInputStream(signedInfoBytes);
    }

    public void marshal(XmlWriter<N> xwriter, String dsPrefix, XMLCryptoContext context)
        throws MarshalException
    {
        xwriter.writeStartElement(dsPrefix, "SignedInfo", XMLSignature.XMLNS);
        XMLStructure siStruct = xwriter.getCurrentNodeAsStructure();
        model = GenXDMStructure.getModel(siStruct);
        localSiElem = GenXDMStructure.getNode(model, siStruct);

        // append Id attribute
        xwriter.writeIdAttribute("", "", "Id", id);
            
        // create and append CanonicalizationMethod element
        DOMCanonicalizationMethod dcm =
            (DOMCanonicalizationMethod)canonicalizationMethod;
        dcm.marshal(xwriter, dsPrefix, context); 

        // create and append SignatureMethod element
        ((AbstractDOMSignatureMethod) signatureMethod).marshal(xwriter, dsPrefix);

        // create and append Reference elements
        for (Reference reference : references) {
            // TODO - either suppress warning here, or figure out how to get rid of the cast.
            DOMReference<N> domRef = (DOMReference<N>)reference;
            domRef.marshal(xwriter, dsPrefix, context);
        }

        xwriter.writeEndElement(); // "SignedInfo"
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (!(o instanceof SignedInfo)) {
            return false;
        }
        SignedInfo osi = (SignedInfo)o;

        boolean idEqual = (id == null ? osi.getId() == null
                                      : id.equals(osi.getId()));

        boolean canonMethodEqual = canonicalizationMethod.equals(osi.getCanonicalizationMethod());
        boolean sigMethodEqual = signatureMethod.equals(osi.getSignatureMethod());
        boolean referencesEqual = references.equals(osi.getReferences());
        return (canonMethodEqual && sigMethodEqual && referencesEqual && idEqual);
    }

    @SuppressWarnings("unchecked")
    public static List<Reference> getSignedInfoReferences(SignedInfo si) {
        return si.getReferences();
    }
    
    @Override
    public int hashCode() {
        int result = 17;
        if (id != null) {
            result = 31 * result + id.hashCode();
        }
        if (canonicalizationMethod != null) {
            result = 31 * result + canonicalizationMethod.hashCode();
        }
        if (signatureMethod != null) {
            result = 31 * result + signatureMethod.hashCode();
        }
        if (references != null) {
            result = 31 * result + references.hashCode();
        }
        
        return result;
    }
}
