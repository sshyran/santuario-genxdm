package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.XMLStructure;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * Manifestation of XmlWriter interface designed to write to a tree.
 */
public class XmlWriterToTree<N> implements XmlWriter<N> {

    public XmlWriterToTree(MutableModel<N> model, N parent) {
        m_model = model;
        m_factory = model.getFactory(parent);
        m_currentNode = parent;
    }
    
    /**
     * Reset to a new parent so that the writer can be re-used.
     * @param newParent
     */
    public void resetToNewParent(N newParent) {
        m_currentNode = newParent;
        m_createdElement = null;
    }
    
    /**
     * Get the root element created with this writer.
     * @return
     */
    public N getCreatedElement() {
        return m_createdElement;
    }
    
    /**
     * In cases where the serialization is supposed to precede a specific
     * element, we add an extra paramter to capture that. Only affects the
     * first element insertion (obviously?).
     * 
     * @param model
     * @param parent
     * @param nextSibling The first element created will be created *before* this element.
     */
    public XmlWriterToTree(MutableModel<N> model, N parent, N nextSibling) {
        this(model, parent);
        m_nextSibling = nextSibling;
    }
    
    public void writeStartElement(String prefix, String localName, String namespaceURI) {
        N newElem = m_factory.createElement(namespaceURI, localName, prefix);
        if (m_nextSibling != null) {
            m_model.insertAfter(m_nextSibling, newElem);
        }
        else {
            m_model.appendChild(m_currentNode, newElem);
        }
        m_nextSibling = null;
        m_currentNode = newElem;
        
        if (m_createdElement == null) {
            m_createdElement = m_currentNode;
        }
    }

    public void writeEndElement() {
        m_currentNode = m_model.getParent(m_currentNode);
    }

    
    public void writeTextElement(String prefix, String localName, String namespaceURI, String value) {
        writeStartElement(prefix, localName, namespaceURI);
        writeCharacters(value);
        writeEndElement();
    }

    public void writeNamespace(String prefix, String namespaceURI) {
        m_model.insertNamespace(m_currentNode, prefix, namespaceURI);
    }

    public void writeCharacters(String text) {
        N textNode = m_factory.createText(text);
        m_model.appendChild(m_currentNode, textNode);
    }
    

    public void writeComment(String text) {
        N commentNode = m_factory.createComment(text);
        m_model.appendChild(m_currentNode, commentNode);
    }

    public N writeAttribute(String prefix, String namespaceURI, String localName, String value) {

        N result = null;
        if (value != null) {
            result = m_factory.createAttribute(namespaceURI, localName, prefix, value);
            m_model.insertAttribute(m_currentNode, result);
        }
        
        return result;
    }

    public void writeIdAttribute(String prefix, String namespaceURI, String localName, String value) {
        if (value == null) {
            return;
        }
        N newAttr = m_factory.createAttribute(namespaceURI, localName, prefix, value);
        m_model.insertAttribute(m_currentNode, newAttr);
        N actualAttr = m_model.getAttribute(m_currentNode, namespaceURI, localName);
        m_model.setIsIdAttribute(actualAttr, true);
    }


    public String getCurrentLocalName() {
        return m_model.getLocalName(m_currentNode);
    }

    public XMLStructure getCurrentNodeAsStructure() {
        return new GenXDMStructure<N>(m_model, m_currentNode);
    }


    private MutableModel<N> m_model;
    
    private NodeFactory<N> m_factory;
    
    private N m_createdElement;
    
    private N m_nextSibling;
    
    private N m_currentNode;
}
