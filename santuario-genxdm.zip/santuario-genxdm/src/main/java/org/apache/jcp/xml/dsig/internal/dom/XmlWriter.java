package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.XMLStructure;
import javax.xml.stream.XMLStreamWriter;

/**
 * This interface is used to construct XML via a sequence of API calls.
 * 
 * <p>This is written to be similar to javax.xml.stream.XMLStreamWriter, but
 * has slightly different requirements. Specifically, we need to be able to create
 * an "ID" type attribute, and get the current node.
 * </p>
 */
public interface XmlWriter<N> {

    /**
     * 
     * @param prefix    What prefix to use?
     * @param localName What local name to use?
     * @param namespaceURI  What namespace URI?
     * 
     * @see {@link XMLStreamWriter#writeStartElement(String, String, String)}
     */
    void writeStartElement(String prefix, String localName, String namespaceURI);
    
    /**
     * @see {@link XMLStreamWriter#writeEndElement()}
     */
    void writeEndElement();
    
    /**
     * Convenience method that writes both a start and end tag, with text contents as
     * provided.
     * 
     * @param prefix
     * @param localName
     * @param namespaceURI
     * @param value
     */
    void writeTextElement(String prefix, String localName, String namespaceURI, String value);
    
    void writeNamespace(String prefix, String namespaceURI);
    
    void writeCharacters(String text);
    
    void writeComment(String text);
    
    N writeAttribute(String prefix, String namespaceURI, String localName, String value);
    
    void writeIdAttribute(String prefix, String namespaceURI, String localName, String value);

    /**
     * Get the local name of the current element.
     * @return
     */
    String getCurrentLocalName();

    XMLStructure getCurrentNodeAsStructure();
}
