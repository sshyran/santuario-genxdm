/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.utils;

import java.io.IOException;
import java.io.OutputStream;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.genxdm.Model;
import org.genxdm.NodeKind;
import org.genxdm.compat.DomCompatibility;
import org.genxdm.io.DocumentHandler;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;
import org.genxdm.names.NamespaceBinding;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

/**
 * DOM and XML accessibility and comfort functions.
 *
 * @author Christian Geuer-Pollmann
 */
public class XMLUtils {

    private static boolean ignoreLineBreaks =
        AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
            public Boolean run() {
                return Boolean.valueOf(Boolean.getBoolean
                    ("org.apache.xml.security.ignoreLineBreaks"));
            }
        }).booleanValue();
    
    private static volatile String dsPrefix = "ds";
    private static volatile String ds11Prefix = "dsig11";
    private static volatile String xencPrefix = "xenc";
    private static volatile String xenc11Prefix = "xenc11";
    
    /** {@link org.apache.commons.logging} logging facility */
    private static final org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(XMLUtils.class);


    /**
     * Constructor XMLUtils
     *
     */
    private XMLUtils() {
        // we don't allow instantiation
    }
    
    public static void ensureSecureProcessing(DocumentHandler<?> dh) {
        if (!dh.isSecurelyProcessing()) {
            throw new IllegalStateException("Not securely processing XML input documents.");
        }
    }
    
    /**
     * Set the prefix for the digital signature namespace
     * @param prefix the new prefix for the digital signature namespace
     */
    public static void setDsPrefix(String prefix) {
        dsPrefix = prefix;
    }
    
    /**
     * Set the prefix for the digital signature 1.1 namespace 
     * @param prefix the new prefix for the digital signature 1.1 namespace
     */
    public static void setDs11Prefix(String prefix) {
        ds11Prefix = prefix;
    }
    
    /**
     * Set the prefix for the encryption namespace
     * @param prefix the new prefix for the encryption namespace
     */
    public static void setXencPrefix(String prefix) {
        xencPrefix = prefix;
    }
    
    /**
     * Set the prefix for the encryption namespace 1.1
     * @param prefix the new prefix for the encryption namespace 1.1
     */
    public static void setXenc11Prefix(String prefix) {
        xenc11Prefix = prefix;
    }
    
    /**
     * For the aid of the APIs that strive to be backwards compatible, convert a node
     * list to a regular list.
     * 
     * @param nodeList  The list to turn into a regular {@link List}.
     * @return  The newly created list.
     */
    public static List<Node> nodeListToList(NodeList nodeList) {
        
        List<Node> result = Collections.emptyList();
        if (nodeList != null && nodeList.getLength() > 0) {
            
            result = new ArrayList<Node>();
            for (int idx = 0 ; idx < nodeList.getLength() ; idx++) {
                Node node = nodeList.item(idx);
                result.add(node);
            }
        }
        
        return result;
    }
    

    /**
     * Sort of a hack to get canonicalization to work properly.
     * 
     * @param <N> The node type being used with the {@link Model}
     * @param bridge Bridge to use to access the underlying XML node
     * @param node  The XML element for which we desire a tag name.
     * 
     * @return A String representing a prefix:localname form of a name.
     */
    public static <N> String getTagName(Model<N> bridge, N node) {
        String result;
        if (bridge.getNodeKind(node) == NodeKind.NAMESPACE) {
            
            String localName = bridge.getLocalName(node);
            if (localName.length() > 0) {
                result = "xmlns:" + localName;
            }
            else {
                result = "xmlns";
            }
        }
        else {
            String prefix = bridge.getPrefix(node);
            String localName = bridge.getLocalName(node);
            if (prefix.length() > 0) {
                result = prefix + ":" + localName;
            }
            else {
                result = localName;
            }
        }
        return result;
    }

    /**
     * @param rootNode
     * @param result
     * @param exclude
     * @param com whether comments or not
     * 
     * @deprecated See {@link #getSet(Model, Object, Set, Object, boolean)}
     */   
    public static void getSet(Node rootNode, Set<Node> result, Node exclude, boolean com) {
        getSet(XmlContext.getDomModel(), rootNode, result, exclude, com);
    }
    
    /**
     * @param rootNode
     * @param result
     * @param exclude
     * @param com wheather comments or not
     */   
    public static <N> void getSet(Model<N> model, N rootNode, Set<N> result, N exclude, boolean com) {
       if ((exclude!=null) && isDescendantOrSelf(model, exclude, rootNode)){
         return;
       }
       getSetRec(model, rootNode, result, exclude, com);
    }

    @SuppressWarnings("fallthrough")
    static final <N> void getSetRec(Model<N> model, final N rootNode,final Set<N> result,
                                final N exclude, final boolean com) {
        if (rootNode == exclude) {
            return;
        }
        switch (model.getNodeKind(rootNode)) {                               
        case ELEMENT:
            result.add(rootNode);
            N el= rootNode;
            if (model.hasAttributes(el) ) {
                for (N attr : model.getAttributeAxis(el, false)) {
                    result.add(attr);
                }
                for (N ns : model.getNamespaceAxis(el, false)) {
                    result.add(ns);
                }
            }
            //no return keep working
        case DOCUMENT:   	   			
            // this code originally skipped multiple text nodes in a row (not separated by anything)
            // and returned if there was nothing else under the child.
            // This seemed like really odd behavior, and was not documented, so instead
            // the new version simply iterates over the children.
            for (N r : model.getChildAxis(rootNode)) {
                getSetRec(model, r, result, exclude, com);
            }
            return;
        case COMMENT:
            if (com) {
                result.add(rootNode);
            }
            return;
        //case Node.DOCUMENT_TYPE_NODE:
        //    return;
        default:
            result.add(rootNode);
        }
    }


    /**
     * Outputs a DOM tree to an {@link OutputStream}.
     *
     * @param contextNode root node of the DOM tree
     * @param os the {@link OutputStream}
     * 
     * @deprecated New clients should use {@link #outputDOM(Model, Object, OutputStream, boolean)} with "false"
     * for the "addPreamble" parameter.
     */
    public static void outputDOM(Node contextNode, OutputStream os) {
        XMLUtils.outputDOM(contextNode, os, false);
    }

    /**
     * Outputs a DOM tree to an {@link OutputStream}. <I>If an Exception is
     * thrown during execution, it's StackTrace is output to System.out, but the
     * Exception is not re-thrown.</I>
     *
     * @param contextNode root node of the DOM tree
     * @param os the {@link OutputStream}
     * @param addPreamble
     * 
     * @deprecated New clients should call {@link #outputDOM(Model, Object, OutputStream, boolean)}
     */
    public static void outputDOM(Node contextNode, OutputStream os, boolean addPreamble) {
       outputDOM(XmlContext.getDomModel(), contextNode, os, addPreamble);
    }

    /**
     * Outputs a DOM tree to an {@link OutputStream}. <I>If an Exception is
     * thrown during execution, it's StackTrace is output to System.out, but the
     * Exception is not re-thrown.</I>
     *
     * @param contextNode root node of the DOM tree
     * @param os the {@link OutputStream}
     * @param addPreamble
     */
    public static <N> void outputDOM(Model<N> model, N contextNode, OutputStream os, boolean addPreamble) {
        try {
            if (addPreamble) {
                os.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".getBytes("UTF-8"));
            }

            os.write(Canonicalizer.getInstance(
                Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS).canonicalizeSubtree(model, contextNode)
            );
        } catch (IOException ex) {
            if (log.isDebugEnabled()) {
                log.debug(ex);
            }
        }
        catch (InvalidCanonicalizerException ex) {
            if (log.isDebugEnabled()) {
                log.debug(ex);
            }
        } catch (CanonicalizationException ex) {
            if (log.isDebugEnabled()) {
                log.debug(ex);
            }
        }
    }

    /**
     * Serializes the <CODE>contextNode</CODE> into the OutputStream, <I>but
     * suppresses all Exceptions</I>.
     * <BR />
     * NOTE: <I>This should only be used for debugging purposes,
     * NOT in a production environment; this method ignores all exceptions,
     * so you won't notice if something goes wrong. If you're asking what is to
     * be used in a production environment, simply use the code inside the
     * <code>try{}</code> statement, but handle the Exceptions appropriately.</I>
     *
     * @param contextNode
     * @param os
     * 
     * @deprecated New clients should use {@link #outputDOMc14nWithComments(Model, Object, OutputStream)}
     */
    public static void outputDOMc14nWithComments(Node contextNode, OutputStream os) {
       outputDOMc14nWithComments(XmlContext.getDomModel(), contextNode, os);
   }

 
    /**
     * Serializes the <CODE>contextNode</CODE> into the OutputStream, <I>but
     * supresses all Exceptions</I>.
     * <BR />
     * NOTE: <I>This should only be used for debugging purposes,
     * NOT in a production environment; this method ignores all exceptions,
     * so you won't notice if something goes wrong. If you're asking what is to
     * be used in a production environment, simply use the code inside the
     * <code>try{}</code> statement, but handle the Exceptions appropriately.</I>
     *
     * @param contextNode
     * @param os
     */
    public static <N> void outputDOMc14nWithComments(Model<N> model, N contextNode, OutputStream os) {
        try {
            os.write(Canonicalizer.getInstance(
                Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS).canonicalizeSubtree(model, contextNode)
            );
        } catch (IOException ex) {
            if (log.isDebugEnabled()) {
                log.debug(ex);
            }
            // throw new RuntimeException(ex.getMessage());
        } catch (InvalidCanonicalizerException ex) {
            if (log.isDebugEnabled()) {
                log.debug(ex);
            }
            // throw new RuntimeException(ex.getMessage());
        } catch (CanonicalizationException ex) {
            if (log.isDebugEnabled()) {
                log.debug(ex);
            }
            // throw new RuntimeException(ex.getMessage());
        }
    }

    /**
     * Method getFullTextChildrenFromElement
     *
     * @param element
     * @return the string of children
     */
    public static <N> String getFullTextChildrenFromElement(Model<N> model, N element) {
        StringBuilder sb = new StringBuilder();
        
        for (N curr : model.getChildAxis(element)) {
            if (model.getNodeKind(curr) == NodeKind.TEXT) {
                sb.append( model.getStringValue(curr) );
             }
        }
        
        return sb.toString();
    }

    /**
     * Creates an Element in the XML Signature specification namespace.
     *
     * @param doc the factory Document
     * @param elementName the local name of the Element
     * @return the Element
     * 
     * @deprecated New clients should use {@link #createElementInSignatureSpace(XmlContext, Object, String)}
     */
    public static Element createElementInSignatureSpace(Document doc, String elementName) {
        return (Element) createElementInSignatureSpace(XmlContext.getContext(), doc, elementName);
    }
    
    /**
     * Creates an Element in the XML Signature 1.1 specification namespace.
     *
     * @param doc the factory Document
     * @param elementName the local name of the Element
     * @return the Element
     */
    public static <N> N createElementInSignature11Space(NodeFactory<N> nodeFactory, String elementName) {

        if ((ds11Prefix == null) || (ds11Prefix.length() == 0)) {
            return nodeFactory.createElement(Constants.SignatureSpec11NS, elementName, "");
        } 
        return nodeFactory.createElement(Constants.SignatureSpec11NS, elementName, ds11Prefix);
    }

    /**
     * Creates an Element in the XML Signature specification namespace.
     *
     * @param doc the factory Document
     * @param elementName the local name of the Element
     * @return the Element
     * 
     * @deprecated New clients should use {@link #createElementInSignatureSpace(NodeFactory, String)}
     */
    public static <N> N createElementInSignatureSpace(XmlContext<N> ctx, N doc, String elementName) {

        if (doc == null) {
            throw new RuntimeException("Document is null");
         }
         
         NodeFactory<N> factory = ctx.mutableModel.getFactory(doc);
         return createElementInSignatureSpace(factory, elementName);
      }
      
      /**
       * Creates an Element in the XML Signature specification namespace.
       *
       * @param nodeFactory The factory for creating the element.
       * @param elementName the local name of the Element
       * @return the Element
       */
      public static <N> N createElementInSignatureSpace(NodeFactory<N> nodeFactory, String elementName) {
          if ((dsPrefix == null) || (dsPrefix.length() == 0)) {
              return nodeFactory.createElement(Constants.SignatureSpecNS, elementName, "");
          } 
          return nodeFactory.createElement(Constants.SignatureSpecNS, elementName, dsPrefix);
      }

    /**
     * Creates an Element in the XML Encryption specification namespace.
     *
     * @param doc the factory Document
     * @param elementName the local name of the Element
     * @return the Element
     */
    public static <N> N createElementInEncryptionSpace(NodeFactory<N> factory, String elementName) {
        return factory.createElement(EncryptionConstants.EncryptionSpecNS, elementName, xencPrefix);
    }
    
    /**
     * Creates an Element in the XML Encryption 1.1 specification namespace.
     *
     * @param doc the factory Document
     * @param elementName the local name of the Element
     * @return the Element
     */
    public static <N> N createElementInEncryption11Space(NodeFactory<N> factory, String elementName) {
        return factory.createElement(EncryptionConstants.EncryptionSpecNS, elementName, xenc11Prefix);
    }

    /**
     * Returns true if the element is in XML Signature namespace and the local
     * name equals the supplied one.
     *
     * @param element
     * @param localName
     * @return true if the element is in XML Signature namespace and the local name equals 
     * the supplied one
     */
    public static <N> boolean elementIsInSignatureSpace(Model<N> model, N element, String localName) {
        if (element == null){
            return false;
        }

        return Constants.SignatureSpecNS.equals(model.getNamespaceURI(element)) && model.getLocalName(element).equals(localName);
    }
    
    /**
     * Returns true if the element is in XML Signature 1.1 namespace and the local
     * name equals the supplied one.
     *
     * @param element
     * @param localName
     * @return true if the element is in XML Signature namespace and the local name equals 
     * the supplied one
     */
    public static <N> boolean elementIsInSignature11Space(Model<N> model, N element, String localName) {
        if (element == null) {
            return false;
        }

        return Constants.SignatureSpec11NS.equals(model.getNamespaceURI(element)) 
            && model.getLocalName(element).equals(localName);
    }

    /**
     * Returns true if the element is in XML Signature namespace and the local
     * name equals the supplied one.
     *
     * @param element
     * @param localName
     * @return true if the element is in XML Signature namespace and the local name equals the supplied one
     * 
     * @deprecated New clients should use {@link #elementIsInSignatureSpace(Model, Object, String)}
     */
    public static boolean elementIsInSignatureSpace(Element element, String localName) {
        return elementIsInSignatureSpace(XmlContext.getDomModel(), element, localName);
    }

    /**
     * Returns true if the element is in XML Encryption namespace and the local
     * name equals the supplied one.
     *
     * @param element
     * @param localName
     * @return true if the element is in XML Encryption namespace and the local name 
     * equals the supplied one
     */
    public static <N> boolean elementIsInEncryptionSpace(Model<N> model, N element, String localName) {
        if (element == null){
            return false;
        }
        return EncryptionConstants.EncryptionSpecNS.equals(model.getNamespaceURI(element)) && model.getLocalName(element).equals(localName);
    }
    
    /**
     * Returns true if the element is in XML Encryption 1.1 namespace and the local
     * name equals the supplied one.
     *
     * @param element
     * @param localName
     * @return true if the element is in XML Encryption 1.1 namespace and the local name 
     * equals the supplied one
     */
    public static <N> boolean elementIsInEncryption11Space(Model<N> model, N element, String localName) {
        if (element == null){
            return false;
        }
        return EncryptionConstants.EncryptionSpec11NS.equals(model.getNamespaceURI(element)) && model.getLocalName(element).equals(localName);
    }

    /**
     * This method returns the owner document of a particular node.
     * This method is necessary because it <I>always</I> returns a
     * {@link Document}. {@link Node#getOwnerDocument} returns <CODE>null</CODE>
     * if the {@link Node} is a {@link Document}.
     *
     * @param node
     * @return the owner document of the node
     * 
     * @deprecated Should be using {@link #getOwnerDocument(Model, Object)} form.
     */
    public static Document getOwnerDocument(Node node) {
        return (Document) getOwnerDocument(XmlContext.getDomModel(), node);
    }

    /**
     * This method returns the owner document of a particular node.
     * This method is necessary because it <I>always</I> returns a
     * {@link Document}. {@link Node#getOwnerDocument} returns <CODE>null</CODE>
     * if the {@link Node} is a {@link Document}.
     *
     * @param node
     * @return the owner document of the node
     */
    public static <N> N getOwnerDocument(Model<N> bridge, N node) {

        return bridge.getRoot(node);
    }
    
    /**
     * This method returns the first non-null owner document of the Nodes in this Set.
     * This method is necessary because it <I>always</I> returns a
     * {@link Document}. {@link Node#getOwnerDocument} returns <CODE>null</CODE>
     * if the {@link Node} is a {@link Document}.
     *
     * @param xpathNodeSet
     * @return the owner document 
     */
    public static Document getOwnerDocument(Collection<Node> xpathNodeSet) {
        NullPointerException npe = null;
        for (Node node : xpathNodeSet) {
            int nodeType = node.getNodeType();
            if (nodeType == Node.DOCUMENT_NODE) {
                return (Document) node;
            } 
            try {
                if (nodeType == Node.ATTRIBUTE_NODE) {
                    return ((Attr)node).getOwnerElement().getOwnerDocument();  
                }
                return node.getOwnerDocument();
            } catch (NullPointerException e) {
                npe = e;
            }
        }
        
        throw new NullPointerException(I18n.translate("endorsed.jdk1.4.0")
                                       + " Original message was \""
                                       + (npe == null ? "" : npe.getMessage()) + "\"");
    }

    /**
     * This method returns the first non-null owner document of the Node's in this Set.
     * This method is necessary because it <I>always</I> returns a
     * {@link Document}. {@link Node#getOwnerDocument} returns <CODE>null</CODE>
     * if the {@link Node} is a {@link Document}.
     *
     * @param xpathNodeSet
     * @return the owner document 
     */
    public static <N> N getOwnerDocument(Model<N> bridge, Iterable<N> xpathNodeSet) {
        for (N node : xpathNodeSet) {
            return bridge.getRoot(node);
        }
        
        return null;
    }
    
    /**
     * Method createDSctx
     *
     * @param doc
     * @param prefix
     * @param namespace
     * @return the element.
     */
    public static Element createDSctx(Document doc, String prefix, String namespace) {
        if ((prefix == null) || (prefix.trim().length() == 0)) {
            throw new IllegalArgumentException("You must supply a prefix");
        }

        Element ctx = doc.createElementNS(null, "namespaceContext");

        ctx.setAttributeNS(Constants.NamespaceSpecNS, "xmlns:" + prefix.trim(), namespace);

        return ctx;
    }

    /**
     * Method addReturnToElement
     * @param model TODO
     * @param e
     */
    public static <N> void addReturnToElement(MutableModel<N> model, N e) {
       if (!ignoreLineBreaks) {
           NodeFactory<N> factory = model.getFactory(e);
           model.appendChild(e, factory.createText("\n"));
       }
    }
    
    public static <N> void addReturnToElement(NodeFactory<N> factory, List<N> nl) {
        if (!ignoreLineBreaks) {
            nl.add(factory.createText("\n"));
        }
     }

    public static <N> void addReturnBeforeChild(MutableModel<N> model, NodeFactory<N> factory, N child) {
        if (!ignoreLineBreaks) {
            model.insertBefore(child, factory.createText("\n"));
        }
    }

    /**
     * Method convertNodelistToSet
     *
     * @param xpathNodeSet
     * @return the set with the nodelist
     */
    public static Set<Node> convertNodelistToSet(NodeList xpathNodeSet) {
        if (xpathNodeSet == null) {
            return new HashSet<Node>();
        }

        int length = xpathNodeSet.getLength();
        Set<Node> set = new HashSet<Node>(length);

        for (int i = 0; i < length; i++) {
            set.add(xpathNodeSet.item(i));
        }

        return set;
    }

    /**
     * This method spreads all namespace attributes in a DOM document to their
     * children. This is needed because the XML Signature XPath transform
     * must evaluate the XPath against all nodes in the input, even against
     * XPath namespace nodes. Through a bug in XalanJ2, the namespace nodes are
     * not fully visible in the Xalan XPath model, so we have to do this by
     * hand in DOM spaces so that the nodes become visible in XPath space.
     *
     * @param doc
     * @see <A HREF="https://issues.apache.org/jira/browse/XALANJ-334">Namespace axis resolution is not XPath compliant </A>
     */
    public static <N> void circumventBug2650(MutableModel<N> model, N doc) {

        N documentElement = model.getFirstChildElement(doc);

        // if the document element has no xmlns definition, we add xmlns=""
        boolean hasXmlns = false;
        for (NamespaceBinding nsb : model.getNamespaceBindings(documentElement)) {
            if (nsb.getPrefix() == "") {
                hasXmlns = true;
                break;
            }
        }
        if (!hasXmlns) {
            model.insertNamespace(documentElement, "", "");
         }
        
        XMLUtils.circumventBug2650internal(model, doc);
    }

    /**
     * This is the work horse for {@link #circumventBug2650}.
     *
     * @param node
     * @see <A HREF="https://issues.apache.org/jira/browse/XALANJ-334">Namespace axis resolution is not XPath compliant </A>
     */
    @SuppressWarnings("fallthrough")
    private static <N> void circumventBug2650internal(MutableModel<N> model, N node) {
        N parent = null;
        N sibling = null;
        do {
            switch ( model.getNodeKind(node)) {
            case ELEMENT:
                if (!model.hasChildren(node))
                    break;
             
                Map<String, String> prefixMap = getPrefixMapping(model, node);
             
                for (N child : model.getChildElements(node)) {
                 
                    Map<String, String> childPrefixes = getPrefixMapping(model, child);
                 
                    for ( Map.Entry<String, String> entry : prefixMap.entrySet()) {
                        if (!childPrefixes.containsKey(entry.getKey())) {
                            model.insertNamespace(child, entry.getKey(), entry.getValue());
                        }
                    }
                }
                parent = node;
                sibling = model.getFirstChild(node);
                break;
                //case ENTITY_REFERENCE_NODE :
            case DOCUMENT:
                parent = node;
                sibling = model.getFirstChild(node);
                break;
            default:
                break;
            }
            while ((sibling == null) && (parent != null)) {
                sibling = model.getNextSibling(parent);
                parent= model.getParent(parent);
            };
            if (sibling == null) {
                return;
            }
        
            node = sibling;
            sibling = model.getNextSibling(node);
        } while (true);
    }
    
    public static <N> Map<String, String> getPrefixMapping(Model<N> model, N elem) {
        
        Map<String, String> result = Collections.emptyMap();
        boolean isEmpty = true;
        for (NamespaceBinding nsb : model.getNamespaceBindings(elem)) {
            if (isEmpty) {
                result = new HashMap<String, String>();
                isEmpty = false;
            }
            
            result.put(nsb.getPrefix(), nsb.getNamespaceURI());
        }
        
        return result;
    }
    
    /**
     * Find the Nth child with the given local name that is in the digital signature space.
     * 
     * @param <N> Parameter for underlying tree type.
     * @param model  Access to the underlying tree
     * @param parent Scan the children of this parent node.
     * @param localName  The local name to search for.
     * @param nth    Which one?
     * 
     * @return The Nth matching element.
     */
    public static <N> N findNthDigSigChild(Model<N> model, N parent, String localName, int nth) {
        
        for (N node : model.getChildElementsByName(parent, Constants.SignatureSpecNS, localName)) {
            if (nth == 0) {
                return node;
            }
            nth--;
        }
        
        return null;
    }
    
    /**
     * @param model  Used to introspect the model
     * @param parent Parent node, whose children will be inspected
     * @param namespace  The namespace to match.
     * @param nodeName
     * @param number
     * 
     * @return A node matching the constraint, if any.
     */
    public static <N> N selectNthChildWithQName(Model<N> model, N parent, String namespace, String nodeName, int number) {
        
        N current = model.getFirstChildElementByName(parent, namespace, nodeName);
        while (current != null && number > 0) {
            number--;
            current = model.getNextSiblingElementByName(current, namespace, nodeName);
        }
        
        return current;
    }

    /**
     * @param sibling
     * @param nodeName
     * @param number
     * @return nodes with the constraint
     */
    public static <N> N selectDs11Node(Model<N> model, N sibling, String nodeName, int number) {
        while (sibling != null) {
            if (Constants.SignatureSpec11NS.equals(model.getNamespaceURI(sibling)) 
                && model.getLocalName(sibling).equals(nodeName)) {
                if (number == 0){
                    return sibling;
                }
                number--;
            }
            sibling = model.getNextSibling(sibling);
        }
        return null;
    }

    /**
     * @param sibling
     * @param nodeName
     * @param number
     * @return nodes with the constrain
     */
    public static <N> N selectXencNode(Model<N> model, N sibling, String nodeName, int number) {
        while (sibling != null) {
            if (EncryptionConstants.EncryptionSpecNS.equals(model.getNamespaceURI(sibling)) && model.getLocalName(sibling).equals(nodeName)) {
                if (number == 0){
                    return sibling;
                }
                number--;
            }
            sibling = model.getNextSibling(sibling);
        }
        return null;
    }


    /**
     * @param sibling
     * @param nodeName
     * @param number
     * @return nodes with the constrain
     */
    public static <N> N getNthDigSigChildNodeText(Model<N> model, N parent, String nodeName, int number) {
        N n = findNthDigSigChild(model, parent, nodeName, number);
         
        if (n != null) {
            // in theory we could simply call model.getStringValue(), but that does a recursive
            // descent that perhaps is not warranted.
             for (N possibleTextNode : model.getChildAxis(n)) {
                 if (model.getNodeKind(possibleTextNode) == NodeKind.TEXT) {
                     return possibleTextNode;
                 }
             }
         }
         return n;
    }
    
    /**
     * @param sibling
     * @param nodeName
     * @param number
     * @return nodes with the constrain
     */
    public static <N> N selectDs11NodeText(Model<N> model, N sibling, String nodeName, int number) {
        N n = selectDs11Node(model, sibling, nodeName, number);
        if (n == null) {
            return null;
        }
        n = model.getFirstChild(n);
        while (n != null && model.getNodeKind(n) != NodeKind.TEXT) {
            n = model.getNextSibling(n);
        }
        return n;
    }

    /**
     * @param sibling
     * @param uri
     * @param nodeName
     * @param number
     * @return nodes with the constrain
     */
    public static <N> N selectNodeText(Model<N> model, N sibling, String uri, String nodeName, int number) {
        N n = selectNode(model, sibling,uri,nodeName,number);
        if (n == null) {
            return null;
        }
        n = model.getFirstChild(n);
        while (n != null && NodeKind.TEXT != model.getNodeKind(n)) {
            n = model.getNextSibling(n);
        }
        return n;
    }

    /**
     * @param sibling
     * @param uri
     * @param nodeName
     * @param number
     * @return nodes with the constrain
     */
    public static <N> N selectNode(Model<N> model, N sibling, String uri,String nodeName, int number) {
        while (sibling != null) {
            String siblingNamespace = model.getNamespaceURI(sibling);
            if (siblingNamespace != null && siblingNamespace.equals(uri) && model.getLocalName(sibling).equals(nodeName)) {
                if (number == 0){
                    return sibling;
                }
                number--;
            }
            sibling = model.getNextSibling(sibling);
        }
        return null;
    }

    /**
     * @param model Access to underlying XML tree
     * @param parent Scan the children of this parent.
     * @param localName  Local name of XML digital signature elements to match.    
     * @return List of nodes in the XML digital signature namespace and the given local name.
     */
    public static <N> List<N> listChildDigSigElements(Model<N> model, N parent, String localName) {
        Iterable<N> matching = model.getChildElementsByName(parent,
                Constants.SignatureSpecNS, localName);
        return DomCompatibility.listFromIterable(matching);
    }

    /**
     * @param sibling
     * @param nodeName    
     * @return nodes with the constrain
     */
    public static <N> List<N> listDs11Nodes(Model<N> model, N sibling, String nodeName) {
        return selectNodes(model, sibling, Constants.SignatureSpec11NS, nodeName);
    }
    
    /**
     * @param sibling
     * @param uri
     * @param nodeName
     * @return nodes with the constrain
     */
     public static <N> List<N> selectNodes(Model<N> model, N sibling, String uri, String nodeName) {
        List<N> a = new ArrayList<N>();
        while (sibling!=null) {
            String siblingNamespace = model.getNamespaceURI(sibling);
            if (siblingNamespace != null && siblingNamespace.equals(uri) && model.getLocalName(sibling).equals(nodeName)) {
                a.add(sibling);
            }
            sibling=model.getNextSibling(sibling);
        }
        return a;
    }
    
    /**
     * Method getStrFromNode
     *
     * @param xpathnode
     * @return the string for the node.
     */
    public static String getStrFromNode(Node xpathnode) {
        if (xpathnode.getNodeType() == Node.TEXT_NODE) {
            // we iterate over all siblings of the context node because eventually,
            // the text is "polluted" with pi's or comments
            StringBuilder sb = new StringBuilder();

            for (Node currentSibling = xpathnode.getParentNode().getFirstChild();
                currentSibling != null;
                currentSibling = currentSibling.getNextSibling()) {
                if (currentSibling.getNodeType() == Node.TEXT_NODE) {
                    sb.append(((Text) currentSibling).getData());
                }
            }

            return sb.toString();
        } else if (xpathnode.getNodeType() == Node.ATTRIBUTE_NODE) {
            return ((Attr) xpathnode).getNodeValue();
        } else if (xpathnode.getNodeType() == Node.PROCESSING_INSTRUCTION_NODE) {
            return ((ProcessingInstruction) xpathnode).getNodeValue();
        }

        return null;
    }

    /**
     * Returns true if the descendantOrSelf is on the descendant-or-self axis
     * of the context node.
     *
     * @param ctx
     * @param descendantOrSelf
     * @return true if the node is descendant
     */
    static public <N> boolean isDescendantOrSelf(Model<N> bridge, N ctx, N descendantOrSelf) {
        if (ctx == descendantOrSelf) {
            return true;
        }

        N parent = descendantOrSelf;

        while (true) {
            if (parent == null) {
                return false;
            }

            if (parent == ctx) {
                return true;
            }

            parent = bridge.getParent(parent);
        }
    }


    public static <N> void removeAllChildren(MutableModel<N> model, N node) {
        // remove all the existing children...
        N n = model.getFirstChild(node);
        while (n!=null) {
            N nextSibling = model.getNextSibling(n);
            model.delete(n);
            n = nextSibling;
        }

    }

    public static boolean ignoreLineBreaks() {
        return ignoreLineBreaks;
    }
    

    /**
     * Method getStrFromNode
     *
     * @param xpathnode
     * @return the string for the node.
     */
    public static <N> String getStrFromNode(Model<N> model, N xpathnode) {
    
        NodeKind nodeKind = model.getNodeKind(xpathnode);
        if (nodeKind == NodeKind.TEXT) {
    
            // we iterate over all siblings of the context node because eventually,
            // the text is "polluted" with pi's or comments
            StringBuffer sb = new StringBuffer();
    
            for (N currentSibling = model.getFirstChild(model.getParent(xpathnode));
                    currentSibling != null;
                    currentSibling = model.getNextSibling(currentSibling) ) {
                if (model.getNodeKind(currentSibling) == NodeKind.TEXT) {
                    sb.append( model.getStringValue(currentSibling));
                }
            }
    
            return sb.toString();
        } else if (nodeKind == NodeKind.ATTRIBUTE || nodeKind == NodeKind.PROCESSING_INSTRUCTION) {
            return model.getStringValue(xpathnode);
        }
    
        return null;
    }

    /**
     * Returns the attribute value for the attribute with the specified name.
     * Returns null if there is no such attribute, or 
     * the empty string if the attribute value is empty.
     *
     * <p>This works around a limitation of the DOM
     * <code>Element.getAttributeNode</code> method, which does not distinguish
     * between an unspecified attribute and an attribute with a value of
     * "" (it returns "" for both cases).
     *
     * @param elem the element containing the attribute
     * @param name the name of the attribute
     * @return the attribute value (may be null if unspecified)
     */
    public static String getAttributeValue(Element elem, String name) {
        Attr attr = elem.getAttributeNodeNS(null, name);
        return (attr == null) ? null : attr.getValue();
    }
    
    /**
     * This method is a tree-search to help prevent against wrapping attacks. It checks that no
     * two Elements have ID Attributes that match the "value" argument, if this is the case then
     * "false" is returned. Note that a return value of "true" does not necessarily mean that
     * a matching Element has been found, just that no wrapping attack has been detected.
     */
    public static <N> boolean protectAgainstWrappingAttack(Model<N> model, N startNode, String value) {
        N startParent = model.getParent(startNode);
        N processedNode = null;
        N foundElement = null;
        
        String id = value.trim();
        if (id.charAt(0) == '#') {
            id = id.substring(1);
        }

        while (startNode != null) {
            if (model.getNodeKind(startNode) == NodeKind.ELEMENT) {
                N se = startNode;
                
                for (N attr : model.getAttributeAxis(se, false)) {
                    if (model.isId(attr) && id.equals(model.getStringValue(attr) ) ) {
                        if (foundElement == null) {
                            // Continue searching to find duplicates
                            foundElement = model.getParent(attr);
                        } else {
                            log.debug("Multiple elements with the same 'Id' attribute value!");
                            return false;
                        }
                    }
                }
            }

            processedNode = startNode;
            startNode = model.getFirstChild(startNode);

            // no child, this node is done.
            if (startNode == null) {
                // close node processing, get sibling
                startNode = model.getNextSibling(processedNode);
            }
            
            // no more siblings, get parent, all children
            // of parent are processed.
            while (startNode == null) {
                processedNode = model.getParent(processedNode);
                if (processedNode == startParent) {
                    return true;
                }
                // close parent node processing (processed node now)
                startNode = model.getNextSibling(processedNode);
            }
        }
        return true;
    }
    
    /**
     * This method is a tree-search to help prevent against wrapping attacks. It checks that no other
     * Element than the given "knownElement" argument has an ID attribute that matches the "value" 
     * argument, which is the ID value of "knownElement". If this is the case then "false" is returned.
     */
    public static <N> boolean protectAgainstWrappingAttack(Model<N> model,
        N startNode, N knownElement, String value
    ) {
        N startParent = model.getParent(startNode);
        N processedNode = null;
        
        String id = value.trim();
        if (id.charAt(0) == '#') {
            id = id.substring(1);
        }

        while (startNode != null) {
            if (model.getNodeKind(startNode) == NodeKind.ELEMENT) {
                N se = startNode;
                
                for (N attr: model.getAttributeAxis(se, false)) {
                    if (model.isId(attr) && id.equals(model.getStringValue(attr)) && se != knownElement) {
                        log.debug("Multiple elements with the same 'Id' attribute value!");
                        return false;
                    }
                }
            }

            processedNode = startNode;
            startNode = model.getFirstChild(startNode);

            // no child, this node is done.
            if (startNode == null) {
                // close node processing, get sibling
                startNode = model.getNextSibling(processedNode);
            }
            
            // no more siblings, get parent, all children
            // of parent are processed.
            while (startNode == null) {
                processedNode = model.getParent(processedNode);
                if (processedNode == startParent) {
                    return true;
                }
                // close parent node processing (processed node now)
                startNode = model.getNextSibling(processedNode);
            }
        }
        return true;
    }

}
