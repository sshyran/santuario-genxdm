package org.apache.xml.security.keys.keyresolver.implementations;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.crypto.SecretKey;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.X509Data;
import org.apache.xml.security.keys.content.x509.XMLX509Digest;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
import org.apache.xml.security.keys.storage.StorageResolver;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.w3c.dom.Element;

/**
 * KeyResolverSpi implementation which resolves public keys and X.509 certificates from a 
 * <code>dsig11:X509Digest</code> element.
 * 
 * @author Brent Putman (putmanb@georgetown.edu)
 */
public class X509DigestResolver extends KeyResolverSpi {

    /** {@link org.apache.commons.logging} logging facility */
    private static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(X509DigestResolver.class);

    /** {@inheritDoc}. */
    public <N> boolean engineCanResolve(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage) {
        if (XMLUtils.elementIsInSignatureSpace(ctx.model, element, Constants._TAG_X509DATA)) {
            try {
                X509Data<N> x509Data = new X509Data<N>(ctx.mutableModel, element, baseURI);
                return x509Data.containsDigest();
            } catch (XMLSecurityException e) {
                return false;
            }
        } else {
            return false;
        }
    }

    /** {@inheritDoc}. */
    public <N> PublicKey engineLookupAndResolvePublicKey(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {

        X509Certificate cert = this.engineLookupResolveX509Certificate(ctx, element, baseURI, storage);

        if (cert != null) {
            return cert.getPublicKey();
        }

        return null;
    }

    /** {@inheritDoc}. */
    public <N> X509Certificate engineLookupResolveX509Certificate(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {

        if (log.isDebugEnabled()) {
            log.debug("Can I resolve " + XMLUtils.getTagName(ctx.model, element));
        }

        if (!engineCanResolve(ctx, element, baseURI, storage)) {
            return null;
        }

        try {
            return resolveCertificate(ctx, element, baseURI, storage);
        } catch (XMLSecurityException e) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", e);
            }
        }

        return null;
    }

    /** {@inheritDoc}. */
    public <N> SecretKey engineLookupAndResolveSecretKey(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {
        return null;
    }

    @Override
    public <N> PrivateKey engineLookupAndResolvePrivateKey(XmlContext<N> ctx, N element,
            String baseURI, StorageResolver storage) throws KeyResolverException {
        return null;
    }

    /**
     * Resolves from the storage resolver the actual certificate represented by the digest.
     * 
     * @param element
     * @param baseURI
     * @param storage
     * @return
     * @throws XMLSecurityException
     */
    private <N> X509Certificate resolveCertificate(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage) 
        throws XMLSecurityException {

        List<XMLX509Digest<N>> x509Digests = null;

        List<N> x509childNodes = XMLUtils.listDs11Nodes(ctx.model, ctx.model.getFirstChild(element), Constants._TAG_X509DIGEST);

        if (x509childNodes == null || x509childNodes.size() <= 0) {
            return null;
        }

        try {         
            checkStorage(storage);

            x509Digests = new ArrayList<XMLX509Digest<N>>(x509childNodes.size());

            for (N child : x509childNodes) {
                x509Digests.add(new XMLX509Digest<N>(ctx.mutableModel, child, baseURI));
            }

            Iterator<Certificate> storageIterator = storage.getIterator();
            while (storageIterator.hasNext()) {
                X509Certificate cert = (X509Certificate) storageIterator.next();

                for (XMLX509Digest<N> keyInfoDigest : x509Digests) {
                    byte[] certDigestBytes = XMLX509Digest.getDigestBytesFromCert(cert, keyInfoDigest.getAlgorithm());

                    if (Arrays.equals(keyInfoDigest.getDigestBytes(), certDigestBytes)) {
                        if (log.isDebugEnabled()) {
                            log.debug("Found certificate with: " + cert.getSubjectX500Principal().getName());
                        }
                        return cert;
                    }

                }
            }

        } catch (XMLSecurityException ex) {
            throw new KeyResolverException("empty", ex);
        }

        return null;
    }

    /**
     * Method checkSrorage
     * 
     * @param storage
     * @throws KeyResolverException
     */
    private void checkStorage(StorageResolver storage) throws KeyResolverException {
        if (storage == null) {
            Object exArgs[] = { Constants._TAG_X509DIGEST };
            KeyResolverException ex = new KeyResolverException("KeyResolver.needStorageResolver", exArgs);
            if (log.isDebugEnabled()) {
                log.debug("", ex);
            }
            throw ex;
        }
    }

}
