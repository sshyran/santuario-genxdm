/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.keys.content;

import java.security.PublicKey;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
import org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.genxdm.mutable.MutableModel;

/**
 * The KeyValue element contains a single public key that may be useful in
 * validating the signature. Structured formats for defining DSA (REQUIRED)
 * and RSA (RECOMMENDED) public keys are defined in Signature Algorithms
 * (section 6.4). The KeyValue element may include externally defined public
 * keys values represented as PCDATA or element types from an external 
 * namespace.
 *
 * @author $Author: coheigea $
 */
public class KeyValue<N> extends SignatureElementProxy<N> implements KeyInfoContent {

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param dsaKeyValue
     */
    public KeyValue(MutableModel<N> model, N doc, DSAKeyValue<N> dsaKeyValue) {
        super(model, doc);

        addReturnToSelf();
        appendSelf(dsaKeyValue);
        addReturnToSelf();
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param rsaKeyValue
     */
    public KeyValue(MutableModel<N> model, N doc, RSAKeyValue<N> rsaKeyValue) {
        super(model, doc);

        addReturnToSelf();
        appendSelf(rsaKeyValue);
        addReturnToSelf();
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param unknownKeyValue
     */
    public KeyValue(MutableModel<N> model, N doc, N unknownKeyValue) {
        super(model, doc);

        addReturnToSelf();
        appendSelf(unknownKeyValue);
        addReturnToSelf();
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param pk
     */
    public KeyValue(MutableModel<N> model, N doc, PublicKey pk) {
        super(model, doc);

        addReturnToSelf();

        if (pk instanceof java.security.interfaces.DSAPublicKey) {
            DSAKeyValue<N> dsa = new DSAKeyValue<N>(model, getDocumentNode(), pk);
            appendSelf(dsa);
            addReturnToSelf();
        } else if (pk instanceof java.security.interfaces.RSAPublicKey) {
            RSAKeyValue<N> rsa = new RSAKeyValue<N>(model, getDocumentNode(), pk);
            appendSelf(rsa);
            addReturnToSelf();
        }
    }

    /**
     * Constructor KeyValue
     *
     * @param element
     * @param BaseURI
     * @throws XMLSecurityException
     */
    public KeyValue(MutableModel<N> model, N element, String BaseURI) throws XMLSecurityException {
        super(model, element, BaseURI);
    }

    /**
     * Method getPublicKey
     *
     * @return the public key
     * @throws XMLSecurityException
     */
    public PublicKey getPublicKey() throws XMLSecurityException {
        N rsa = model.getFirstChildElementByName(getElementNode(),
                Constants.SignatureSpecNS, Constants._TAG_RSAKEYVALUE);
                 
        if (rsa != null) {
            RSAKeyValue<N> kv = new RSAKeyValue<N>(model, rsa, this.baseURI);
            return kv.getPublicKey();
        }

        N dsa = model.getFirstChildElementByName(getElementNode(),
                Constants.SignatureSpecNS, Constants._TAG_DSAKEYVALUE);

        if (dsa != null) {
            DSAKeyValue<N> kv = new DSAKeyValue<N>(model, dsa, this.baseURI);
            return kv.getPublicKey();
        }

        return null;
    }

    /** @inheritDoc */
    public String getBaseLocalName() {
        return Constants._TAG_KEYVALUE;
    }
}
