/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.signature;

import java.util.List;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Handles <code>&lt;ds:SignatureProperties&gt;</code> elements
 * This Element holds {@link SignatureProperty} that contian additional information items
 * concerning the generation of the signature.
 * for example, data-time stamp, serial number of cryptographic hardware.
 *
 * @author Christian Geuer-Pollmann
 */
public class SignatureProperties<N> extends SignatureElementProxy<N> {

    /**
     * Constructor SignatureProperties
     *
     * @param doc
     */
    public SignatureProperties(MutableModel<N> model, N doc) {
        super(model, doc);

        addReturnToSelf();
    }

    /**
     * Constructor SignatureProperties
     *
     * @param doc
     * 
     * @deprecated New clients should use {@link #SignatureProperties(XmlContext, Object)}
     */
    @SuppressWarnings("unchecked")
    public SignatureProperties(Document doc) {
        this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc);
    }

    /**
     * Constructs {@link SignatureProperties} from {@link Element}
     * @param element <code>SignatureProperties</code> elementt
     * @param BaseURI the URI of the resource where the XML instance was stored
     * @throws XMLSecurityException
     */
    public SignatureProperties(MutableModel<N> model, N element, String BaseURI) throws XMLSecurityException {
        super(model, element, BaseURI);
        
        N attr = model.getAttribute(element, "", "Id");
        if (attr != null) {
            model.setIsIdAttribute(attr, true);
        }
        
        int length = getLength();
        for (int i = 0; i < length; i++) {
            N propertyElem =
                XMLUtils.findNthDigSigChild(model, getElementNode(), Constants._TAG_SIGNATUREPROPERTY, i);
            N propertyAttr = model.getAttribute(propertyElem, "", "Id");
            if (propertyAttr != null) {
                model.setIsIdAttribute(propertyAttr, true);
            }
        }
    }

    /**
     * Return the nonnegative number of added SignatureProperty elements.
     *
     * @return the number of SignatureProperty elements
     */
    public int getLength() {
        List<N> propertyElems = 
            XMLUtils.listChildDigSigElements(model, getElementNode(), Constants._TAG_SIGNATUREPROPERTY);

        return propertyElems.size();
    }

    /**
     * Return the <it>i</it><sup>th</sup> SignatureProperty. Valid <code>i</code>
     * values are 0 to <code>{link@ getSize}-1</code>.
     *
     * @param i Index of the requested {@link SignatureProperty}
     * @return the <it>i</it><sup>th</sup> SignatureProperty
     * @throws XMLSignatureException
     */
    public SignatureProperty<N> item(int i) throws XMLSignatureException {
        try {
            N propertyElem =
                XMLUtils.findNthDigSigChild(model, getElementNode(), Constants._TAG_SIGNATUREPROPERTY, i);

            if (propertyElem == null) {
                return null;
            } 
            return new SignatureProperty<N>(model, propertyElem, this.baseURI);               
        } catch (XMLSecurityException ex) {
            throw new XMLSignatureException("empty", ex);
        }
    }

    /**
     * Sets the <code>Id</code> attribute
     *
     * @param Id the <code>Id</code> attribute
     */
    public void setId(String Id) {
        if (Id != null) {
            setLocalIdAttribute(Constants._ATT_ID, Id);
        }
    }

    /**
     * Returns the <code>Id</code> attribute
     *
     * @return the <code>Id</code> attribute
     */
    public String getId() {
        return getLocalAttribute(Constants._ATT_ID);
    }

    /**
     * Method addSignatureProperty
     *
     * @param sp
     */
    public void addSignatureProperty(SignatureProperty<N> sp) {
        appendSelf(sp);
        addReturnToSelf();
    }

    /** @inheritDoc */
    public String getBaseLocalName() {
        return Constants._TAG_SIGNATUREPROPERTIES;
    }
}
