package org.apache.xml.security.utils;

/**
 * Utility class to safely load a class with generics.
 */
public class ClassUtil {

	public static <C> Class<? extends C> loadClass(String className, Class<C> ofType) throws ClassNotFoundException {
		
    	Class<?> loadedClass = Class.forName(className);
    	Class<? extends C> castClass = loadedClass.asSubclass(ofType);
    	return castClass;
	}
}
