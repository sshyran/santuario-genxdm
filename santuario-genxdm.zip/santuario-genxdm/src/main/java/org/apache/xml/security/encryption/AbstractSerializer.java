/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.encryption;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;

/**
 * Converts <code>String</code>s into <code>Node</code>s and visa versa.
 * 
 * An abstract class for common Serializer functionality
 */
public abstract class AbstractSerializer implements Serializer {
    
    protected Canonicalizer canon;
    
    public void setCanonicalizer(Canonicalizer canon) {
        this.canon = canon;
    }
    
    /**
     * Returns a <code>String</code> representation of the specified
     * <code>Element</code>.
     * <p/>
     * Refer also to comments about setup of format.
     *
     * @param element the <code>Element</code> to serialize.
     * @return the <code>String</code> representation of the serilaized
     *   <code>Element</code>.
     * @throws Exception
     */
    public <N> String serialize(Model<N> model, N element) throws Exception {
        return canonSerialize(model, element);
    }

    /**
     * Returns a <code>byte[]</code> representation of the specified
     * <code>Element</code>.
     *
     * @param element the <code>Element</code> to serialize.
     * @return the <code>byte[]</code> representation of the serilaized
     *   <code>Element</code>.
     * @throws Exception
     */
    public <N> byte[] serializeToByteArray(Model<N> model, N element) throws Exception {
        return canonSerializeToByteArray(model, element);
    }

    /**
     * Returns a <code>String</code> representation of the specified
     * <code>NodeList</code>.
     * <p/>
     * This is a special case because the NodeList may represent a
     * <code>DocumentFragment</code>. A document fragment may be a
     * non-valid XML document (refer to appropriate description of
     * W3C) because it my start with a non-element node, e.g. a text
     * node.
     * <p/>
     * The methods first converts the node list into a document fragment.
     * Special care is taken to not destroy the current document, thus
     * the method clones the nodes (deep cloning) before it appends
     * them to the document fragment.
     * <p/>
     * Refer also to comments about setup of format.
     * 
     * @param content the <code>NodeList</code> to serialize.
     * @return the <code>String</code> representation of the serialized
     *   <code>NodeList</code>.
     * @throws Exception
     */
    public <N> String serialize(Model<N> model, Iterable<N> content) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        canon.setWriter(baos);
        canon.notReset();
        for (N node : content) {
            canon.canonicalizeSubtree(model, node);                
        }
        String ret = baos.toString("UTF-8");
        baos.reset();
        return ret;
    }

    /**
     * Returns a <code>byte[]</code> representation of the specified
     * <code>NodeList</code>.
     * 
     * @param content the <code>NodeList</code> to serialize.
     * @return the <code>byte[]</code> representation of the serialized
     *   <code>NodeList</code>.
     * @throws Exception
     */
    public <N> byte[] serializeToByteArray(Model<N> model, Iterable<N> content) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        canon.setWriter(baos);
        canon.notReset();
        for (N node : content) {
            canon.canonicalizeSubtree(model, node);                
        }
        return baos.toByteArray();
    }

    /**
     * Use the Canonicalizer to serialize the node
     * @param node
     * @return the canonicalization of the node
     * @throws Exception
     */ 
    public <N> String canonSerialize(Model<N> model, N node) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        canon.setWriter(baos);                      
        canon.notReset();
        canon.canonicalizeSubtree(model, node);                    
        String ret = baos.toString("UTF-8");
        baos.reset();
        return ret;
    }

    /**
     * Use the Canonicalizer to serialize the node
     * @param node
     * @return the (byte[]) canonicalization of the node
     * @throws Exception
     */ 
    public <N> byte[] canonSerializeToByteArray(Model<N> model, N node) throws Exception {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        canon.setWriter(baos);
        canon.notReset();
        canon.canonicalizeSubtree(model, node);
        return baos.toByteArray();
    }

    /**
     * @param source
     * @param ctx
     * @return the Node resulting from the parse of the source
     * @throws XMLEncryptionException
     */
    public abstract <N> N deserialize(XmlContext<N> xmlCtx, String source, N ctx) throws XMLEncryptionException;

    /**
     * @param source
     * @param ctx
     * @return the Node resulting from the parse of the source
     * @throws XMLEncryptionException
     */
    public abstract <N> N deserialize(XmlContext<N> xmlCtx, byte[] source, N ctx) throws XMLEncryptionException;

    protected static <N> byte[] createContext(Model<N> model, byte[] source, N ctx) throws XMLEncryptionException {
        // Create the context to parse the document against
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(byteArrayOutputStream, "UTF-8");
            outputStreamWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?><dummy");

            // Run through each node up to the document node and find any xmlns: nodes
            Map<String, String> storedNamespaces = new HashMap<String, String>();
            N wk = ctx;
            while (wk != null) {
                for (N nsDecl : model.getNamespaceAxis(wk, false)) {
                    String prefix = model.getLocalName(nsDecl);
                    if (!storedNamespaces.containsKey(prefix)) {
                        String nsStr = model.getStringValue(nsDecl);
                        outputStreamWriter.write(" xmlns");
                        if (prefix.length() > 0) {
                            outputStreamWriter.write(":");
                            outputStreamWriter.write(prefix);
                        }
                        outputStreamWriter.write("=\"");
                        outputStreamWriter.write(nsStr);
                        outputStreamWriter.write("\"");
                        storedNamespaces.put(prefix, nsStr);
                    }
                }
                wk = model.getParent(wk);
            }
            outputStreamWriter.write(">");
            outputStreamWriter.flush();
            byteArrayOutputStream.write(source);

            outputStreamWriter.write("</dummy>");
            outputStreamWriter.close();

            return byteArrayOutputStream.toByteArray();
        } catch (UnsupportedEncodingException e) {
            throw new XMLEncryptionException("empty", e);
        } catch (IOException e) {
            throw new XMLEncryptionException("empty", e);
        }
    }
    
    protected static <N> String createContext(Model<N> model, String source, N ctx) {
        // Create the context to parse the document against
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><dummy");

        // Run through each node up to the document node and find any xmlns: nodes
        Map<String, String> storedNamespaces = new HashMap<String, String>();
        for (N wk : model.getAncestorOrSelfAxis(ctx)) {
            for (N nsDecl : model.getNamespaceAxis(wk, false)) {
                String prefix = model.getLocalName(nsDecl);
                String namespace = model.getStringValue(nsDecl);
                if (!storedNamespaces.containsKey(prefix)) {
                    sb.append(" xmlns");
                    if (prefix.length() > 0) {
                        sb.append(":");
                        sb.append(prefix);
                    }
                    sb.append("=\"" + namespace + "\"");
                    storedNamespaces.put(prefix, namespace);

                }
            }
        }
        sb.append(">" + source + "</dummy>");
        return sb.toString();
    }
    
}