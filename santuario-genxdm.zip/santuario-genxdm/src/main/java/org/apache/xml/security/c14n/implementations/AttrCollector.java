package org.apache.xml.security.c14n.implementations;

import java.util.Collection;
import java.util.TreeSet;

import org.genxdm.Model;

/**
 * This class exists to "collect" the attributes being output as part of
 * canonicalization.
 * 
 * <p>During the canonicalization process, it is sometimes necessary
 * to manufacture an attribute that doesn't exist at the specific place in
 * the tree. To that end, this "collector" contains two kinds of
 * objects - actual nodes in the tree, and implementations of {@link AttrInfo}
 * </p>
 */
public class AttrCollector<N> {

    public AttrCollector(Model<N> model) {
        m_model = model;
        m_attrs = new TreeSet<Object>(new AttrInfoComparator(model));
    }
    
    public void addAll(Collection<AttrInfo> attrs) {
        m_attrs.addAll(attrs);
    }
    
    public void use(Object attr) {
        // Note - we remove the attribute here in case we're pre-processing the collected
        // attributes and modifying them.
        // @see XMLAttrStackCanon11.getXmlnsAttr()
        m_attrs.remove(attr);
        m_attrs.add(attr);
    }
    
    public boolean hasAttributes() {
        return m_attrs.size() > 0;
    }
    
    public void reset() {
        m_attrs.clear();
    }
    
    public AttrCursor<N> iterate() {
        return new AttrCursor<N>(m_model, m_attrs.iterator());
    }

    private Model<N> m_model;
    
    private Collection<Object> m_attrs; 
}
