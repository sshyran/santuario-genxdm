package org.apache.xml.security.c14n.implementations;

import java.util.Iterator;

import org.genxdm.Model;

/**
 * When canonicalizing, this "cursor" interface allows
 * @author eric
 *
 */
public class AttrCursor<N> {

    public AttrCursor(Model<N> model, Iterator<Object> iter) {
        
        m_model = model;
        m_iter = iter;
    }
    
    public boolean toNext() {
        boolean result = m_iter.hasNext();
        if (result) {
            m_current = m_iter.next();
        }
        else {
            m_current = null;
        }
        return result;
    }
    
    public static <N> String getLocalName(Model<N> model, Object obj) {
        
        if (obj instanceof AttrInfo) {
            return ( (AttrInfo)obj).getLocalName();
        }
        else {
            @SuppressWarnings("unchecked")
            N node = (N) obj;
            return model.getLocalName(node);
        }
    }
    
    public String getLocalName() {
        return getLocalName(m_model, m_current);
    }
    
    private static <N> String getTagName(Model<N> model, Object obj) {
        
        if (obj instanceof AttrInfo) {
            return ( (AttrInfo)obj).getTagName();
        }
        else {
            @SuppressWarnings("unchecked")
            N node = (N) obj;
            String localName = model.getLocalName(node);
            if (model.isNamespace(node)) {
                return "".equals(localName) ? "xmlns" : "xmlns:" + localName; 
            }
            String prefix = model.getPrefix(node);
            if ("".equals(prefix)) {
                return localName;
            }
            else {
                StringBuilder sb = new StringBuilder(prefix);
                sb.append(':');
                sb.append(localName);
                return sb.toString();
            }
        }
    }
    
    public String getAttrQName() {
        return getTagName(m_model, m_current);
    }
    
    public static <N> String getAttrValue(Model<N> model, Object obj) {
        if (obj instanceof AttrInfo) {
            return ( (AttrInfo) obj).getValue();
        }
        else {
            @SuppressWarnings("unchecked")
            N node = (N) obj;
            return model.getStringValue(node);
        }
    }
    
    public String getAttrValue() {
        return getAttrValue(m_model, m_current);
    }

    public static <N> boolean isNamespace(Model<N> model, Object obj) {
        if (obj instanceof AttrInfo) {
            return ( (AttrInfo) obj).isNamespace();
        }
        else {
            @SuppressWarnings("unchecked")
            N node = (N) obj;
            return model.isNamespace(node);
        }
    }
    
    public static <N> String getNamespace(Model<N> model, Object obj) {
        if (obj instanceof AttrInfo) {
            return ( (AttrInfo) obj).getNamespace();
        }
        else {
            @SuppressWarnings("unchecked")
            N node = (N) obj;
            return model.getNamespaceURI(node);
        }
    }
    @SuppressWarnings("deprecation")
    public static Object getWrappedNode(Object obj) {
        if (obj instanceof AttrInfo) {
            return ( (AttrInfo) obj).getWrappedNode();
        }
        else {
            return obj;
        }
    }
    
    /**
     * Deprecated function to get the wrapped node underneath.
     * @deprecated 
     */
    public Object getWrappedNode() {
        return getWrappedNode(m_current);
    }
    
    private Model<N> m_model;
    
    private Object m_current = null;
    
    private Iterator<Object> m_iter;
}
