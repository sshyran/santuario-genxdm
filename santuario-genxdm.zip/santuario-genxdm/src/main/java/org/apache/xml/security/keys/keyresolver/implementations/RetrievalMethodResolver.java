/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.keys.keyresolver.implementations;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.RetrievalMethod;
import org.apache.xml.security.keys.content.x509.XMLX509Certificate;
import org.apache.xml.security.keys.keyresolver.GxKeyResolverSpi;
import org.apache.xml.security.keys.keyresolver.KeyResolver;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.keys.storage.StorageResolver;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.apache.xml.security.utils.resolver.ResourceResolver;
import org.genxdm.NodeKind;
import org.genxdm.Model;
import org.genxdm.io.DocumentHandler;
import org.xml.sax.SAXException;

/**
 * The RetrievalMethodResolver can retrieve public keys and certificates from
 * other locations. The location is specified using the ds:RetrievalMethod
 * element which points to the location. This includes the handling of raw
 * (binary) X.509 certificate which are not encapsulated in an XML structure.
 * If the retrieval process encounters an element which the
 * RetrievalMethodResolver cannot handle itself, resolving of the extracted
 * element is delegated back to the KeyResolver mechanism.
 *
 * @author $Author: raul $ modified by Dave Garcia
 */
public class RetrievalMethodResolver extends GxKeyResolverSpi {

    /** {@link org.apache.commons.logging} logging facility */
    private static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(RetrievalMethodResolver.class);

    /**
     * Method engineResolvePublicKey
     * @inheritDoc
     * @param element
     * @param baseURI
     * @param storage
     */
    public <N> PublicKey engineLookupAndResolvePublicKey(
           XmlContext<N> ctx, N element, String baseURI, StorageResolver storage
    ) {
        if (!XMLUtils.elementIsInSignatureSpace(ctx.model, element, Constants._TAG_RETRIEVALMETHOD)) {      
            return null;
        }

        try {
            // Create a retrieval method over the given element
            RetrievalMethod<N> rm = new RetrievalMethod<N>(ctx, element, baseURI);
            String type = rm.getType();		   
            XMLSignatureInput<N> resource = resolveInput(rm, baseURI, secureValidation);
            if (RetrievalMethod.TYPE_RAWX509.equals(type)) {
                // a raw certificate, direct parsing is done!
                X509Certificate cert = getRawCertificate(resource);
                if (cert != null) {
                    return cert.getPublicKey();
                }
                return null;
             }
             N e = obtainReferenceElement(resource);

             // Check to make sure that the reference is not to another RetrievalMethod
             // which points to this element
             if (XMLUtils.elementIsInSignatureSpace(ctx.model, e, Constants._TAG_RETRIEVALMETHOD)) {
                 if (secureValidation) {
                     String error = "Error: It is forbidden to have one RetrievalMethod "
                         + "point to another with secure validation";
                     if (log.isDebugEnabled()) {
                         log.debug(error);
                     }
                     return null;
                 }
                 RetrievalMethod<N> rm2 = new RetrievalMethod<N>(ctx, e, baseURI);
                 XMLSignatureInput<N> resource2 = resolveInput(rm2, baseURI, secureValidation);
                 N e2 = obtainReferenceElement(resource2);
                 if (e2 == element) {
                     if (log.isDebugEnabled()) {
                         log.debug("Error: Can't have RetrievalMethods pointing to each other");
                     }
                     return null;
                 }
             }
            
             return resolveKey(ctx, e, baseURI, storage);
         } catch (XMLSecurityException ex) {
             if (log.isDebugEnabled()) {
                 log.debug("XMLSecurityException", ex);
             }
         } catch (CertificateException ex) {
             if (log.isDebugEnabled()) {
                 log.debug("CertificateException", ex);
             }
         } catch (IOException ex) {
             if (log.isDebugEnabled()) {
                 log.debug("IOException", ex);
             }
         } catch (ParserConfigurationException e) {
             if (log.isDebugEnabled()) {
                 log.debug("ParserConfigurationException", e);
             }
         } catch (SAXException e) {
             if (log.isDebugEnabled()) {
                 log.debug("SAXException", e);
             }
         } 
         return null;
    }

    /**
     * Method engineResolveX509Certificate
     * @inheritDoc
     * @param element
     * @param baseURI
     * @param storage
     */
    public <N> X509Certificate engineLookupResolveX509Certificate(
        XmlContext<N> ctx, N element, String baseURI, StorageResolver storage) {
        if (!XMLUtils.elementIsInSignatureSpace(ctx.model, element, Constants._TAG_RETRIEVALMETHOD)) {      
             return null;
        }

        try {
            RetrievalMethod<N> rm = new RetrievalMethod<N>(ctx, element, baseURI);
            String type = rm.getType();		   
            XMLSignatureInput<N> resource = resolveInput(rm, baseURI, secureValidation);
            if (RetrievalMethod.TYPE_RAWX509.equals(type)) {
                return getRawCertificate(resource);
            }
            
            N e = obtainReferenceElement(resource);

            // Check to make sure that the reference is not to another RetrievalMethod
            // which points to this element
            if (XMLUtils.elementIsInSignatureSpace(ctx.model, e, Constants._TAG_RETRIEVALMETHOD)) {
                if (secureValidation) {
                    String error = "Error: It is forbidden to have one RetrievalMethod "
                        + "point to another with secure validation";
                    if (log.isDebugEnabled()) {
                        log.debug(error);
                    }
                    return null;
                }
                RetrievalMethod<N> rm2 = new RetrievalMethod<N>(ctx, e, baseURI);
                XMLSignatureInput<N> resource2 = resolveInput(rm2, baseURI, secureValidation);
                N e2 = obtainReferenceElement(resource2);
                if (e2 == element) {
                    if (log.isDebugEnabled()) {
                        log.debug("Error: Can't have RetrievalMethods pointing to each other");
                    }
                    return null;
                }
            }
            
            return resolveCertificate(ctx, e, baseURI, storage);
        } catch (XMLSecurityException ex) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", ex);
            }
        } catch (CertificateException ex) {
            if (log.isDebugEnabled()) {
                log.debug("CertificateException", ex);
            }
        } catch (IOException ex) {
            if (log.isDebugEnabled()) {
                log.debug("IOException", ex);
            }
        } catch (ParserConfigurationException e) {
            if (log.isDebugEnabled()) {
                log.debug("ParserConfigurationException", e);
            }
        } catch (SAXException e) {
            if (log.isDebugEnabled()) {
                log.debug("SAXException", e);
            }
        } 
        return null;
    }
   
    /**
     * Retrieves a x509Certificate from the given information
     * @param e
     * @param baseURI
     * @param storage
     * @return
     * @throws KeyResolverException 
     */
    private static <N> X509Certificate resolveCertificate(
        XmlContext<N> ctx, N e, String baseURI, StorageResolver storage
    ) throws KeyResolverException {
        if (log.isDebugEnabled()) {
            log.debug("Now we have a {" + ctx.model.getNamespaceURI(e) + "}"
                + ctx.model.getLocalName(e) + " Element");
        }
        // An element has been provided
        if (e != null) { 
            return KeyResolver.getX509Certificate(ctx, e, baseURI, storage);
        }
        return null;
    } 
   
    /**
     * Retrieves a PublicKey from the given information
     * @param e
     * @param baseURI
     * @param storage
     * @return
     * @throws KeyResolverException 
     */
    private static <N> PublicKey resolveKey(
        XmlContext<N> ctx, N e, String baseURI, StorageResolver storage
    ) throws KeyResolverException {
        if (log.isDebugEnabled()) {
            log.debug("Now we have a {" + ctx.model.getNamespaceURI(e) + "}"
                + ctx.model.getLocalName(e) + " Element");
        }
        // An element has been provided
        if (e != null) { 
            return KeyResolver.getPublicKey(ctx, e, baseURI, storage);
        }
        return null;
    }
    
    private static <N> N obtainReferenceElement(XMLSignatureInput<N> resource)
        throws CanonicalizationException, ParserConfigurationException, 
        IOException, SAXException, KeyResolverException {
        N e;
        if (resource.isElement()){
            e = resource.getSubNodeN();
        } else if (resource.isNodeSet()) {
            // Retrieved resource is a nodeSet
            e = getDocumentElement(resource.getContext().model, resource.getNodeSet());							   
        } else {
            // Retrieved resource is an inputStream
            byte inputBytes[] = resource.getBytes();
            e = getDocFromBytes(resource.getContext(), inputBytes);
            // otherwise, we parse the resource, create an Element and delegate
            if (log.isDebugEnabled()) {
                log.debug("we have to parse " + inputBytes.length + " bytes");
            }
        }
        return e;
    }

    private static <N> X509Certificate getRawCertificate(XMLSignatureInput<N> resource)
        throws CanonicalizationException, IOException, CertificateException {
        byte inputBytes[] = resource.getBytes();	   
        // if the resource stores a raw certificate, we have to handle it
        CertificateFactory certFact = 
            CertificateFactory.getInstance(XMLX509Certificate.JCA_CERT_ID);
        X509Certificate cert = (X509Certificate) 
            certFact.generateCertificate(new ByteArrayInputStream(inputBytes));
        return cert;
    }

    /**
     * Resolves the input from the given retrieval method 
     * @return
     * @throws XMLSecurityException 
     */
    private static <N> XMLSignatureInput<N> resolveInput(
        RetrievalMethod<N> rm, String baseURI, boolean secureValidation
    ) throws XMLSecurityException {
        N uri = rm.getURIAttrNode();
        // Apply the transforms
        Transforms<N> transforms = rm.getTransforms();
        ResourceResolver resRes = ResourceResolver.getInstance(rm.getContext(), uri, baseURI, secureValidation);
        XMLSignatureInput<N> resource = resRes.resolve(rm.getContext(), uri, baseURI, secureValidation);
        if (transforms != null) {
            if (log.isDebugEnabled()) {
                log.debug("We have Transforms");
            }
            resource = transforms.performTransforms(resource);
        }		  
        return resource;
    }
   
    /**
     * Parses a byte array and returns the parsed Element.
     *
     * @param bytes
     * @return the Document Element after parsing bytes 
     * @throws KeyResolverException if something goes wrong
     */
    private static <N> N getDocFromBytes(XmlContext<N> ctx, byte[] bytes) throws KeyResolverException {
        try {
            DocumentHandler<N> docHandler = ctx.docHandlerFactory.newDocumentHandler();
            XMLUtils.ensureSecureProcessing(docHandler);
            N doc = docHandler.parse(new ByteArrayInputStream(bytes), null);
            return ctx.model.getFirstChildElement(doc);
        } catch (IOException ex) {
            throw new KeyResolverException("empty", ex);
        }
    }

    /**
     * Method engineResolveSecretKey
     * @inheritDoc
     * @param element
     * @param baseURI
     * @param storage
     */
    public <N> javax.crypto.SecretKey engineLookupAndResolveSecretKey(
        XmlContext<N> ctx, N element, String baseURI, StorageResolver storage
    ) {
        return null;
    }
   
    private static <N> N getDocumentElement(Model<N> model, Set<N> set) {
        N e = null;
        for (N currentNode : set) {
            if (currentNode != null && NodeKind.ELEMENT == model.getNodeKind(currentNode)) {
                e = currentNode;
                break;
            }
        }
        List<N> parents = new ArrayList<N>();
                
        // Obtain all the parents of the elemnt
        while (e != null) {
            parents.add(e);
  			N n = model.getParent(e);
  			if (n == null || NodeKind.ELEMENT != model.getNodeKind(n)) {
                break;
            }
            e = n;
        }
        // Visit them in reverse order.
        ListIterator<N> it2 = parents.listIterator(parents.size()-1);
        N ele = null;
        while (it2.hasPrevious()) {
            ele = it2.previous();
            if (set.contains(ele)) {
                return ele;
            }
        }
        return null;
    }
}
