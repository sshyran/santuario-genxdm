/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.transforms.implementations;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.Transform;
import org.apache.xml.security.transforms.TransformSpi;
import org.apache.xml.security.transforms.TransformationException;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.transforms.params.XPath2FilterContainer;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.genxdm.xpath.v10.ExprException;
import org.genxdm.xpath.v10.ExprParseException;
import org.genxdm.xpath.v10.NodeDynamicContextBuilder;
import org.genxdm.xpath.v10.NodeIterator;
import org.genxdm.xpath.v10.NodeSetExpr;
import org.genxdm.xpath.v10.StaticContext;
import org.genxdm.xpath.v10.XPathCompiler;
import org.genxdm.xpath.v10.XPathToolkit;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Implements the <I>XML Signature XPath Filter v2.0</I>
 *
 * @see <A HREF="http://www.w3.org/TR/xmldsig-filter2/">XPath Filter v2.0 (TR)</A>
 */
public class TransformXPath2Filter extends TransformSpi {

    /** Field implementedTransformURI */
    public static final String implementedTransformURI =
        Transforms.TRANSFORM_XPATH2FILTER;
    
    /**
     * Method engineGetURI
     *
     * @inheritDoc
     */
    protected String engineGetURI() {
        return implementedTransformURI;
    }

    /**
     * Method enginePerformTransform
     * @inheritDoc
     * @param input
     *
     * @throws TransformationException
     */
   	protected <N> XMLSignatureInput<N> enginePerformTransform(
        XMLSignatureInput<N> input, OutputStream os, Transform<N> transformObject
    ) throws TransformationException {
        try {
            Collection<Collection<N>> unionNodes = new ArrayList<Collection<N>>();
            Collection<Collection<N>> subtractNodes = new ArrayList<Collection<N>>();
            Collection<Collection<N>> intersectNodes = new ArrayList<Collection<N>>();

            XmlContext<N> ctx = input.getContext();
            XPathToolkit toolkit = XPathHelper.getXPathToolkitWithHereFunction();
   		
            List<N> xpathElements = XMLUtils.selectNodes(ctx.model,
                ctx.model.getFirstChild(transformObject.getElementNode()),
                    XPath2FilterContainer.XPathFilter2NS,
                    XPath2FilterContainer._TAG_XPATH2
                );
   	        if (xpathElements.size() == 0) {
                Object exArgs[] = { Transforms.TRANSFORM_XPATH2FILTER, "XPath" };

                throw new TransformationException("xml.WrongContent", exArgs);
            }

   	        N inputDoc = null;
   	        if (input.getSubNodeN() != null) {   
   	            inputDoc = XMLUtils.getOwnerDocument(ctx.model, input.getSubNodeN());
   	        } else {
   	            inputDoc = XMLUtils.getOwnerDocument(ctx.model, input.getNodeSet());
   	        }

   	        for (N xpathElement : xpathElements) {
   	            XPath2FilterContainer<N> xpathContainer =
   	                XPath2FilterContainer.newInstance(ctx.mutableModel, xpathElement,
                                                   	input.getSourceURI());

   	            XPathCompiler compiler = toolkit.newXPathCompiler();
   	            StaticContext staticArgs = toolkit.newExprContextStaticArgs();
                
   	            XPathHelper.declareNamespacesFromContextNode(ctx.model, xpathElement, staticArgs);
   	            NodeDynamicContextBuilder<N> dynArgs = toolkit.newExprContextDynamicArgs();

   	            XPathHelper.bindHereNode(ctx.model, xpathElement, dynArgs);
   	    		
   	            String expr = XMLUtils.getStrFromNode(ctx.model, xpathContainer.getXPathFilterTextN() );

   	            NodeSetExpr nodeSetExpr = compiler.compileNodeSetExpr(expr, staticArgs ); 
   	            NodeIterator<N> resultIterator = nodeSetExpr.nodeIterator(ctx.model, inputDoc, dynArgs.build());
   	            Collection<N> results = XPathHelper.nodeIteratorIntoCollection(resultIterator, new ArrayList<N>() );
   	    		
//   	    		NodeList subtreeRoots = xPathFuncHereAPI.selectNodeList(inputDoc,
//                                       xpathContainer.getXPathFilterTextN(),
//                                       expr,
//                                       xpathContainer.getElementNode());
//   	    		List<N> subtreeRootsList = (List<N>) XMLUtils.nodeListToList(subtreeRoots);
//   	    		if (subtreeRootsList.size() != results.size() ) {
//   	    			throw new IllegalStateException("Expected to have a size match.");
//   	    		}
   	    		
   	            if (xpathContainer.isIntersect()) {
   	                intersectNodes.add(results);
   	            } else if (xpathContainer.isSubtract()) {
   	                subtractNodes.add(results);
   	            } else if (xpathContainer.isUnion()) {
   	                unionNodes.add(results);
   	            } 
   	        }

         
   	        input.addNodeFilter(new XPath2NodeFilter<N>(unionNodes, subtractNodes,intersectNodes));
   	        input.setNodeSet(true);
   	        return input;
//      } catch (TransformerException ex) {
//         throw new TransformationException("empty", ex);
        } catch (DOMException ex) {
            throw new TransformationException("empty", ex);
        } catch (CanonicalizationException ex) {
            throw new TransformationException("empty", ex);
        } catch (InvalidCanonicalizerException ex) {
            throw new TransformationException("empty", ex);
        } catch (XMLSecurityException ex) {
            throw new TransformationException("empty", ex);
        } catch (SAXException ex) {
            throw new TransformationException("empty", ex);
        } catch (IOException ex) {
            throw new TransformationException("empty", ex);
        } catch (ParserConfigurationException ex) {
            throw new TransformationException("empty", ex);
      } catch (ExprParseException ex) {
          throw new TransformationException("empty", ex);
      } catch (ExprException ex) {
          throw new TransformationException("empty", ex);
        }
    }
   	
   	static Set<Node> convertNodeListToSet(List<NodeList> l){
   	    Set<Node> result=new HashSet<Node>();
   	    for (int j=0;j<l.size();j++) {
   	        NodeList rootNodes = l.get(j);	   
   	        int length = rootNodes.getLength();

   	        for (int i = 0; i < length; i++) {
   	            Node rootNode = rootNodes.item(i);
   	            result.add(rootNode);
	            
   	        }

   	    }
   	    return result;
   	}
}

class XPath2NodeFilter<N> implements NodeFilter<N> {
    
    boolean hasUnionFilter;
    boolean hasSubtractFilter;
    boolean hasIntersectFilter;
    Set<N> unionNodes;
    Set<N> subtractNodes;
    Set<N> intersectNodes;
    int inSubtract = -1;
    int inIntersect = -1;
    int inUnion = -1;
    
    XPath2NodeFilter(Collection<Collection<N>> unionNodes, Collection<Collection<N>> subtractNodes,
                     Collection<Collection<N>> intersectNodes) {
        hasUnionFilter = !unionNodes.isEmpty();
        this.unionNodes = convertNodeListToSet(unionNodes);
        hasSubtractFilter = !subtractNodes.isEmpty();
        this.subtractNodes = convertNodeListToSet(subtractNodes);
        hasIntersectFilter = !intersectNodes.isEmpty();
        this.intersectNodes = convertNodeListToSet(intersectNodes);
    }

    /**
     * @see org.apache.xml.security.signature.NodeFilter#isNodeInclude(org.w3c.dom.Node)
     */
    public int isNodeInclude(Model<N> bridge, N currentNode) {	 
        int result = 1;

        if (hasSubtractFilter && rooted(bridge, currentNode, subtractNodes)) {
            result = -1;
        } else if (hasIntersectFilter && !rooted(bridge, currentNode, intersectNodes)) {
            result = 0;
        }

        //TODO OPTIMIZE
        if (result == 1) {     	        
            return 1;
        }
        if (hasUnionFilter) { 
            if (rooted(bridge, currentNode, unionNodes)) {
                return 1;
            }
            result = 0;
        }    	
        return result;
    }
    
    public int isNodeIncludeDO(Model<N> bridge, N n, int level) {
        int result = 1;
        if (hasSubtractFilter) {
            if ((inSubtract == -1) || (level <= inSubtract)) {
                if (inList(n, subtractNodes)) {
                    inSubtract = level;
                } else {
                    inSubtract = -1;   			   
                }		   
            } 
            if (inSubtract != -1){
                result = -1;
            }
        } 
        if (result != -1 && hasIntersectFilter 
            && ((inIntersect == -1) || (level <= inIntersect))) { 
            if (!inList(n, intersectNodes)) {
                inIntersect = -1;
                result = 0;
            } else {
                inIntersect = level;   			   
            }		   
        }

        if (level <= inUnion) {
            inUnion = -1;
        }
        if (result == 1) {     	        
            return 1;
        }
        if (hasUnionFilter) {
            if ((inUnion == -1) && inList(n, unionNodes)) {
                inUnion = level;
            }
            if (inUnion != -1) {
                return 1;
            }
            result=0;
        }

        return result;
    }

    /**
     * Method rooted
     * @param currentNode 
     * @param nodeList 
     *
     * @return if rooted bye the rootnodes
     */
    static <N> boolean rooted(Model<N> bridge, N currentNode, Set<N> nodeList) {
        if (nodeList.isEmpty()) {
            return false;
        }
        if (nodeList.contains(currentNode)) {
            return true;
        }
        for (N rootNode : nodeList) {
            if (XMLUtils.isDescendantOrSelf(bridge, rootNode, currentNode)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method rooted
     * @param currentNode 
     * @param nodeList 
     *
     * @return if rooted bye the rootnodes
     */
    static <N> boolean inList(N currentNode, Set<N> nodeList ) {
        return nodeList.contains(currentNode);
    }
    
    private static <N> Set<N> convertNodeListToSet(Collection<Collection<N>> l) {
        Set<N> result = new HashSet<N>();
        for (Collection<N> rootNodes : l) {
            for (N rootNode : rootNodes) {
                result.add(rootNode);
            }
        }
        return result;
    }
}
