/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.c14n.implementations;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.helper.C14nHelper;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.XMLUtils;
import org.genxdm.Model;
import org.genxdm.mutable.MutableModel;

/**
 * Implements <A HREF="http://www.w3.org/TR/2008/PR-xml-c14n11-20080129/">
 * Canonical XML Version 1.1</A>, a W3C Proposed Recommendation from 29 
 * January 2008.
 *
 * @author Sean Mullan
 * @author Raul Benito
 */
public abstract class Canonicalizer11 extends CanonicalizerBase {
    
    private XmlAttrStackCanon11 xmlattrStack = new XmlAttrStackCanon11();
    private boolean firstCall = true;

    /**
     * Constructor Canonicalizer11
     *
     * @param includeComments
     */
    public Canonicalizer11(boolean includeComments) {
        super(includeComments);
    }

    /**
     * Always throws a CanonicalizationException because this is inclusive c14n.
     *
     * @param xpathNodeSet
     * @param inclusiveNamespaces
     * @return none it always fails
     * @throws CanonicalizationException always
     */
    public <N> byte[] engineCanonicalizeXPathNodeSet(
        Model<N> model, Set<N> xpathNodeSet, String inclusiveNamespaces
    ) throws CanonicalizationException {
        throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
    }

    /**
     * Always throws a CanonicalizationException because this is inclusive c14n.
     *
     * @param rootNode
     * @param inclusiveNamespaces
     * @return none it always fails
     * @throws CanonicalizationException
     */
    public byte[] engineCanonicalizeSubTree(
        Node rootNode, String inclusiveNamespaces
    ) throws CanonicalizationException {
        throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
    }
    
    /**
     * Always throws a CanonicalizationException because this is inclusive c14n.
     * 
     * @param rootNode
     * @param inclusiveNamespaces
     * @return none it always fails
     * @throws CanonicalizationException
     */
    @Override
    public <N> byte[] engineCanonicalizeSubTree(Model<N> bridge, N rootNode, String inclusiveNamespaces)
            throws CanonicalizationException {
        throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
    }

    /**
     * Returns the Attr[]s to be output for the given element.
     * <br>
     * The code of this method is a copy of {@link #handleAttributes(Element,
     * NameSpaceSymbTable)},
     * whereas it takes into account that subtree-c14n is -- well -- 
     * subtree-based.
     * So if the element in question isRoot of c14n, it's parent is not in the
     * node set, as well as all other ancestors.
     * @param ns
     * @param element
     *
     * @throws CanonicalizationException
     */
    @Override
    protected <N> void handleAttributesSubtree(Model<N> bridge, N E, NameSpaceSymbTable<N> ns, AttrCollector<N> attrCol)
        throws CanonicalizationException {
        if (!bridge.hasAttributes(E) && !bridge.hasNamespaces(E) && !firstCall) {
            return; 
        }
    
        for (N attr : bridge.getAttributeAxis(E, false)) {
            attrCol.use(attr);
        }

        for (N nsDecl : bridge.getNamespaceAxis(E, false)) {

            String NName = bridge.getLocalName(nsDecl);
            String NValue = bridge.getStringValue(nsDecl);
            if (XML.equals(NName) && XMLConstants.XML_NS_URI.equals(NValue)) {
                    // The default mapping for xml must not be output.
                continue;
            }
    
            Object n = ns.addMappingAndRenderAttr(bridge, NName, NValue, nsDecl);

            if (n != null) {
                // Render the ns definition
                attrCol.use(n);
                if (C14nHelper.namespaceIsRelative(bridge, nsDecl)) {
                    Object exArgs[] = { XMLUtils.getTagName(bridge, E), NName,
                            bridge.getStringValue(nsDecl) };
                    throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace",
                            exArgs);
                }
            }
        }

        if (firstCall) {
            // It is the first node of the subtree
            // Obtain all the namespaces defined in the parents, and added to the output.
            ns.getUnrenderedNodeWrappers(attrCol);
            // output the attributes in the xml namespace.
            xmlattrStack.getXmlnsAttr(attrCol);
            firstCall = false;
        } 
    }

    /**
     * Returns the Attr[]s to be output for the given element.
     * <br>
     * IMPORTANT: This method expects to work on a modified DOM tree, i.e. a 
     * DOM which has been prepared using 
     * {@link org.apache.xml.security.utils.XMLUtils#circumventBug2650(
     * MutableModel, Object)}.
     * @param ns
     * @param element
     * 
     * @throws CanonicalizationException
     */
    @Override
    protected <N> void handleAttributes(Model<N> bridge, N element, NameSpaceSymbTable<N> ns, Set<N> xpathNodeSet,
            List<NodeFilter<N>> nodeFilter, AttrCollector<N> attrCol)
        throws CanonicalizationException {    
        // result will contain the attrs which have to be output
        xmlattrStack.push(ns.getLevel());
        boolean isRealVisible = isVisibleDO(bridge, element, ns.getLevel(), xpathNodeSet, nodeFilter) == 1;
        
        for (N attr : bridge.getAttributeAxis(element, false)) {
            String NUri = bridge.getNamespaceURI(attr);
    
                    //A non namespace definition node.
            if (XMLConstants.XML_NS_URI.equals(NUri)) {
                if (bridge.getLocalName(attr).equals("id")) {
                    if (isRealVisible) {
                        // treat xml:id like any other attribute 
                        // (emit it, but don't inherit it)
                        attrCol.use(attr);
                    }
                } else {
                    xmlattrStack.addXmlnsAttr( AttrInfo.createAttribute(bridge, attr) );
                }
            } else if (isRealVisible) {
                // The node is visible add the attribute to the list of
                // output attributes.
                attrCol.use(attr);
            } 
        }
        N xmlnsDecl = null;

        for (N nsDecl : bridge.getNamespaceAxis(element, false)) {

            String NName = bridge.getLocalName(nsDecl);
            if (NName.length() == 0) {
                xmlnsDecl = nsDecl;
            }
            String NValue = bridge.getStringValue(nsDecl);
            if ("xml".equals(NName) && XMLConstants.XML_NS_URI.equals(NValue)) {
                /*
                 * except omit namespace node with local name xml, which defines
                     * the xml prefix, if its string value is 
                     * http://www.w3.org/XML/1998/namespace.
                     */
                continue;
            }
                    // add the prefix binding to the ns symb table.
            // ns.addInclusiveMapping(NName,NValue,N,isRealVisible);
            if (isVisible(bridge, nsDecl, xpathNodeSet, nodeFilter)) {
                if (!isRealVisible && ns.removeMappingIfRender(NName)) {
                    continue;
                }
                // The xpath select this node output it if needed.
                // Node n = ns.addMappingAndRenderXNodeSet
                // (NName, NValue, N, isRealVisible);
                Object n = ns.addMappingAndRenderAttr(bridge, NName, NValue, nsDecl);
                if (n != null) {
                    attrCol.use(n);
                    if (C14nHelper.namespaceIsRelative(bridge, nsDecl)) {
                        Object exArgs[] = { XMLUtils.getTagName(bridge, element), NName,
                                bridge.getStringValue(nsDecl) };
                        throw new CanonicalizationException("c14n.Canonicalizer.RelativeNamespace",
                                exArgs);
                    }
                }
            } else {
                if (isRealVisible && NName != "") {
                            ns.removeMapping(NName);    
                } else {
                    ns.addMapping(bridge, NName, NValue, nsDecl);
                }
            }
        }
        if (isRealVisible) {                      
            //The element is visible, handle the xmlns definition        
            Object n = null;
            if (xmlnsDecl == null) {
                //No xmlns def just get the already defined.
                n = ns.getMappingWrap("");
            } else if (!isVisible(bridge, xmlnsDecl, xpathNodeSet, nodeFilter)) {
                //There is a definition but the xmlns is not selected by the xpath.
                //then xmlns=""
                n = ns.addMappingAndRenderAttr(bridge, "", "", null);
            }
            //output the xmlns def if needed.
            if (n != null) {
                attrCol.use(n);
            }
            //Float all xml:* attributes of the unselected parent elements to this one. 
            xmlattrStack.getXmlnsAttr(attrCol);
            ns.getUnrenderedNodeWrappers(attrCol);
        }
    }

    @Override
    protected <N> void circumventBugIfNeeded(XMLSignatureInput<N> input)
        throws CanonicalizationException, ParserConfigurationException,
        IOException, SAXException {
        if (!input.isNeedsToBeExpanded()) {
            return;
        }
        MutableModel<N> model = input.getContext().mutableModel;
        N doc = null;
        if (input.getSubNodeN() != null) {
            doc = XMLUtils.getOwnerDocument(model, input.getSubNodeN());
        } else {
            doc = XMLUtils.getOwnerDocument(model, input.getNodeSet());
        }
        XMLUtils.circumventBug2650(model, doc);
    }

    @Override
    protected <N> void handleParent(Model<N> model, N e, NameSpaceSymbTable<N> ns) {
        if (!model.hasAttributes(e) && !model.hasNamespaces(e) && "".equals(model.getNamespaceURI(e)) ) {
            return;
        }
        
        xmlattrStack.push(-1);
            
        for (N nsDecl : model.getNamespaceAxis(e, false)) {
            String NName = model.getLocalName(nsDecl);
            String NValue = model.getStringValue(nsDecl);
            if (XML.equals(NName) && XMLConstants.XML_NS_URI.equals(NValue)) {
                continue;
            }
            ns.addMapping(model, NName, NValue, nsDecl);
        }

        for (N attr : model.getAttributeAxis(e, false)) {

            if (!"id".equals(model.getLocalName(attr)) && XMLConstants.XML_NS_URI.equals(model.getNamespaceURI(attr))) {
                xmlattrStack.addXmlnsAttr(AttrInfo.createAttribute(model,attr) );
            }
        }

        if (!"".equals(model.getNamespaceURI(e)) ) {
            ns.addMapping(model, model.getPrefix(e), model.getNamespaceURI(e), null);
        }
    }
}
