/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.c14n.implementations;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.helper.C14nHelper;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.XMLUtils;
import org.genxdm.Model;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * Implements <A HREF="http://www.w3.org/TR/2001/REC-xml-c14n-20010315">Canonical
 * XML Version 1.0</A>, a W3C Recommendation from 15 March 2001.
 *
 * @author Christian Geuer-Pollmann <geuerp@apache.org>
 */
public abstract class Canonicalizer20010315 extends CanonicalizerBase {
    private boolean firstCall = true;

    private XmlAttrStack xmlattrStack = new XmlAttrStack();

    /**
     * Constructor Canonicalizer20010315
     *
     * @param includeComments
     */
    public Canonicalizer20010315(boolean includeComments) {
        super(includeComments);
    }
    
    /**
     * Always throws a CanonicalizationException because this is inclusive c14n.
     *
     * @param rootNode
     * @param inclusiveNamespaces
     * @return none it always fails
     * @throws CanonicalizationException
     */
    @Override
    public <N> byte[] engineCanonicalizeSubTree(Model<N> bridge, N rootNode, String inclusiveNamespaces)
        throws CanonicalizationException {

        /** $todo$ well, should we throw UnsupportedOperationException ? */
        throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
    }

    /**
     * Always throws a CanonicalizationException because this is inclusive c14n.
     *
     * @param rootNode
     * @param inclusiveNamespaces
     * @return none it always fails
     * @throws CanonicalizationException
     */
    public byte[] engineCanonicalizeSubTree(Node rootNode, String inclusiveNamespaces)
        throws CanonicalizationException {

        /** $todo$ well, should we throw UnsupportedOperationException ? */
        throw new CanonicalizationException("c14n.Canonicalizer.UnsupportedOperation");
    }

    /**
     * Returns the Attr[]s to be output for the given element.
     * <br>
     * The code of this method is a copy of {@link #handleAttributes(Element,
     * NameSpaceSymbTable)},
     * whereas it takes into account that subtree-c14n is -- well -- subtree-based.
     * So if the element in question isRoot of c14n, it's parent is not in the
     * node set, as well as all other ancestors.
     * @param ns
     * @param element
     *
     * @throws CanonicalizationException
     */
    @Override
    protected <N> void handleAttributesSubtree(Model<N> bridge, N element, NameSpaceSymbTable<N> ns, AttrCollector<N> attrCol)
        throws CanonicalizationException {
        if (!bridge.hasAttributes(element) && !bridge.hasNamespaces(element) && !firstCall) {
            return; 
        }
        // Loop through namespace declarations.
        for (N nsDecl : bridge.getNamespaceAxis(element, false)) {
    
            String prefix = bridge.getLocalName(nsDecl);
            String namespaceStr = bridge.getStringValue(nsDecl);        
            if (XML.equals(prefix)
                    && XMLConstants.XML_NS_URI.equals(namespaceStr)) {
                    //The default mapping for xml must not be output.
                continue;
            }
        
            Object n = ns.addMappingAndRenderAttr(bridge, prefix, namespaceStr, nsDecl);                  
             
            if (n != null) {
                //Render the ns definition
                attrCol.use(n);
                if (C14nHelper.namespaceIsRelative(bridge, nsDecl)) {
                    Object exArgs[] = { XMLUtils.getTagName(bridge, element), prefix,
                            bridge.getStringValue(nsDecl) };
                            throw new CanonicalizationException(
                                "c14n.Canonicalizer.RelativeNamespace", exArgs
                            );
                }
            }
        }

        for (N attr : bridge.getAttributeAxis(element, false)) {
            attrCol.use( attr );
        }
                   
        if (firstCall) {
            //It is the first node of the subtree
            //Obtain all the namespaces defined in the parents, and added to the output.
            ns.getUnrenderedNodeWrappers(attrCol);
            //output the attributes in the xml namespace.
            xmlattrStack.getXmlnsAttr(bridge, attrCol);
            firstCall = false;
        } 
    }

    /**
     * Returns the Attr[]s to be output for the given element.
     * <br>
     * IMPORTANT: This method expects to work on a modified DOM tree, i.e. a DOM which has
     * been prepared using {@link org.apache.xml.security.utils.XMLUtils#circumventBug2650(
     * MutableModel, Object)}.
     * @param ns
     * @param element
     * 
     * @throws CanonicalizationException
     */
    @Override
    protected <N> void handleAttributes(Model<N> bridge, N element, NameSpaceSymbTable<N> ns,
            Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter, AttrCollector<N> attrCol) throws CanonicalizationException {    
        // result will contain the attrs which have to be output
        xmlattrStack.push(ns.getLevel());
        boolean isRealVisible = isVisibleDO(bridge, element, ns.getLevel(), xpathNodeSet, nodeFilter) == 1;
    
        for (N attr : bridge.getAttributeAxis(element, false)) {
            String NUri = bridge.getNamespaceURI(attr);
    
            // explicitly add any "xml:*" attributes to the attribute stack.
            if (XMLConstants.XML_NS_URI.equals(NUri)) {
                xmlattrStack.addXmlnsAttr(bridge, attr);
            } else if (isRealVisible) {
                //The node is visible add the attribute to the list of output attributes.
                attrCol.use( attr );
            } 
        }
        
        N xmlnsDecl = null;
        
        for (N nsDecl : bridge.getNamespaceAxis(element, false)) {
       
            String prefix = bridge.getLocalName(nsDecl);
            
            if (prefix.length() == 0) {
                xmlnsDecl = nsDecl;
            }
            String NValue = bridge.getStringValue(nsDecl);              
            if ("xml".equals(prefix)
                    && XMLConstants.XML_NS_URI.equals(NValue)) {
                    /* except omit namespace node with local name xml, which defines
                     * the xml prefix, if its string value is http://www.w3.org/XML/1998/namespace.
                     */
                continue;
            }
            
            //add the prefix binding to the ns symb table.
            if  (isVisible(bridge, nsDecl, xpathNodeSet, nodeFilter))  {
                if (!isRealVisible && ns.removeMappingIfRender(prefix)) {
                    continue;
                }
                
                //The xpath select this node output it if needed.
                Object n = ns.addMappingAndRenderAttr(bridge, prefix, NValue, nsDecl);
                if (n != null) {
                    attrCol.use(n);
                    if (C14nHelper.namespaceIsRelative(bridge, nsDecl)) {
                       Object exArgs[] = { XMLUtils.getTagName(bridge, element), prefix,
                               bridge.getStringValue(nsDecl) };
                                    throw new CanonicalizationException(
                                        "c14n.Canonicalizer.RelativeNamespace", exArgs
                                    );
                    }
                }
            }
            else {
                if (isRealVisible && prefix.length() > 0) {
                    ns.removeMapping(prefix);   
                } else {
                    ns.addMapping(bridge, prefix,NValue, nsDecl);
                }
            }
        }
        if (isRealVisible) {    	           
            //The element is visible, handle the xmlns definition        
            Object n = null;
            if (xmlnsDecl == null) {
                //No xmlns def just get the already defined.
                n = ns.getMappingWrap("");
            } else if ( !isVisible(bridge, xmlnsDecl, xpathNodeSet, nodeFilter)) {
                //There is a definition but the xmlns is not selected by the xpath.
                //then xmlns=""
                n = ns.addMappingAndRenderAttr(bridge, "","", null);
            }
            //output the xmlns def if needed.
            if (n != null) {
                attrCol.use(n);
            }
            //Float all xml:* attributes of the unselected parent elements to this one. 
            xmlattrStack.getXmlnsAttr(bridge, attrCol);
            ns.getUnrenderedNodeWrappers(attrCol);
        }
    }
    
    protected <N> void circumventBugIfNeeded(XMLSignatureInput<N> input) 
        throws CanonicalizationException, ParserConfigurationException, IOException, SAXException {
        if (!input.isNeedsToBeExpanded()) {
            return;
        }
        MutableModel<N> model = input.getContext().mutableModel;
        N doc = null;
        if (input.getSubNodeN() != null) {
            doc= XMLUtils.getOwnerDocument(model, input.getSubNodeN());
        } else {
            doc = XMLUtils.getOwnerDocument(model, input.getNodeSet());
        }
        XMLUtils.circumventBug2650(model, doc);
    }

    @Override
    protected <N> void handleParent(Model<N> bridge, N e,NameSpaceSymbTable<N> ns) {
        xmlattrStack.push(-1);
            
       for ( N nsDecl : bridge.getNamespaceAxis(e, false)) {

           String NName = bridge.getLocalName(nsDecl);
           String NValue = bridge.getStringValue(nsDecl);
           if (XML.equals(NName)
                   && XMLConstants.XML_NS_URI.equals(NValue)) {
                continue;
           }
           ns.addMapping(bridge, NName,NValue, nsDecl);
       }
       
       for (N attr : bridge.getAttributeAxis(e, false)) {
           if (XMLConstants.XML_NS_URI.equals(bridge.getNamespaceURI(attr) )) {
               xmlattrStack.addXmlnsAttr(bridge, attr);
            }
        }
       
       if (!"".equals(bridge.getNamespaceURI(e))) {
           ns.addMapping(bridge, bridge.getPrefix(e), bridge.getNamespaceURI(e), null);
       }
    }
}
