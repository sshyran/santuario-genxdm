/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.transforms.implementations;

import java.io.OutputStream;

import org.apache.xml.security.exceptions.XMLSecurityRuntimeException;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.Transform;
import org.apache.xml.security.transforms.TransformSpi;
import org.apache.xml.security.transforms.TransformationException;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.genxdm.Model;
import org.genxdm.xpath.v10.BooleanExpr;
import org.genxdm.xpath.v10.ExprParseException;
import org.genxdm.xpath.v10.NodeDynamicContextBuilder;
import org.genxdm.xpath.v10.StaticContext;
import org.genxdm.xpath.v10.XPathCompiler;
import org.genxdm.xpath.v10.XPathToolkit;
import org.w3c.dom.DOMException;

/**
 * Class TransformXPath
 *
 * Implements the <CODE>http://www.w3.org/TR/1999/REC-xpath-19991116</CODE>
 * transform.
 *
 * @author Christian Geuer-Pollmann
 * @see <a href="http://www.w3.org/TR/1999/REC-xpath-19991116">XPath</a>
 *
 */
public class TransformXPath extends TransformSpi {

    /** Field implementedTransformURI */
    public static final String implementedTransformURI = Transforms.TRANSFORM_XPATH;
    
    /**
     * Method engineGetURI
     *
     * @inheritDoc
     */
    protected String engineGetURI() {
        return implementedTransformURI;
    }

    /**
     * Method enginePerformTransform
     * @inheritDoc
     * @param input
     *
     * @throws TransformationException
     */
    protected <N> XMLSignatureInput<N> enginePerformTransform(
        XMLSignatureInput<N> input, OutputStream os, Transform<N> transformObject
    ) throws TransformationException {
        try {
            /**
             * If the actual input is an octet stream, then the application MUST
             * convert the octet stream to an XPath node-set suitable for use by
             * Canonical XML with Comments. (A subsequent application of the
             * REQUIRED Canonical XML algorithm would strip away these comments.)
             *
             * ...
             *
             * The evaluation of this expression includes all of the document's nodes
             * (including comments) in the node-set representing the octet stream.
             */
            Model<N> model = input.getContext().model;

            N xpathElement = 
                model.getFirstChildElementByName(
                    transformObject.getElementNode(), Constants.SignatureSpecNS, Constants._TAG_XPATH);

            if (xpathElement == null) {
                Object exArgs[] = { "ds:XPath", "Transform" };

                throw new TransformationException("xml.WrongContent", exArgs);
            }
            N xpathnode = model.getFirstChild(xpathElement);
            String str = XMLUtils.getStrFromNode(model, xpathnode);
            input.setNeedsToBeExpanded(needsCircumvent(str));
            if (xpathnode == null) {
                throw new DOMException(
                    DOMException.HIERARCHY_REQUEST_ERR, "Text must be in ds:Xpath"
                );
            }
            
            //XPathFactory xpathFactory = XPathFactory.newInstance();
            //XPathAPI xpathAPIInstance = xpathFactory.newXPathAPI();
            input.addNodeFilter(new XPathNodeFilter<N>( model, xpathElement, xpathnode, str));
            input.setNodeSet(true);
            return input;
        } catch (DOMException ex) {
            throw new TransformationException("empty", ex);
        }
    }

    /**
     * @param str
     * @return true if needs to be circumvent for bug.
     */
    private boolean needsCircumvent(String str) {
        return (str.indexOf("namespace") != -1) || (str.indexOf("name()") != -1);
    }

    static class XPathNodeFilter<N> implements NodeFilter<N> {
        
        Model<N> model;
        String str;
        BooleanExpr boolExpr;
        NodeDynamicContextBuilder<N> dynArgs;
    	
    	XPathNodeFilter(Model<N> model, N xpathElement, N xpathnode, String str) {    		
            this.model = model;
            this.str = str;
            
            XPathToolkit toolkit = XPathHelper.getXPathToolkitWithHereFunction();
    		
            XPathCompiler compiler = toolkit.newXPathCompiler();
            StaticContext staticArgs = toolkit.newExprContextStaticArgs();
    		
            XPathHelper.declareNamespacesFromContextNode(model, xpathElement, staticArgs);
            dynArgs = toolkit.newExprContextDynamicArgs();
            XPathHelper.bindHereNode(model, xpathnode, dynArgs);
    		
            try {
	            boolExpr = compiler.compileBooleanExpr(str, staticArgs);
	        } catch (ExprParseException e) {
                Object[] eArgs = {str};
	            throw new XMLSecurityRuntimeException("xpath.parse.exception", eArgs, e);
	        }
        }

        /**
         * @see org.apache.xml.security.signature.NodeFilter#isNodeInclude(org.w3c.dom.Node)
         */
        public int isNodeInclude(Model<N> model, N currentNode) {			
            try {
                boolean result = boolExpr.booleanFunction(model, currentNode, dynArgs.build());
    			
                return result ? 1 : 0;
            } catch (Exception e) {
                Object[] eArgs = {currentNode, model.getNodeKind(currentNode)};
                throw new XMLSecurityRuntimeException("signature.Transform.nodeAndType",eArgs, e);
            }
        }
        
        public int isNodeIncludeDO(Model<N> bridge, N n, int level) {
            return isNodeInclude(bridge, n);
        }
        
    }
}
