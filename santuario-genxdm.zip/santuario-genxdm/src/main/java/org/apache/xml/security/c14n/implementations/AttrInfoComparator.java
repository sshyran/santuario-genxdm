package org.apache.xml.security.c14n.implementations;

import org.apache.xml.security.c14n.helper.AttrCompareBase;
import org.apache.xml.security.c14n.helper.AttrCompareBase.Accessor;
import org.genxdm.Model;

public class AttrInfoComparator extends AttrCompareBase<Object> {

	private static final long serialVersionUID = 1L;
	
	public <N> AttrInfoComparator(Model<N> model) {
		super( new AttrInfoAccessor<N>(model) );
	}
    public static class AttrInfoAccessor<N> implements Accessor<Object> {

    	public AttrInfoAccessor(Model<N> model) {
    	    m_model = model;
    	}
    	
		public String getLocalName(Object item) {
		    return AttrCursor.getLocalName(m_model, item);
		}

		public String getNamespace(Object item) {
			return AttrCursor.getNamespace(m_model, item);
		}

		public boolean isNamespace(Object item) {
		    return AttrCursor.isNamespace(m_model, item);
		}
    	
		private final Model<N> m_model; 
    };
    
}
