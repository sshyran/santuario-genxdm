package org.apache.xml.security.keys.keyresolver.implementations;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;

import javax.crypto.SecretKey;
import javax.xml.namespace.QName;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.keys.content.KeyInfoReference;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
import org.apache.xml.security.keys.storage.StorageResolver;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.apache.xml.security.utils.resolver.ResourceResolver;
import org.genxdm.io.DocumentHandler;

/**
 * KeyResolverSpi implementation which resolves public keys, private keys, secret keys, and X.509 certificates from a 
 * <code>dsig11:KeyInfoReference</code> element.
 * 
 * @author Brent Putman (putmanb@georgetown.edu)
 */
public class KeyInfoReferenceResolver extends KeyResolverSpi {

    /** {@link org.apache.commons.logging} logging facility */
    private static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(KeyInfoReferenceResolver.class);

    /** {@inheritDoc}. */
    public <N> boolean engineCanResolve(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage) {
        return XMLUtils.elementIsInSignature11Space(ctx.model, element, Constants._TAG_KEYINFOREFERENCE);
    }

    /** {@inheritDoc}. */
    public <N> PublicKey engineLookupAndResolvePublicKey(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {

        if (log.isDebugEnabled()) {
            log.debug("Can I resolve " + XMLUtils.getTagName(ctx.model, element));
        }

        if (!engineCanResolve(ctx, element, baseURI, storage)) {
            return null;
        }

        try {
            KeyInfo<N> referent = resolveReferentKeyInfo(ctx, element, baseURI, storage);
            if (referent != null) {
                return referent.getPublicKey();
            }
        } catch (XMLSecurityException e) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", e);
            }
        }

        return null;
    }

    /** {@inheritDoc}. */
    public <N> X509Certificate engineLookupResolveX509Certificate(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {

        if (log.isDebugEnabled()) {
            log.debug("Can I resolve " + XMLUtils.getTagName(ctx.model, element));
        }

        if (!engineCanResolve(ctx, element, baseURI, storage)) {
            return null;
        }

        try {
            KeyInfo<N> referent = resolveReferentKeyInfo(ctx, element, baseURI, storage);
            if (referent != null) {
                return referent.getX509Certificate();
            }
        } catch (XMLSecurityException e) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", e);
            }
        }

        return null;
    }

    /** {@inheritDoc}. */
    public <N> SecretKey engineLookupAndResolveSecretKey(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {

        if (log.isDebugEnabled()) {
            log.debug("Can I resolve " + XMLUtils.getTagName(ctx.model, element));
        }

        if (!engineCanResolve(ctx, element, baseURI, storage)) {
            return null;
        }

        try {
            KeyInfo<N> referent = resolveReferentKeyInfo(ctx, element, baseURI, storage);
            if (referent != null) {
                return referent.getSecretKey();
            }
        } catch (XMLSecurityException e) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", e);
            }
        }

        return null;
    }

    /** {@inheritDoc}. */
    public <N> PrivateKey engineLookupAndResolvePrivateKey(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage)
        throws KeyResolverException {

        if (log.isDebugEnabled()) {
            log.debug("Can I resolve " + XMLUtils.getTagName(ctx.model, element));
        }

        if (!engineCanResolve(ctx, element, baseURI, storage)) {
            return null;
        }

        try {
            KeyInfo<N> referent = resolveReferentKeyInfo(ctx, element, baseURI, storage);
            if (referent != null) {
                return referent.getPrivateKey();
            }
        } catch (XMLSecurityException e) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", e);
            }
        }

        return null;
    }

    /**
     * Resolve the KeyInfoReference Element's URI attribute into a KeyInfo instance.
     * 
     * @param element
     * @param baseURI
     * @param storage
     * @return the KeyInfo which is referred to by this KeyInfoReference, or null if can not be resolved
     * @throws XMLSecurityException
     */
    private <N> KeyInfo<N> resolveReferentKeyInfo(XmlContext<N> ctx, N element, String baseURI, StorageResolver storage) throws XMLSecurityException {
        KeyInfoReference<N> reference = new KeyInfoReference<N>(ctx.mutableModel, element, baseURI);
        N uriAttr = reference.getURIAttrNode();

        XMLSignatureInput<N> resource = resolveInput(ctx, uriAttr, baseURI, secureValidation);

        N referentElement = null;
        try {
            referentElement = obtainReferenceElement(resource);
        } catch (Exception e) {
            if (log.isDebugEnabled()) {
                log.debug("XMLSecurityException", e);
            }
            return null;
        }

        if (referentElement == null) {
            log.debug("De-reference of KeyInfoReference URI returned null: " + ctx.model.getStringValue(uriAttr));
            return null;
        }

        validateReference(ctx, referentElement);

        KeyInfo<N> referent = new KeyInfo<N>(ctx, referentElement, baseURI);
        referent.addStorageResolver(storage);
        return referent;
    }

    /**
     * Validate the Element referred to by the KeyInfoReference.
     * 
     * @param referentElement
     * 
     * @throws XMLSecurityException
     */
    private <N> void validateReference(XmlContext<N> ctx, N referentElement) throws XMLSecurityException {
        if (!XMLUtils.elementIsInSignatureSpace(ctx.model, referentElement, Constants._TAG_KEYINFO)) {
            Object exArgs[] = { new QName(ctx.model.getNamespaceURI(referentElement), ctx.model.getLocalName(referentElement)) };
            throw new XMLSecurityException("KeyInfoReferenceResolver.InvalidReferentElement.WrongType", exArgs);
        }

        KeyInfo<N> referent = new KeyInfo<N>(ctx, referentElement, "");
        if (referent.containsKeyInfoReference()) {
            if (secureValidation) {
                throw new XMLSecurityException("KeyInfoReferenceResolver.InvalidReferentElement.ReferenceWithSecure");
            } else {
                // Don't support chains of references at this time. If do support in the future, this is where the code
                // would go to validate that don't have a cycle, resulting in an infinite loop. This may be unrealistic
                // to implement, and/or very expensive given remote URI references.
                throw new XMLSecurityException("KeyInfoReferenceResolver.InvalidReferentElement.ReferenceWithoutSecure");
            }
        }

    }

    /**
     * Resolve the XML signature input represented by the specified URI.
     * 
     * @param uri
     * @param baseURI
     * @param secureValidation
     * @return
     * @throws XMLSecurityException 
     */
    private <N> XMLSignatureInput<N> resolveInput(XmlContext<N> ctx, N uri, String baseURI, boolean secureValidation)
        throws XMLSecurityException {
        ResourceResolver resRes = ResourceResolver.getInstance(ctx, uri, baseURI, secureValidation);
        XMLSignatureInput<N> resource = resRes.resolve(ctx, uri, baseURI, secureValidation);
        return resource;
    }

    /**
     * Resolve the Element effectively represented by the XML signature input source.
     * 
     * @param resource
     * @return
     * @throws CanonicalizationException
     * @throws ParserConfigurationException
     * @throws IOException
     * @throws SAXException
     * @throws KeyResolverException
     */
    private <N> N obtainReferenceElement(XMLSignatureInput<N> resource) 
        throws CanonicalizationException, ParserConfigurationException, 
        IOException, KeyResolverException {

        N e;
        if (resource.isElement()){
            e = resource.getSubNodeN();
        } else if (resource.isNodeSet()) {
            log.debug("De-reference of KeyInfoReference returned an unsupported NodeSet");
            return null;
        } else {
            // Retrieved resource is a byte stream
            byte inputBytes[] = resource.getBytes();
            e = getDocFromBytes(resource.getContext(), inputBytes);
        }
        return e;
    }

    /**
     * Parses a byte array and returns the parsed Element.
     *
     * @param bytes
     * @return the Document Element after parsing bytes 
     * @throws KeyResolverException if something goes wrong
     */
    private <N> N getDocFromBytes(XmlContext<N> ctx, byte[] bytes) throws KeyResolverException {
        try {
            DocumentHandler<N> dh = ctx.docHandlerFactory.newDocumentHandler();
            N doc = dh.parse(new ByteArrayInputStream(bytes), null);
            return ctx.model.getFirstChildElement(doc);
        } catch (IOException ex) {
            throw new KeyResolverException("empty", ex);
        }
    }

}
