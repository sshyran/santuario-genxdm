/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.c14n.implementations;

import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.helper.C14nHelper;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.params.InclusiveNamespaces;
import org.apache.xml.security.utils.XMLUtils;
import org.genxdm.Model;
import org.genxdm.mutable.MutableModel;
import org.xml.sax.SAXException;

/**
 * Implements &quot; <A
 * HREF="http://www.w3.org/TR/2002/REC-xml-exc-c14n-20020718/">Exclusive XML
 * Canonicalization, Version 1.0 </A>&quot; <BR />
 * Credits: During restructuring of the Canonicalizer framework, Ren??
 * Kollmorgen from Software AG submitted an implementation of ExclC14n which
 * fitted into the old architecture and which based heavily on my old (and slow)
 * implementation of "Canonical XML". A big "thank you" to Ren?? for this.
 * <BR />
 * <i>THIS </i> implementation is a complete rewrite of the algorithm.
 * 
 * @author Christian Geuer-Pollmann <geuerp@apache.org>
 * @version $Revision: 1147448 $ 
 * @see <a href="http://www.w3.org/TR/2002/REC-xml-exc-c14n-20020718/ Exclusive#">
 *          XML Canonicalization, Version 1.0</a>
 */
public abstract class Canonicalizer20010315Excl extends CanonicalizerBase {

    /**
      * This Set contains the names (Strings like "xmlns" or "xmlns:foo") of
      * the inclusive namespaces.
      */
    private Set<String> inclusiveNSSet;

    /**
     * Constructor Canonicalizer20010315Excl
     * 
     * @param includeComments
     */
    public Canonicalizer20010315Excl(boolean includeComments) {
        super(includeComments);
    }

    /**
     * Method engineCanonicalizeSubTree
     * @inheritDoc
     * @param rootNode
     * 
     * @throws CanonicalizationException
     */
    @Override
    public <N> byte[] engineCanonicalizeSubTree(Model<N> bridge, N rootNode)
        throws CanonicalizationException {
        return engineCanonicalizeSubTree(bridge, rootNode, "", null);
    }

    /**
     * Method engineCanonicalizeSubTree
     *  @inheritDoc
     * @param rootNode
     * @param inclusiveNamespaces
     * 
     * @throws CanonicalizationException
     */
    @Override
    public <N> byte[] engineCanonicalizeSubTree(
    	Model<N> bridge, N rootNode, String inclusiveNamespaces
    ) throws CanonicalizationException {
        return engineCanonicalizeSubTree(bridge, rootNode, inclusiveNamespaces, null);
    }

    /**
     * Method engineCanonicalizeSubTree  
     * @param rootNode
     * @param inclusiveNamespaces   
     * @param excl A element to exclude from the c14n process. 
     * @return the rootNode c14n.
     * @throws CanonicalizationException
     */
    public <N> byte[] engineCanonicalizeSubTree(Model<N> bridge,
        N rootNode, String inclusiveNamespaces, N excl
    ) throws CanonicalizationException {

        inclusiveNSSet = InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces);
        return super.engineCanonicalizeSubTree(bridge, rootNode, excl, getIncludeComments(), null, null);
    }

    /**
     * 
     * @param rootNode
     * @param inclusiveNamespaces
     * @return the rootNode c14n.
     * @throws CanonicalizationException
     */
    public <N> byte[] engineCanonicalize(
        XMLSignatureInput<N> rootNode, String inclusiveNamespaces
    ) throws CanonicalizationException {
        inclusiveNSSet = InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces);
        return super.engineCanonicalizeInternal(rootNode);
    }
 
    /**
     * Method engineCanonicalizeXPathNodeSet
     * @inheritDoc
     * @param xpathNodeSet
     * @param inclusiveNamespaces
     * @throws CanonicalizationException
     */
    public <N> byte[] engineCanonicalizeXPathNodeSet(Model<N> model,
        Set<N> xpathNodeSet, String inclusiveNamespaces
    ) throws CanonicalizationException {
        inclusiveNSSet = InclusiveNamespaces.prefixStr2Set(inclusiveNamespaces);
        return this.engineCanonicalizeXPathNodeSetInternal(model, XMLUtils.getOwnerDocument(model, xpathNodeSet),
                getIncludeComments(), xpathNodeSet, null);
    }
    
    @Override
    protected <N> void handleAttributesSubtree(Model<N> bridge, N element, NameSpaceSymbTable<N> ns, AttrCollector<N> attrCol)
        throws CanonicalizationException {
        // The prefix visibly utilized (in the attribute or in the name) in 
        // the element
        SortedSet<String> visiblyUtilized = new TreeSet<String>();
        if (inclusiveNSSet != null) {
            visiblyUtilized.addAll(inclusiveNSSet);
        }
    
        // complete hack - remove "xml" prefix if it is listed.
        visiblyUtilized.remove("xml");
                
        for ( N attr : bridge.getAttributeAxis(element, false)) {
            
            //The Element is output element, add his prefix(if used) to visibyUtilized
            String prefix = bridge.getPrefix(attr);
            if ( !prefix.equals(XML) && prefix.length() > 0) {
                        visiblyUtilized.add(prefix);
                    }                                   
                    // Add to the result.
            attrCol.use( attr );              
        }
        
        for ( N nsDecl : bridge.getNamespaceAxis(element, false) ) {
            String NName = bridge.getLocalName(nsDecl);
            String NNodeValue = bridge.getStringValue(nsDecl);
        
            if (ns.addMapping(bridge, NName, NNodeValue, nsDecl )) {
                    // New definition check if it is relative.
                if (C14nHelper.namespaceIsRelative(NNodeValue)) {
                    Object exArgs[] = {XMLUtils.getTagName(bridge, element), NName,
                            bridge.getStringValue(nsDecl)};
                    throw new CanonicalizationException(
                        "c14n.Canonicalizer.RelativeNamespace", exArgs
                    );
                }
            }
        }
        String prefix = null;
        if (bridge.getNamespaceURI(element) != null) {
            prefix = bridge.getPrefix(element);
        } else {
            prefix = "";
        }
        visiblyUtilized.add(prefix);
    
        for (String s : visiblyUtilized ) {
            Object key = ns.getMappingWrap(s);
            if (key != null) {
                attrCol.use(key);
            }
        }
    }
        
    /**
     * @inheritDoc
     * @param element
     * @throws CanonicalizationException
     */
    @Override
    protected final <N> void handleAttributes(Model<N> bridge, N element, NameSpaceSymbTable<N> ns, Set<N> xpathNodeSet,
            List<NodeFilter<N>> nodeFilter, AttrCollector<N> attrCol)
        throws CanonicalizationException {

        // The prefix visibly utilized (in the attribute or in the name) in 
        // the element
        Set<String> visiblyUtilized = null;
        // It's the output selected.
        boolean isOutputElement = isVisibleDO(bridge, element, ns.getLevel(), xpathNodeSet, nodeFilter) == 1;           
        if (isOutputElement) {
            visiblyUtilized = new TreeSet<String>();
            if (inclusiveNSSet != null) {
                visiblyUtilized.addAll(inclusiveNSSet);
            }
        }

        for (N attr : bridge.getAttributeAxis(element, false)) {
            if ( isVisible(bridge, attr, xpathNodeSet, nodeFilter) && isOutputElement)  {
                //The Element is output element, add his prefix(if used) to visibyUtilized
                String prefix = bridge.getPrefix(attr);
                if (!prefix.equals(XML) && prefix.length() > 0){ 
                            visiblyUtilized.add(prefix);
                }                   
                // Add to the result.
                attrCol.use( attr );
            }
        }
        
        N xmlnsDecl = null;
        
        for (N nsDecl: bridge.getNamespaceAxis(element, false) ) {
                        
            String NName=bridge.getLocalName(nsDecl);
            if (NName.length() == 0) {
                xmlnsDecl = nsDecl;
            }
            if (isOutputElement && !isVisible(bridge, nsDecl, xpathNodeSet, nodeFilter) && NName.length() > 0) {
                    ns.removeMappingIfNotRender(NName);
                continue;
            }
            String NNodeValue = bridge.getStringValue(nsDecl);
            
            if (!isOutputElement && isVisible(bridge, nsDecl, xpathNodeSet, nodeFilter)
                    && inclusiveNSSet.contains(NName)
                        && !ns.removeMappingIfRender(NName)) {
                Object n = ns.addMappingAndRenderAttr(bridge, NName,NNodeValue, nsDecl );
                if (n != null) {
                    attrCol.use(n);
                    if (C14nHelper.namespaceIsRelative(bridge, nsDecl)) {
                        Object exArgs[] = { XMLUtils.getTagName(bridge, element), NName,
                                   bridge.getStringValue(nsDecl) };
                                throw new CanonicalizationException(
                                    "c14n.Canonicalizer.RelativeNamespace", exArgs
                                );
                        }
                    }
                }

            if (ns.addMapping(bridge, NName, NNodeValue, nsDecl )) {
                //New definiton check if it is relative
                if (C14nHelper.namespaceIsRelative(NNodeValue)) {
                    Object exArgs[] = {XMLUtils.getTagName(bridge, element), NName,
                            bridge.getStringValue(nsDecl)};
                        throw new CanonicalizationException(
                            "c14n.Canonicalizer.RelativeNamespace", exArgs
                        );
                    }
                }
            }

        if (isOutputElement) {	               
            // The element is visible, handle the xmlns definition    

           if ( xmlnsDecl != null && !isVisible(bridge, xmlnsDecl, xpathNodeSet, nodeFilter) ) {
              //There is a definition but the xmlns is not selected by the xpath.
              //then xmlns=""
              ns.addMapping(bridge, "", "", null);
            }

            String prefix = null;
            if (bridge.getNamespaceURI(element) != null) {
                prefix = bridge.getPrefix(element);
            } else {
                prefix = "";
            }
            visiblyUtilized.add(prefix);
        
            for (String s : visiblyUtilized) {
                Object key = ns.getMappingWrap(s);
                if (key != null) {
                    attrCol.use(key);
                }
            }
        }
    }

    @Override
    protected <N> void circumventBugIfNeeded(XMLSignatureInput<N> input)
        throws CanonicalizationException, ParserConfigurationException,
               IOException, SAXException {
        if (!input.isNeedsToBeExpanded() || inclusiveNSSet.isEmpty()) {
            return;
        }
        N doc = null;

        MutableModel<N> model = input.getContext().mutableModel;
        N subNode = input.getSubNodeN();
        if (subNode != null) {
            doc = XMLUtils.getOwnerDocument(model, subNode);
        } else {
            doc = XMLUtils.getOwnerDocument(model, input.getNodeSet());
        }
        XMLUtils.circumventBug2650(model, doc);
    }
}
