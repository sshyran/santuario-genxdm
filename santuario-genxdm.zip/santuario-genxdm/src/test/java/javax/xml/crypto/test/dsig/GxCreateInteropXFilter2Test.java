/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
package javax.xml.crypto.test.dsig;

import java.io.*;
import java.security.*;
import java.security.cert.Certificate;
import java.util.*;

import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.keyinfo.*;
import javax.xml.crypto.dsig.spec.*;

import org.apache.jcp.crypto.genxdm.GenXDMSignContext;
import org.apache.jcp.crypto.genxdm.GenXDMValidateContext;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

import javax.xml.crypto.test.KeySelectors;
import javax.xml.crypto.test.util.JavaxTestUtil;

/**
 * Test that recreates merlin-xpath-filter2-three test vectors
 * but with different keys and X.509 data.
 *
 * @author Sean Mullan
 */
public class GxCreateInteropXFilter2Test<N> extends org.junit.Assert {

    private XMLSignatureFactory fac;
    private KeyInfoFactory kifac;
    private XmlTestContext<N> testCtx;
    private DocumentHandlerFactory<N> docFactory;
    private KeyStore ks;
    private Key signingKey;
    private PublicKey validatingKey;
    private Certificate signingCert;

    static {
        Security.insertProviderAt
            (new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI(), 1);
    }

    public GxCreateInteropXFilter2Test() throws Exception {
        fac = JavaxTestUtil.getFactory();
        kifac = fac.getKeyInfoFactory();
        testCtx = XmlTestContext.getTestContext();
        docFactory = testCtx.getXmlContext().docHandlerFactory;

        // get key & self-signed certificate from keystore
        String fs = System.getProperty("file.separator");
        String base = System.getProperty("basedir") == null ? "./": System.getProperty("basedir");
        
        FileInputStream fis = new FileInputStream
            (base + fs + "src/test/resources" + fs + "test.jks");
        ks = KeyStore.getInstance("JKS");
        ks.load(fis, "changeit".toCharArray());
        signingKey = ks.getKey("mullan", "changeit".toCharArray());
        signingCert = ks.getCertificate("mullan");
        validatingKey = signingCert.getPublicKey();
    }

    @org.junit.Test
    public void test_create_sign_spec_gx() throws Exception {
        List<Reference> refs = new ArrayList<Reference>(2);

        // create reference 1
        List<XPathType> types = new ArrayList<XPathType>(3);
        types.add(new XPathType(" //ToBeSigned ", XPathType.Filter.INTERSECT));
        types.add(new XPathType(" //NotToBeSigned ", XPathType.Filter.SUBTRACT));
        types.add(new XPathType(" //ReallyToBeSigned ", XPathType.Filter.UNION));
        XPathFilter2ParameterSpec xp1 = new XPathFilter2ParameterSpec(types);
        refs.add(fac.newReference
            ("", fac.newDigestMethod(DigestMethod.SHA1, null),
             Collections.singletonList(fac.newTransform(Transform.XPATH2, xp1)),
             null, null));

        // create reference 2
        List<Transform> trans2 = new ArrayList<Transform>(2);
        trans2.add(fac.newTransform(Transform.ENVELOPED, 
            (TransformParameterSpec) null));
        XPathFilter2ParameterSpec xp2 = new XPathFilter2ParameterSpec
            (Collections.singletonList
                (new XPathType(" / ", XPathType.Filter.UNION)));
        trans2.add(fac.newTransform(Transform.XPATH2, xp2));
        refs.add(fac.newReference("#signature-value", 
            fac.newDigestMethod(DigestMethod.SHA1, null), trans2, null, null));
                
        // create SignedInfo
        SignedInfo si = fac.newSignedInfo(
            fac.newCanonicalizationMethod
                (CanonicalizationMethod.INCLUSIVE, 
                 (C14NMethodParameterSpec) null),
            fac.newSignatureMethod(SignatureMethod.DSA_SHA1, null), refs);

        // create KeyInfo
        List<XMLStructure> kits = new ArrayList<XMLStructure>(2);
        kits.add(kifac.newKeyValue(validatingKey));
        List<Object> xds = new ArrayList<Object>(2);
        xds.add("CN=Sean Mullan, DC=sun, DC=com");
        xds.add(signingCert);
        kits.add(kifac.newX509Data(xds));
        KeyInfo ki = kifac.newKeyInfo(kits);

        // create XMLSignature
        XMLSignature sig = fac.newXMLSignature
            (si, ki, null, null, "signature-value");

        NodeFactory<N> nodeFactory = testCtx.getNodeFactory();
        XmlContext<N> ctx = testCtx.getXmlContext();
        MutableModel<N> model = ctx.mutableModel;

        N doc = nodeFactory.createDocument(null, null);
        N tbs1 = nodeFactory.createElement("", "ToBeSigned", "");
        N tbs1Com = nodeFactory.createComment(" comment ");
        N tbs1Data = nodeFactory.createElement("", "Data", "");
        N tbs1ntbs = nodeFactory.createElement("", "NotToBeSigned", "");
        N tbs1rtbs = nodeFactory.createElement("", "ReallyToBeSigned", "");
        N tbs1rtbsCom = nodeFactory.createComment(" comment ");
        N tbs1rtbsData = nodeFactory.createElement("", "Data", "");
        model.appendChild(tbs1rtbs, tbs1rtbsCom);
        model.appendChild(tbs1rtbs, tbs1rtbsData);
        model.appendChild(tbs1ntbs, tbs1rtbs);
        model.appendChild(tbs1, tbs1Com);
        model.appendChild(tbs1, tbs1Data);
        model.appendChild(tbs1, tbs1ntbs);

        N tbs2 = nodeFactory.createElement("", "ToBeSigned", "");
        N tbs2Data = nodeFactory.createElement("", "Data", "");
        N tbs2ntbs = nodeFactory.createElement("", "NotToBeSigned", "");
        N tbs2ntbsData = nodeFactory.createElement("", "Data", "");
        model.appendChild(tbs2ntbs, tbs2ntbsData);
        model.appendChild(tbs2, tbs2Data);
        model.appendChild(tbs2, tbs2ntbs);

        N document = nodeFactory.createElement("", "Document", "");
        model.appendChild(document, tbs1);
        model.appendChild(document, tbs2);
        model.appendChild(doc, document);

        GenXDMSignContext<N> dsc = new GenXDMSignContext<N>(docFactory, model, signingKey, document);

        sig.sign(dsc);

        GenXDMValidateContext<N> dvc = new GenXDMValidateContext<N>
            (new KeySelectors.KeyValueKeySelector(), docFactory, model, model.getLastChild(document));
        XMLSignature sig2 = fac.unmarshalXMLSignature(dvc);

        assertTrue(sig.equals(sig2));

        assertTrue(sig2.validate(dvc));
    }

}
