/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package javax.xml.crypto.test.dsig;

import java.io.File;
import java.io.FileInputStream;
import java.security.Security;

import javax.xml.crypto.MarshalException;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.jcp.xml.dsig.internal.dom.DOMSignedInfo;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.compat.DomCompatibility;
import org.genxdm.io.DocumentHandler;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;

/**
 * This is a test for a forbidden number of references when secure validation is enabled.
 */
public class GxJSRForbiddenRefCountTest<N> extends org.junit.Assert {

    static {
        Security.insertProviderAt(new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI(), 1);
    }
    
    private XmlContext<N> ctx;
    
    public GxJSRForbiddenRefCountTest() {
        ctx = XmlTestContext.getContext();
    }

    @org.junit.Test
    public void testReferenceCount_gx() throws Exception {
        N signedInfoElement = 
            getSignedInfoElement("src/test/resources/interop/c14n/Y4", "signature-manifest.xml");
        
        InternalGenXDMCryptoContext<N> context = new InternalGenXDMCryptoContext<N>(ctx.docHandlerFactory, ctx.mutableModel);
        new DOMSignedInfo<N>(ctx.mutableModel, signedInfoElement, context, null);
        
        context.setProperty("org.apache.jcp.xml.dsig.secureValidation", Boolean.TRUE);
        try {
            new DOMSignedInfo<N>(ctx.mutableModel,signedInfoElement, context, null);
        } catch (MarshalException ex) {
            String error = 
                "A maxiumum of 30 references per Manifest are allowed with secure validation";
            assertTrue(ex.getMessage().contains(error));
        }
    }
    
    private static class InternalGenXDMCryptoContext<NT> extends GenXDMCryptoContext<NT> {

        public InternalGenXDMCryptoContext(DocumentHandlerFactory<NT> docFactory,
                MutableModel<NT> model) {
            super(docFactory, model);
            // TODO Auto-generated constructor stub
        }
        //
    }
    
    private N getSignedInfoElement(
        String directory, String file
    ) throws Exception {
        String basedir = System.getProperty("basedir");
        if (basedir != null && !"".equals(basedir)) {
            directory = basedir + "/" + directory;
        }

        File f = new File(directory + "/" + file);

        DocumentHandler<N> docHandler = ctx.docHandlerFactory.newDocumentHandler();
        N doc = docHandler.parse(new FileInputStream(f), f.toURI());
        
        return DomCompatibility.getFirstDescendantOrSelfElementByName
            (ctx.model, doc, Constants.SignatureSpecNS, Constants._TAG_SIGNEDINFO);
    }

}
