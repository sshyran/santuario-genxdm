package javax.xml.crypto.test.util;

import javax.xml.crypto.dsig.XMLSignatureFactory;

/**
 * Utility methods for testing Javax API.
 *
 */
public class JavaxTestUtil {


	/**
	 * Gets the {@link XMLSignatureFactory} implementation to use, rather than
	 * relying on the JRE to provide one.
	 * 
	 * <p>Method created to centralize logic after renaming packages.
	 * </p>
	 */
	public static XMLSignatureFactory getFactory() {
    	XMLSignatureFactory factory = XMLSignatureFactory.getInstance
        ("DOM", new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI());
		
    	return factory;
	}
}
