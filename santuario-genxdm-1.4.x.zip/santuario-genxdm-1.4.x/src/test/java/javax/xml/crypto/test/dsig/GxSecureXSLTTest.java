/*
 * Copyright 2006-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package javax.xml.crypto.test.dsig;

import java.io.*;

import java.security.Security;
import java.util.List;

import javax.xml.crypto.dsig.*;

import junit.framework.*;
import javax.xml.crypto.test.KeySelectors;
import javax.xml.crypto.test.util.JavaxTestUtil;

import org.apache.jcp.crypto.genxdm.GenXDMValidateContext;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.compat.DomCompatibility;
import org.genxdm.io.DocumentHandlerFactory;

public class GxSecureXSLTTest<N> extends TestCase {

    static {
        Security.insertProviderAt
            (new org.apache.jcp.xml.dsig.internal.dom.XMLDSigRI(), 1);
    }

    public GxSecureXSLTTest(String name) {
	super(name);
    }

    public void test_gx() throws Exception {

        String fs = System.getProperty("file.separator");
        String base = System.getProperty("basedir") == null ? "./": System.getProperty("basedir");
    	
        File baseDir = new File(base + fs + "data" 
	    + fs + "javax" + fs + "xml" + fs + "crypto", "dsig");

        String[] signatures =
            { "signature1.xml", "signature2.xml", "signature3.xml" };

        XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
        XmlContext<N> ctx = testCtx.getXmlContext();
        DocumentHandlerFactory<N> docFactory = ctx.docHandlerFactory;
        XMLSignatureFactory fac = JavaxTestUtil.getFactory();
        File f = new File("doc.xml");
        for (int i=0; i<signatures.length; i++) {
	    String signature = signatures[i];
            // System.out.println("Validating " + signature);
	        File toParse = new File(baseDir, signature);
	        N doc = docFactory.newDocumentHandler().parse(new FileInputStream(toParse), toParse.toURI());

	        List<N> nodes = (List<N>) DomCompatibility.getDescendantOrSelfElementsByName(ctx.model, doc, XMLSignature.XMLNS, "Signature");
            if (nodes.size() == 0) {
                throw new Exception("Cannot find Signature element");
            }

            GenXDMValidateContext<N> valContext = new GenXDMValidateContext<N>
                (new KeySelectors.KeyValueKeySelector(), ctx.docHandlerFactory, ctx.mutableModel, nodes.get(0));
	    // enable reference caching in your validation context 
	    valContext.setProperty
    		("javax.xml.crypto.dsig.cacheReference", Boolean.TRUE);

            // make sure file is not left over from previous run
            f.delete();

            XMLSignature sig = fac.unmarshalXMLSignature(valContext);
            try {
                if (sig.validate(valContext)) {
                    System.err.println("Signature UNEXPECTEDLY passed validation");
                }
		sig.getSignedInfo().getReferences().get(0);
            } catch (XMLSignatureException xse) {
                // this is good, but still make sure attack was not successful
                // by falling through and checking if file was created
//		xse.printStackTrace();
            }
            if (f.exists()) {
                f.delete(); // cleanup file. comment out when debugging
                throw new Exception
                    ("Test FAILED: doc.xml was successfully created");
            }
        }
        // System.out.println("Test PASSED");
    }
}
