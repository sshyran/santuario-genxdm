/*
 * Copyright  2007-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.encryption;

import java.io.ByteArrayInputStream;
import java.util.List;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandler;
import org.genxdm.compat.DomCompatibility;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GxEncryptContentTest<N> extends TestCase {

	private static final String DATA = "<users>\n" + "  <user>\n"
			+ "    <firstname>Bugs</firstname>\n"
			+ "    <lastname>Bunny</lastname>\n" + "    <age>34</age>\n"
			+ "    <serial>Y10</serial>\n" + "  </user>\n" + "</users>\n";

	private XmlContext<N> ctx;
	private DocumentHandler<N> docHandler;
	private SecretKey secretKey;

	public static Test suite() throws Exception {
		return new TestSuite(GxEncryptContentTest.class);
	}

	public GxEncryptContentTest(String name) {
		super(name);
	}

	public void setUp() throws Exception {

		ctx = XmlTestContext.getContext();
		docHandler = ctx.docHandlerFactory.newDocumentHandler();
		
		org.apache.xml.security.Init.init();

		byte[] bits192 = "abcdefghijklmnopqrstuvwx".getBytes();
		DESedeKeySpec keySpec = new DESedeKeySpec(bits192);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
		secretKey = keyFactory.generateSecret(keySpec);
	}

	public void testContentRemovedGx() throws Exception {

		N doc = docHandler.parse(new ByteArrayInputStream(DATA.getBytes("UTF8")), null);
		
		List<N> dataToEncrypt = DomCompatibility.listFromIterable( 
			DomCompatibility.getDescendantOrSelfElementsByName(ctx.model, doc, "", "user"));
		
		XMLCipher<N> dataCipher = XMLCipher.getInstance(XMLCipher.TRIPLEDES);
		dataCipher.init(XMLCipher.ENCRYPT_MODE, secretKey);

		for (N elem : dataToEncrypt) {
			dataCipher.doFinal(ctx, doc, elem, true);
		}

		// Check that user content has been removed
		N user = dataToEncrypt.get(0);
		N child = ctx.model.getFirstChildElement(user);

		// child should be EncryptedData, if not throw exception
		if (!ctx.model.getLocalName(child).equals("EncryptedData")) {
			// t.transform(new DOMSource(doc), new StreamResult(System.out));
			throw new Exception("Element content not replaced");
		}
		// there shouldn't be any more children elements
		N sibling = ctx.model.getNextSiblingElement(child);
		if (sibling != null) {
			// t.transform(new DOMSource(doc), new StreamResult(System.out));
			throw new Exception("Sibling element content not replaced");
		}

		// t.transform(new DOMSource(doc), new StreamResult(System.out));
	}
}
