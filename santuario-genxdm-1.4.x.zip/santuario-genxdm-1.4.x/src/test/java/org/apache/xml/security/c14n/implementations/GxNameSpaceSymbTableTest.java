package org.apache.xml.security.c14n.implementations;

import java.util.ArrayList;
import java.util.List;

import org.apache.xml.security.test.gxml.XmlTestContext;
import org.genxdm.Model;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * TODO - really should revisit this test class, and see if it can be
 * usefully rewritten without resorting to the deprecated functions.
 * 
 * @param <N>
 */
public class GxNameSpaceSymbTableTest<N> extends TestCase {
	public static Test suite() {
	      return new TestSuite(GxNameSpaceSymbTableTest.class);
	   }
	
	private Model<N> model;
	
	private N node1;
	
	private N node2;
	
	public void setUp() {
		XmlTestContext<N> ctx = XmlTestContext.getTestContext();

		model = ctx.getXmlContext().model;
		
		node1 = ctx.createAttributeWithValue("a", "b", "anything");
		node2 = ctx.createAttributeWithValue("b", "c", "anything else");
	}
	public void testGxNullFirstXmlns() {
		NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
		assertNull(ns.getMappingWrap("xmlns"));
  }
  public void testGxXmlnsPut() {
      NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);
      assertEquals(node1,ns.getMappingWrap("xmlns").getWrappedNode() );
  }
  public void testGxXmlnsMap() {
      NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);
      assertEquals(node1,ns.getMappingWrap("xmlns").getWrappedNode() );
      ns.pop();
      assertEquals(null,ns.getMappingWrap("xmlns"));        
  }
  public void testGxXmlnsMap2() {
      NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);        
      ns.pop();
      ns.pop();
      assertEquals(null,ns.getMappingWrap("xmlns"));        
  }
  public void testGxXmlnsPrefix() {
      NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);
      assertEquals(node1,ns.getMappingWrap("xmlns").getWrappedNode());
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);
      assertEquals(null,ns.getMappingWrap("xmlns"));     
      ns.push();
      ns.addMapping(model, "xmlns","http://b",node1);
      assertEquals(node1,ns.getMappingWrap("xmlns").getWrappedNode());
  }
  public void testGxXmlnsRemovePrefix() {
      NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);
      assertEquals(node1,ns.getMappingWrap("xmlns").getWrappedNode());
      ns.pop();        
      assertNull(ns.getMappingWrap("xmlns"));             
  }
  public void testGxPrefix() {
  	NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.addMapping(model, "a","http://a",node1);
      assertEquals(node1,ns.getMappingWrap("a").getWrappedNode());
      ns.push();
      assertNull(ns.getMappingWrap("a"));
      ns.push();
      ns.addMapping(model, "a","http://c",node1);
      assertEquals(node1,ns.getMappingWrap("a").getWrappedNode());
      ns.pop();
      ns.push();
      assertNull(ns.getMappingWrap("a"));
      ns.addMapping(model, "a","http://c",node1);
      assertEquals(node1,ns.getMappingWrap("a").getWrappedNode());
  }
  public void testGxSeveralPrefixes() {
  	NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.addMapping(model, "a","http://a",node1);
      ns.addMapping(model, "b","http://b",node2);
      assertEquals(node1,ns.getMappingWrap("a").getWrappedNode());
      assertEquals(node2,ns.getMappingWrap("b").getWrappedNode());
      ns.push();
      assertNull(ns.getMappingWrap("a"));
   }
  public void testGxSeveralPrefixes2() {
      NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      ns.addMapping(model, "a","http://a",node1);
      ns.push();        
      assertEquals(node1,ns.getMappingWrap("a").getWrappedNode());
      ns.pop();
      assertEquals(node1,ns.getMappingWrap("a").getWrappedNode());        
   }
  public void testGxGetUnrenderedNodes() {
  	NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      List<Object> l=new ArrayList<Object>();
      ns.addMapping(model, "xmlns","http://a",node1);
      ns.push();
      ns.getUnrenderedNodes(l);
      assertTrue(l.contains(node1));
      AttrInfo n = ns.addMappingAndRenderAttr(model, "xmlns","",node2);
      assertNotNull("xmlns=\"\" not rendered",n);
      assertEquals(n.getWrappedNode(), node2);
  }
  public void testGxUnrederedNodes() {
  	NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
      ns.push();
      List<Object> l=new ArrayList<Object>();
      ns.getUnrenderedNodes(l);
      assertTrue(l.isEmpty());
      l.clear();
      ns.push();
      ns.addMapping(model, "xmlns","http://a",node1);
      ns.addMapping(model, "a","http://a",node2);

      ns.push();
      
      ns.getUnrenderedNodes(l);
      assertTrue(l.contains(node1));
      assertTrue(l.contains(node2));
      ns.push();
      l.clear();
      ns.getUnrenderedNodes(l);
      assertFalse(l.contains(node1));
      assertFalse(l.contains(node2));   
      ns.pop();
      ns.pop();
      l.clear();
      ns.getUnrenderedNodes(l);
      assertTrue(l.contains(node1));
      assertTrue(l.contains(node2));
      
  }
  public void testGxBug38655() {
  	 NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
       ns.push();
       
       ns.addMappingAndRenderAttr(model, "generated-command","http://foo.com/command",node1);        	 
       ns.addMappingAndRenderAttr(model, "generated-event","http://foo.com/event",node1);
       ns.addMappingAndRenderAttr(model, "command","http://foo.com/command",node1);
       ns.addMappingAndRenderAttr(model, "ui","http://foo.com/ui",node1);
       ns.addMappingAndRenderAttr(model, "event","http://foo.com/event",node1);
       ns.addMappingAndRenderAttr(model, "instruction","http://foo/instruction",node1);
       ns.addMappingAndRenderAttr(model, "directory","http://foo.com/io/directory",node1);    		    
       ns.addMappingAndRenderAttr(model, "function","http://foo.com/function",node1);
       ns.addMappingAndRenderAttr(model, "xmlns","http://www.w3.org/1999/xhtml",node1);
       ns.addMappingAndRenderAttr(model, "ctrl","http://foo.com/controls",node1);
       ns.addMappingAndRenderAttr(model, "wiki","http://foo.com/samples/wiki",node1);
  		  
  }

}
