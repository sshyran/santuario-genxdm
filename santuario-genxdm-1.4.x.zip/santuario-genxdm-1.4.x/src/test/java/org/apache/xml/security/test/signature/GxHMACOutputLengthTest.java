/*
 * Copyright 2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.signature;

import java.io.File;
import java.io.FileInputStream;

import javax.crypto.SecretKey;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.xml.security.Init;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.signature.XMLSignatureException;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandler;
import org.genxdm.compat.DomCompatibility;

public class GxHMACOutputLengthTest<N> extends TestCase {

	private DocumentHandler<N> docHandler;
	private XmlContext<N> ctx;
	
    protected void setUp() throws Exception {
        Init.init();
        
        ctx = XmlTestContext.getContext();
        docHandler = ctx.docHandlerFactory.newDocumentHandler();
        
    }

    /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log =
        org.apache.commons.logging.LogFactory.getLog
            (GxHMACOutputLengthTest.class.getName());

    private static final String BASEDIR = System.getProperty("basedir", System.getProperty("user.dir"));
    private static final String SEP = System.getProperty("file.separator");

    public static Test suite() {
        return new TestSuite(GxHMACOutputLengthTest.class);
    }

    public GxHMACOutputLengthTest(String name) {
        super(name);
    }

    public static void main(String[] args) {
        String[] testCaseName = { "-noloading",
                                  GxHMACOutputLengthTest.class.getName() };

        junit.textui.TestRunner.main(testCaseName);
    }

    public void testGx_signature_enveloping_hmac_sha1_trunclen_0() throws Exception {
        try {
            validate("signature-enveloping-hmac-sha1-trunclen-0-attack.xml");
            fail("Expected HMACOutputLength exception");
        } catch (XMLSignatureException xse) {
            System.out.println(xse.getMessage());
            if (xse.getMsgID().equals("algorithms.HMACOutputLengthMin")) {
                // pass
            } else {
                fail(xse.getMessage());
            }
        }
    }
    public void testGx_signature_enveloping_hmac_sha1_trunclen_8() throws Exception {
        try {
            validate("signature-enveloping-hmac-sha1-trunclen-8-attack.xml");
        } catch (XMLSignatureException xse) {
            System.out.println(xse.getMessage());
            if (xse.getMsgID().equals("algorithms.HMACOutputLengthMin")) {
                // pass
            } else {
                fail(xse.getMessage());
            }
        }
    }

    private void validate(String data) throws Exception {
        System.out.println("Validating " + data);
        File file = new File(BASEDIR + SEP + "data" + SEP + "javax" + SEP + "xml" + SEP + "crypto" + SEP + "dsig" + SEP, data);

        N doc = docHandler.parse(new FileInputStream(file), null);
        
        N sigElement = DomCompatibility.getFirstDescendantOrSelfElementByName(
        		ctx.model, doc, Constants.SignatureSpecNS, "Signature");
        
        XMLSignature<N> signature = new XMLSignature<N>
            (ctx, sigElement, file.toURI().toString());
        SecretKey sk = signature.createSecretKey("secret".getBytes("ASCII"));
        System.out.println
            ("Validation status: " + signature.checkSignatureValue(sk));
    }

    public void testGx_generate_hmac_sha1_40() throws Exception {
        System.out.println("Generating ");

        XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
        N doc = testCtx.getNodeFactory().createDocument(null, null);
        XMLSignature<N> sig = new XMLSignature<N>
            (ctx, doc, null, XMLSignature.ALGO_ID_MAC_HMAC_SHA1, 40,
             Canonicalizer.ALGO_ID_C14N_OMIT_COMMENTS);
        try {
            sig.sign(getSecretKey("secret".getBytes("ASCII")));
            fail("Expected HMACOutputLength Exception");
        } catch (XMLSignatureException xse) {
            System.out.println(xse.getMessage());
            if (xse.getMsgID().equals("algorithms.HMACOutputLengthMin")) {
                // pass
            } else {
                fail(xse.getMessage());
            }
        }
    }

    @SuppressWarnings("serial")
	private static SecretKey getSecretKey(final byte[] secret) {
        return new SecretKey() {
            public String getFormat()   { return "RAW"; }
            public byte[] getEncoded()  { return secret; }
            public String getAlgorithm(){ return "SECRET"; }
        };
    }
}
