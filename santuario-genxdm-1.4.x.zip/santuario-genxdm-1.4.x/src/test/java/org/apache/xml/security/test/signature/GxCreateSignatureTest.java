/*
 * Copyright  1999-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.signature;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import org.apache.xml.security.algorithms.SignatureAlgorithm;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.signature.ObjectContainer;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.transforms.params.XPathContainer;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandler;
import org.genxdm.mutable.NodeFactory;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Tests that create signatures.
 * 
 * @author Sean Mullan
 */
public class GxCreateSignatureTest<N> extends TestCase {

	/** {@link org.apache.commons.logging} logging facility */
	static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory
			.getLog(GxCreateSignatureTest.class.getName());

	private static final String BASEDIR = System.getProperty("basedir");
	private static final String SEP = System.getProperty("file.separator");

	public static Test suite() {
		return new TestSuite(GxCreateSignatureTest.class);
	}

	public GxCreateSignatureTest(String name) {
		super(name);
	}

	public static void main(String[] args) {
		String[] testCaseName = { "-noloading",
				GxCreateSignatureTest.class.getName() };

		junit.textui.TestRunner.main(testCaseName);
	}

	/**
	 * Test for bug 36044 - Canonicalizing an empty node-set throws an
	 * ArrayIndexOutOfBoundsException.
	 */
	public void testGxEmptyNodeSet() throws Exception {

		NodeFactory<N> factory = testCtx.getNodeFactory();
		N doc = factory.createDocument(null, null);
		N envelope = factory.createElement("http://www.usps.gov/", "Envelope", "");
		ctx.mutableModel.appendChild(envelope, factory.createText("\n"));
		ctx.mutableModel.appendChild(doc, envelope);

		XMLSignature<N> sig = new XMLSignature<N>(ctx, doc, null,
				XMLSignature.ALGO_ID_SIGNATURE_DSA);

		ObjectContainer<N> object1 = new ObjectContainer<N>(ctx.mutableModel, doc);
		object1.setId("object-1");
		object1.setMimeType("text/plain");
		sig.appendObject(object1);

		ObjectContainer<N> object2 = new ObjectContainer<N>(ctx.mutableModel, doc);

		object2.setId("object-2");
		object2.setMimeType("text/plain");
		object2.setEncoding("http://www.w3.org/2000/09/xmldsig#base64");
		object2.appendChildNode(factory.createText("SSBhbSB0aGUgdGV4dC4="));
		sig.appendObject(object2);

		Transforms<N> transforms = new Transforms<N>(ctx.mutableModel, doc);
		XPathContainer<N> xpathC = new XPathContainer<N>(ctx.mutableModel, doc);

		xpathC.setXPath("self::text()");
		transforms.addTransform(Transforms.TRANSFORM_XPATH, xpathC
				.getElementWrappedByReturns());
		sig.addDocument("#object-1", transforms, Constants.ALGO_ID_DIGEST_SHA1,
				null, "http://www.w3.org/2000/09/xmldsig#Object");

		KeyStore ks = KeyStore.getInstance("JKS");
		FileInputStream fis = null;
		if (BASEDIR != null && !"".equals(BASEDIR)) {
			fis = new FileInputStream(BASEDIR + SEP
					+ "data/org/apache/xml/security/samples/input/keystore.jks");
		} else {
			fis = new FileInputStream(
					"data/org/apache/xml/security/samples/input/keystore.jks");
		}
		ks.load(fis, "xmlsecurity".toCharArray());
		PrivateKey privateKey = (PrivateKey) ks.getKey("test", "xmlsecurity"
				.toCharArray());

		sig.sign(privateKey);
	}

	private KeyPair kp = null;
	private XmlTestContext<N> testCtx;
	private XmlContext<N> ctx;
	private DocumentHandler<N> docHandler;

	protected void setUp() throws Exception {
		
		testCtx = XmlTestContext.getTestContext();
		ctx = XmlTestContext.getContext();
		docHandler = ctx.docHandlerFactory.newDocumentHandler();
		
		org.apache.xml.security.Init.init();
		kp = KeyPairGenerator.getInstance("RSA").genKeyPair();
	}

	public void testGxOne() throws Exception {
		doVerify(doSign());
		doVerify(doSign());
	}

	public void testGxTwo() throws Exception {
		doSignWithCert();
	}

	public void testGxWithNSPrefixDisabled() throws Exception {
		String prefix = Constants.getSignatureSpecNSprefix();
		try {
			Constants.setSignatureSpecNSprefix("");
			doSign();
			Constants.setSignatureSpecNSprefix(prefix);
		} catch (Exception e) {
			Constants.setSignatureSpecNSprefix(prefix);
			throw e;
		}
	}

	private String doSign() throws Exception {
		PrivateKey privateKey = kp.getPrivate();
		NodeFactory<N> factory = testCtx.getNodeFactory();
		N doc = factory.createDocument(null, null);
		ctx.mutableModel.appendChild(doc, factory.createComment(" Comment before "));
		N root = factory.createElement("", "RootElement", "");

		ctx.mutableModel.appendChild(doc, root);
		ctx.mutableModel.appendChild(root, factory.createText("Some simple text\n"));

		N canonElem = XMLUtils.createElementInSignatureSpace(factory,
				Constants._TAG_CANONICALIZATIONMETHOD);
		ctx.mutableModel.insertAttribute(canonElem, factory.createAttribute("", Constants._ATT_ALGORITHM, "",
				Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS));

		SignatureAlgorithm<N> signatureAlgorithm = new SignatureAlgorithm<N>(ctx.mutableModel, doc,
				XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA1, false);
		XMLSignature<N> sig = new XMLSignature<N>(ctx, doc, null, signatureAlgorithm
				.getElementNode(), canonElem);

		ctx.mutableModel.appendChild(root, sig.getElementNode());
		ctx.mutableModel.appendChild(doc, factory.createComment(" Comment after "));
		Transforms<N> transforms = new Transforms<N>(ctx.mutableModel, doc);
		transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
		transforms.addTransform(Transforms.TRANSFORM_C14N_WITH_COMMENTS);
		sig.addDocument("", transforms, Constants.ALGO_ID_DIGEST_SHA1);

		sig.addKeyInfo(kp.getPublic());
		sig.sign(privateKey);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		XMLUtils.outputDOMc14nWithComments(ctx.model, doc, bos);
		return new String(bos.toByteArray());
	}

	String doSignWithCert() throws Exception {
		KeyStore ks = KeyStore.getInstance("JKS");
		FileInputStream fis = null;
		if (BASEDIR != null && !"".equals(BASEDIR)) {
			fis = new FileInputStream(BASEDIR + SEP + "data/test.jks");
		} else {
			fis = new FileInputStream("data/test.jks");
		}
		ks.load(fis, "changeit".toCharArray());
		PrivateKey privateKey = (PrivateKey) ks.getKey("mullan", "changeit"
				.toCharArray());
		NodeFactory<N> factory = testCtx.getNodeFactory();
		N doc = factory.createDocument(null, null);
		X509Certificate signingCert = (X509Certificate) ks
				.getCertificate("mullan");
		ctx.mutableModel.appendChild(doc, factory.createComment(" Comment before "));
		N root = factory.createElement("", "RootElement", "");

		ctx.mutableModel.appendChild(doc, root);
		ctx.mutableModel.appendChild(root, factory.createText("Some simple text\n"));

		N canonElem = XMLUtils.createElementInSignatureSpace(factory,
				Constants._TAG_CANONICALIZATIONMETHOD);
		ctx.mutableModel.insertAttribute(canonElem, factory.createAttribute("", Constants._ATT_ALGORITHM, "",
				Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS));

		SignatureAlgorithm<N> signatureAlgorithm = new SignatureAlgorithm<N>(ctx.mutableModel, doc,
				XMLSignature.ALGO_ID_SIGNATURE_DSA, false);
		XMLSignature<N> sig = new XMLSignature<N>(ctx, doc, null, signatureAlgorithm
				.getElementNode(), canonElem);

		ctx.mutableModel.appendChild(root, sig.getElementNode());
		ctx.mutableModel.appendChild(doc, factory.createComment(" Comment after "));
		Transforms<N> transforms = new Transforms<N>(ctx.mutableModel, doc);
		transforms.addTransform(Transforms.TRANSFORM_ENVELOPED_SIGNATURE);
		transforms.addTransform(Transforms.TRANSFORM_C14N_WITH_COMMENTS);
		sig.addDocument("", transforms, Constants.ALGO_ID_DIGEST_SHA1);

		sig.addKeyInfo(signingCert);
		sig.sign(privateKey);
		X509Certificate cert = sig.getKeyInfo().getX509Certificate();
		sig.checkSignatureValue(cert.getPublicKey());
		ByteArrayOutputStream bos = new ByteArrayOutputStream();

		XMLUtils.outputDOMc14nWithComments(ctx.model, doc, bos);
		return new String(bos.toByteArray());
	}

	void doVerify(String signedXML) throws Exception {
		N doc = docHandler.parse(new ByteArrayInputStream(signedXML
				.getBytes()), null);
		Map<String, String> nsContext = new HashMap<String, String>();
		nsContext.put("ds", Constants.SignatureSpecNS);

		N sigElement = XmlTestContext.selectSingleNodeViaXPath(ctx.model, doc, "//ds:Signature[1]", nsContext);
		XMLSignature<N> signature = new XMLSignature<N>(ctx, sigElement, "");
		KeyInfo<N> ki = signature.getKeyInfo();

		if (ki == null) {
			throw new RuntimeException("No keyinfo");
		}
		PublicKey pk = signature.getKeyInfo().getPublicKey();

		if (pk == null) {
			throw new RuntimeException("No public key");
		}
		assertTrue(signature.checkSignatureValue(pk));
	}
}
