package org.apache.xml.security.test.gxml;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.axiom.om.impl.llom.factory.OMLinkedListImplFactory;
import org.apache.xml.security.transforms.implementations.XPathHelper;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.genxdm.ProcessingContext;
import org.genxdm.mutable.NodeFactory;
import org.genxdm.bridge.axiom.AxiomFactory;
import org.genxdm.bridge.axiom.AxiomMutableModel;
import org.genxdm.bridge.axiom.AxiomProcessingContext;
import org.genxdm.bridge.cx.base.XmlNodeContext;
import org.genxdm.bridge.cx.tree.XmlNode;
import org.genxdm.bridge.cx.tree.XmlNodeMutator;
import org.genxdm.bridge.dom.DomModelMutable;
import org.genxdm.bridge.dom.DomProcessingContext;
import org.genxdm.processor.xpath.v10.XPathToolkitFactoryImpl;
import org.genxdm.xpath.v10.ExprContextDynamicArgs;
import org.genxdm.xpath.v10.ExprContextStatic;
import org.genxdm.xpath.v10.ExprException;
import org.genxdm.xpath.v10.ExprParseException;
import org.genxdm.xpath.v10.NodeIterator;
import org.genxdm.xpath.v10.NodeSetExpr;
import org.genxdm.xpath.v10.XPathCompiler;
import org.genxdm.xpath.v10.XPathToolkit;
import org.genxdm.xpath.v10.XPathToolkitFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 * This class exists to let us choose, from the command line, which gXML bridge
 * we want to actually run tests with.
 */
public abstract class XmlTestContext<N> {

	protected XmlTestContext(ProcessingContext<N> pcx) {
		m_pcx = pcx;
	}
	
	public abstract XmlContext<N> getXmlContext();
	
	public N createAttributeWithValue(String ns, String localName, String value) {
		return getNodeFactory().createAttribute(ns, localName, null, value);
	}
	
	public ProcessingContext<N> getProcessingContext() {
		return m_pcx;
	}
	
	public NodeFactory<N> getNodeFactory() {
		return m_pcx.getMutableContext().getNodeFactory();
	}
	
	/**
	 * Get an XPathToolkitFactory to use for tests.
	 * @return
	 */
	public static XPathToolkitFactory
		getXPathFactory() {
		return new XPathToolkitFactoryImpl();
		
	}
	
	public static <N> Set<N> selectNodesViaXPath(Model<N> model, N docNode, String xpathStr, Map<String, String> nsContext)
			throws ExprParseException, ExprException {
		NodeIterator<N> nodeIter = xpathSelect(model, docNode, xpathStr,
				nsContext);
		Set<N> nodeSet = new HashSet<N>();
	
		return XPathHelper.nodeIteratorIntoCollection(nodeIter, nodeSet);
	}

	public static <N> N selectSingleNodeViaXPath(Model<N> model, N docNode, String xpathStr, Map<String, String> nsContext)
	throws ExprParseException, ExprException {
		
		NodeIterator<N> nodeIter = xpathSelect(model, docNode, xpathStr, nsContext);
		return nodeIter.next();
	}

	private static <N> NodeIterator<N> xpathSelect(Model<N> model, N docNode,
			String xpathStr, Map<String, String> nsContext)
			throws ExprParseException, ExprException {
		XPathToolkitFactory factory = getXPathFactory();
		XPathToolkit toolkit = factory.newXPathToolkit();
		XPathCompiler compiler = toolkit.newXPathCompiler();
		ExprContextStatic staticArgs = toolkit.newExprContextStaticArgs();
		ExprContextDynamicArgs<N> dynArgs = toolkit.newExprContextDynamicArgs();
	
		// Add the namespace mappings requested by the caller, if any.
		if (nsContext != null) {
			for (Map.Entry<String, String> mapping : nsContext.entrySet()) {
				staticArgs.declareNamespace(mapping.getKey(), mapping.getValue());
			}
		}
	
		// compile the expression.
		NodeSetExpr expr =
			compiler.compileNodeSetExpr( xpathStr, staticArgs );
		NodeIterator<N> nodeIter = expr.nodeIterator(model, docNode, dynArgs.build());
		return nodeIter;
	}

	public static class AxiomTestContext extends XmlTestContext<Object> {

		private final XmlContext<Object> xmlContext;
		
		public AxiomTestContext() {
			super( new AxiomProcessingContext( new OMLinkedListImplFactory()));
			AxiomFactory factory = new AxiomFactory(new OMLinkedListImplFactory());
			xmlContext = new XmlContext<Object>(getProcessingContext(), new AxiomMutableModel(factory));
		}

		@Override
		public XmlContext<Object> getXmlContext() {
			return xmlContext;
		}
		
	}
	

	public static class CxTestContext extends XmlTestContext<XmlNode> {

		private final XmlContext<XmlNode> xmlContext;
		
		public CxTestContext() {
			super( new XmlNodeContext() );
			xmlContext = new XmlContext<XmlNode>(getProcessingContext(), new XmlNodeMutator());
		}

		@Override
		public XmlContext<XmlNode> getXmlContext() {
			return xmlContext;
		}
		
	}
	
	public static class DomTestContext extends XmlTestContext<Node> {

		private XmlContext<Node> xmlContext;
		
		public DomTestContext() {
			super( new DomProcessingContext());
			try {
				DomProcessingContext domPcx = (DomProcessingContext) getProcessingContext();
				doc = domPcx.getDocumentBuilderFactory().newDocumentBuilder().newDocument();
			} catch (ParserConfigurationException e) {
				throw new IllegalStateException(e);
			}
			
			xmlContext = new XmlContext<Node>(getProcessingContext(), new DomModelMutable());
		}
		

		@Override
		public Node createAttributeWithValue(String ns, String localName,
				String value) {
			Attr attrib = doc.createAttributeNS(ns, localName);
			attrib.setNodeValue(value);
			return attrib;
		}
		
		private Document doc;

		@Override
		public XmlContext<Node> getXmlContext() {
			return xmlContext;
		}
	}

	private ProcessingContext<N> m_pcx;
	
	@SuppressWarnings("unchecked")
	public static <N> XmlTestContext<N> getTestContext() {
		// TODO - look for a system property, and choose the implementation based on that.
		//XmlTestContext bland = new DomTestContext();
		XmlTestContext bland = new CxTestContext();
		//XmlTestContext bland = new AxiomTestContext();
		return (XmlTestContext<N>) bland;
	}
	
	/**
	 * Utility method for testing that doesn't need the full XmlTestContext, just the context.
	 * @param <N>
	 * @return
	 */
	public static <N> XmlContext<N> getContext() {
		XmlTestContext<N> testCtx = getTestContext();
		return testCtx.getXmlContext();
	}
}
