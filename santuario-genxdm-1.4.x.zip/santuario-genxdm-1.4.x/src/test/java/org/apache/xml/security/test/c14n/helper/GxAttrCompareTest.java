package org.apache.xml.security.test.c14n.helper;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.helper.AttrInfoComparator;
import org.apache.xml.security.c14n.implementations.AttrInfo;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GxAttrCompareTest extends TestCase {

	   /**
	    * Method suite
	    *
	    * @return
	    */
	   public static Test suite() {
	      return new TestSuite(GxAttrCompareTest.class);
	   }

	   /**
	    * Constructor AttrCompareTest
	    *
	    * @param Name_
	    */
	   public GxAttrCompareTest(String Name_) {
	      super(Name_);
	   }

	   /**
	    * Method main
	    *
	    * @param args
	    */
	   public static void main(String[] args) {

	      String[] testCaseName = { "-noloading", GxAttrCompareTest.class.getName() };

	      junit.textui.TestRunner.main(testCaseName);
	   }

	   /**
	    * Method createDoc
	 * @param model TODO
	 * @param documentElement
	    *
	    * @return
	    * @throws ParserConfigurationException
	    */
	   private static <N> N createDoc(MutableModel<N> model, NodeFactory<N> factory, String documentElement)
	           throws ParserConfigurationException {

		   
		   N doc = factory.createDocument(null, null);
		   N root = factory.createElement("", documentElement, "");

		   model.appendChild(doc, root);

	      return doc;
	   }

	   /**
	    * Method testA1
	    *
	    * @throws ParserConfigurationException
	    */
	   public static <N> void testGxA1() throws ParserConfigurationException {

		   XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
		   NodeFactory<N> factory = testCtx.getNodeFactory();
		   MutableModel<N> model = testCtx.getXmlContext().mutableModel;
		   
	      N doc = createDoc(model, factory, "documentElement");
	      N root = model.getFirstChildElement(doc);
	      
	      N attr0 = model.insertNamespace(root, "", "http://default/");
	      N attr1 = model.insertNamespace(root, "b", "http://val1/");

	      List<N> nsDecls = new ArrayList<N>();
	      for (N nsDecl : model.getNamespaceAxis(root, false)) {
	    	  nsDecls.add(nsDecl);
	      }
	      
	      model.getNamespaceAxis(root, false);

	      N attr00 = nsDecls.get(0);
	      N attr10 = nsDecls.get(1);

	      assertNotNull("Attribute attr00", attr00);
	      assertNotNull("Attribute attr10", attr10);

	      AttrInfoComparator attrCompare = new AttrInfoComparator();

	      AttrInfo wrap0 = AttrInfo.createAttribute(model, attr0);
	      AttrInfo wrap1 = AttrInfo.createAttribute(model, attr1);

	      assertTrue(attr0 + " < " + attr1, attrCompare.compare(wrap0, wrap1) < 0);
	      assertTrue(attr1 + " < " + attr0, attrCompare.compare(wrap1, wrap0) > 0);
	   }

	   public static <N> void testGxA2() throws ParserConfigurationException {

		   XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
		   NodeFactory<N> factory = testCtx.getNodeFactory();
		   MutableModel<N> model = testCtx.getXmlContext().mutableModel;
		   		   
	      N doc = createDoc(model, factory, "documentElement");
	      
	      N attr0 = factory.createAttribute("", "foo", "", "anything");
	      N attr1 = factory.createAttribute("http://goo", "foo", "goo", "anything");

	      AttrInfoComparator attrCompare = new AttrInfoComparator();

	      AttrInfo wrap0 = AttrInfo.createAttribute(model, attr0);
	      AttrInfo wrap1 = AttrInfo.createAttribute(model, attr1);

	      assertTrue(attr0 + " < " + attr1, attrCompare.compare(wrap0, wrap1) < 0);
	      assertTrue(attr1 + " < " + attr0, attrCompare.compare(wrap1, wrap0) > 0);

	   }


	   /**
	    * Method testA2
	    *
	    * @throws ParserConfigurationException
	    */
	   public static <U, N> void _testA2() throws ParserConfigurationException {

		   XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
		   NodeFactory<N> factory = testCtx.getNodeFactory();
		   MutableModel<N> model = testCtx.getXmlContext().mutableModel;
		   		   
	      N doc = createDoc(model, factory, "documentElement");
	      N root = model.getFirstChildElement(doc);
	      
	      N attr0 = factory.createAttribute("", "aAttr", "", "val0");
	      model.insertAttribute(root, attr0);
	      N attr1 = factory.createAttribute("", "bAttr", "", "val1");
	      model.insertAttribute(root, attr1);

	      List<N> attrDecls = new ArrayList<N>();
	      for (N nsDecl : model.getAttributeAxis(doc, false)) {
	    	  attrDecls.add(nsDecl);
	      }
	      
	      assertEquals("attrDecls.size()", attrDecls.size(), 2);

	      N attr00 = attrDecls.get(0);
	      N attr10 = attrDecls.get(1);

	      assertNotNull("Attribute attr00", attr00);
	      assertNotNull("Attribute attr10", attr10);

	      AttrInfoComparator attrCompare = new AttrInfoComparator();

	      AttrInfo wrap0 = AttrInfo.createAttribute(model, attr0);
	      AttrInfo wrap1 = AttrInfo.createAttribute(model, attr1);

	      assertTrue(attr0 + " < " + attr1, attrCompare.compare(wrap0, wrap1) < 0);
	      assertTrue(attr1 + " < " + attr0, attrCompare.compare(wrap1, wrap0) > 0);
	   }

	   /**
	    * This test uses the attrs[] array to compare every attribute against
	    * the others (and vice versa).
	    *
	    * The attribute values are taken from example 3.3 Start and End Tags
	    * http://www.w3.org/TR/2001/REC-xml-c14n-20010315#Example-SETags
	    *
	    * @throws ParserConfigurationException
	    */
	   public static <U, N> void testGxComplete() throws ParserConfigurationException {

	      /* <e5 xmlns="http://example.org"
	       *     xmlns:a="http://www.w3.org"
	       *     xmlns:b="http://www.ietf.org"
	       *     attr="I'm"
	       *     attr2="all"
	       *     b:attr="sorted"
	       *     a:attr="out"></e5>
	       */
		   
	      // This List has to be ordered to verify correctness of the comparison
	      //J-
	      List<AttrInfo > attrs = new ArrayList<AttrInfo>();
	      attrs.add(AttrInfo.createNamespace(null, "", "http://example.org") );
	      attrs.add(AttrInfo.createNamespace(null, "a", "http://www.w3.org") );
	      attrs.add(AttrInfo.createNamespace(null, "b", "http://www.ietf.org") );
	      attrs.add(AttrInfo.createAttribute(null, "", "attr", "", "I'm") );
	      attrs.add(AttrInfo.createAttribute(null, "", "attr2", "", "all") );
	      attrs.add(AttrInfo.createAttribute(null,"http://www.ietf.org", "attr", "b", "sorted") );
	      attrs.add(AttrInfo.createAttribute(null, "http://www.w3.org", "attr", "a", "out") );

	      AttrInfoComparator attrCompare = new AttrInfoComparator();

	      for (int i = 0; i < attrs.size(); i++) {
	         for (int j = i + 1; j < attrs.size(); j++) {
	            AttrInfo attr0 = attrs.get(i);
	            AttrInfo attr1 = attrs.get(j);
	            assertTrue(attr0 + " < " + attr1, attrCompare.compare(attr0, attr1) < 0);
	            assertTrue(attr1 + " < " + attr0, attrCompare.compare(attr1, attr0) > 0);
	         }
	      }
	   }

	   static {
	      org.apache.xml.security.Init.init();
	   }
}
