
/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.c14n.implementations;



import java.io.File;
import java.io.FileInputStream;

import junit.framework.Test;
import junit.framework.TestSuite;

import org.apache.xml.security.signature.Reference;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.test.interop.GxInteropTest;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.JavaUtils;
import org.genxdm.compat.DomCompatibility;


/**
 * Interop test for exclusive canonical XML.
 *
 * @author Christian Geuer-Pollmann
 */
public class GxExclusiveC14NInterop<N> extends GxInteropTest<N> {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(GxExclusiveC14NInterop.class.getName());

    static {
        org.apache.xml.security.Init.init();
    }
   /**
    * Method suite
    *
    *
    */
   public static Test suite() {
      return new TestSuite(GxExclusiveC14NInterop.class);
   }

   /**
    *  Constructor GxExclusiveC14NInterop
    *
    *  @param Name_
    */
   public GxExclusiveC14NInterop(String Name_) {
      super(Name_);
   }

   /**
    * Method main
    *
    * @param args
    */
   public static void main(String[] args) {

      String[] testCaseName = { "-noloading",
                                GxExclusiveC14NInterop.class.getName() };

      org.apache.xml.security.Init.init();
      junit.textui.TestRunner.main(testCaseName);
   }

   /**
    * Method test_Y4
    *
    * @throws Exception
    */
   public void test_Y4Gx() throws Exception {

      String success = t("data/interop/c14n/Y4", "signature.xml");

      assertTrue(success, success == null);
   }

   /**
    * Method test_Y1
    *
    * @throws Exception
    */
   public void test_Y1Gx() throws Exception {

      String success = t("data/interop/c14n/Y1", "exc-signature.xml");

      assertTrue(success, success == null);
   }

   /**
    * Method test_Y2
    *
    * @throws Exception
    */
   public void test_Y2Gx() throws Exception {

      String success = t("data/interop/c14n/Y2", "signature-joseph-exc.xml");

      assertTrue(success, success == null);
   }

   /**
    * Method test_Y3
    *
    * @throws Exception
    */
   public void test_Y3Gx() throws Exception {

      String success = t("data/interop/c14n/Y3", "signature.xml");

      assertTrue(success, success == null);
   }

   public void test_xfilter2Gx() throws Exception {

      String success = t("data/interop/xfilter2/merlin-xpath-filter2-three", "sign-spec.xml");

      assertTrue(success, success == null);
   }

   /**
    * Method t
    *
    * @param directory
    * @param file
    *
    * @throws Exception
    */
   public String t(String directory, String file) throws Exception
   {
   	  String basedir = System.getProperty("basedir");
   	  if(basedir != null && !"".equals(basedir)) {
   	  	directory = basedir + "/" + directory;
   	  }

      File f = new File(directory + "/" + file);

      N doc = docHandler.parse( new FileInputStream(f), f.toURI());
      
      N sigElement = DomCompatibility.getFirstDescendantOrSelfElementByName(
    		  m_ctx.model, doc, Constants.SignatureSpecNS, Constants._TAG_SIGNATURE);
      XMLSignature<N> signature = new XMLSignature<N>(m_ctx, sigElement,
                                                f.toURI().toString());
      boolean verify =
         signature.checkSignatureValue(signature.getKeyInfo().getPublicKey());

      log.debug("   signature.checkSignatureValue finished: " + verify);

      int failures = 0;

      // if (!verify) {
         StringBuffer sb = new StringBuffer();

         for (int i = 0; i < signature.getSignedInfo().getLength(); i++) {
            boolean refVerify =
               signature.getSignedInfo().getVerificationResult(i);
            JavaUtils.writeBytesToFilename(directory + "/c14n-" + i + ".apache.html", signature.getSignedInfo().item(i).getHTMLRepresentation().getBytes());

            if (refVerify) {
               log.debug("Reference " + i + " was OK");
            } else {
               failures++;

               sb.append(i + " ");

               JavaUtils.writeBytesToFilename(directory + "/c14n-" + i + ".apache.txt", signature.getSignedInfo().item(i).getContentsAfterTransformation().getBytes());
               JavaUtils.writeBytesToFilename(directory + "/c14n-" + i + ".apache.html", signature.getSignedInfo().item(i).getHTMLRepresentation().getBytes());

               Reference<N> reference = signature.getSignedInfo().item(i);
               int length = reference.getTransforms().getLength();
               String algo = reference.getTransforms().item(length
                  - 1).getURI();

               log.debug("Reference " + i + " failed: " + algo);
            }
         }

         String r = sb.toString().trim();

         return r.length() == 0 ? null : r;
//      } else {
//         return null;
//      }
   	}
}
