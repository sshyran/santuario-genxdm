/*
 * Copyright  1999-2007 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.signature;

import java.io.File;
import java.io.FileInputStream;
import java.security.PublicKey;
import org.apache.xml.security.keys.KeyInfo;
import org.apache.xml.security.keys.content.KeyValue;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandler;
import org.genxdm.compat.DomCompatibility;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GxKeyValueTest<N> extends TestCase {

	private static final String BASEDIR = System.getProperty("basedir");
	private static final String SEP = System.getProperty("file.separator");

	private XmlContext<N> ctx;
	private DocumentHandler<N> docHandler;
	
	public GxKeyValueTest(String name) {
		super(name);
	}

	public static Test suite() {
		TestSuite suite = new TestSuite(GxKeyValueTest.class);
		return suite;
	}

	public void setUp() throws Exception {
		ctx = XmlTestContext.getContext();
		docHandler = ctx.docHandlerFactory.newDocumentHandler();
	}

	public void testGxDSAPublicKey() throws Exception {

		File f = null;
		if (BASEDIR != null && !"".equals(BASEDIR)) {
			f = new File(
					BASEDIR
							+ SEP
							+ "data/ie/baltimore/merlin-examples/merlin-xmldsig-twenty-three/signature-enveloping-dsa.xml");
		} else {
			f = new File(
					"data/ie/baltimore/merlin-examples/merlin-xmldsig-twenty-three/signature-enveloping-dsa.xml");
		}
		N doc = docHandler.parse(new FileInputStream(f), f.toURI());
		N sigElem = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model, doc, Constants.SignatureSpecNS, "Signature");
		XMLSignature<N> sig = new XMLSignature<N>(ctx, sigElem, f.toURI().toString());
		KeyInfo<N> ki = sig.getKeyInfo();
		KeyValue<N> kv = ki.itemKeyValue(0);
		PublicKey pk = kv.getPublicKey();
		assertNotNull(pk);
	}
}
