/*
 * Copyright  1999-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.external.org.apache.xalan.XPathAPI;

import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandler;
import org.genxdm.xpath.v10.BooleanExpr;
import org.genxdm.xpath.v10.ExprContextDynamicArgs;
import org.genxdm.xpath.v10.ExprContextStatic;
import org.genxdm.xpath.v10.XPathCompiler;
import org.genxdm.xpath.v10.XPathToolkit;
import org.genxdm.xpath.v10.XPathToolkitFactory;

/**
 * This test is to ensure that the owner element of an Attribute is on the
 * ancestor-or-self axis.
 * 
 * @author $Author: coheigea $
 */
public class GxAttributeAncestorOrSelfTest<N> extends TestCase {

	/** {@link org.apache.commons.logging} logging facility */
	static org.apache.commons.logging.Log log = org.apache.commons.logging.LogFactory
			.getLog(GxAttributeAncestorOrSelfTest.class.getName());

	private XmlContext<N> ctx;
	private DocumentHandler<N> docHandler;
	
	/**
	 * Method suite
	 * 
	 * 
	 */
	public static Test suite() {
		return new TestSuite(GxAttributeAncestorOrSelfTest.class);
	}

	/**
	 * Constructor AttributeAncestorOrSelf
	 * 
	 * @param Name_
	 */
	public GxAttributeAncestorOrSelfTest(String Name_) {
		super(Name_);
	}

	/**
	 * Method main
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		String[] testCaseName = { "-noloading",
				GxAttributeAncestorOrSelfTest.class.getName() };

		junit.textui.TestRunner.main(testCaseName);
	}

	@Override
	protected void setUp() throws Exception {
		ctx = XmlTestContext.getContext();
		docHandler = ctx.docHandlerFactory.newDocumentHandler();
	}

	/**
	 * Process input args and execute the XPath.
	 * 
	 * @param xmlString
	 * @param ctxNodeStr
	 * @param evalStr
	 * 
	 * @throws Exception
	 */
	private boolean isAncestorOf(String xmlString, String ctxNodeStr,
			String evalStr) throws Exception {

		N document = docHandler.parse(new ByteArrayInputStream(_nodeSetInput1
				.getBytes()), null);
		Map<String, String> nsCtx = new HashMap<String, String>();
		nsCtx.put("ds", "http://www.w3.org/2000/09/xmldsig#");

		N ctxNode = XmlTestContext.selectSingleNodeViaXPath(ctx.model, document, ctxNodeStr, nsCtx);

		XPathToolkitFactory factory = XmlTestContext.getXPathFactory();
		XPathToolkit toolkit = factory.newXPathToolkit();
		XPathCompiler compiler = toolkit.newXPathCompiler();
		ExprContextStatic staticArgs = toolkit.newExprContextStaticArgs();
		ExprContextDynamicArgs<N> dynArgs = toolkit.newExprContextDynamicArgs();
	
		// Add the namespace mappings requested by the caller, if any.
		for (Map.Entry<String, String> mapping : nsCtx.entrySet()) {
			staticArgs.declareNamespace(mapping.getKey(), mapping.getValue());
		}
	
		// compile the expression.
		BooleanExpr bool = compiler.compileBooleanExpr(evalStr, staticArgs);

		// now evaluate
		return bool.booleanFunction(ctx.model, ctxNode, dynArgs.build());
	}

	// J-
	static final String _nodeSetInput1 = "<?xml version=\"1.0\"?>\n"
			+ "<ds:Signature xmlns:ds='http://www.w3.org/2000/09/xmldsig#'>"
			+ "\n" + "<ds:Object Id='id1'>" + "\n"
			+ "<!-- the comment -->and text" + "</ds:Object>" + "\n"
			+ "</ds:Signature>";

	// J+

	/**
	 * Method test01
	 * 
	 * @throws Exception
	 */
	public void testGxXPath01() throws Exception {

		String ctxNodeStr = "/ds:Signature/ds:Object";
		String evalStr = "ancestor-or-self::ds:Signature";

		assertTrue("Bad " + ctxNodeStr + " " + evalStr + "  ", isAncestorOf(
				_nodeSetInput1, ctxNodeStr, evalStr));
	}

	/**
	 * Method test02
	 * 
	 * @throws Exception
	 */
	public void testGxXPath02() throws Exception {

		String ctxNodeStr = "/ds:Signature/ds:Object/text()";
		String evalStr = "ancestor-or-self::ds:Signature";

		assertTrue("Bad " + ctxNodeStr + " " + evalStr + "  ", isAncestorOf(
				_nodeSetInput1, ctxNodeStr, evalStr));
	}

	/**
	 * Method test03
	 * 
	 * @throws Exception
	 */
	public void testGxXPath03() throws Exception {

		String ctxNodeStr = "/ds:Signature/ds:Object/@Id";
		String evalStr = "ancestor-or-self::ds:Object";

		assertTrue("Bad " + ctxNodeStr + " " + evalStr + "  ", isAncestorOf(
				_nodeSetInput1, ctxNodeStr, evalStr));
	}

	static {
		org.apache.xml.security.Init.init();
	}
}
