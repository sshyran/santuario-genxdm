/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.xml.security.test.c14n.implementations;


import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.xml.security.Init;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandler;

/**
 * This is a test for Santuario-273:
 * 
 * https://issues.apache.org/jira/browse/SANTUARIO-273
 * "xml:base attribute not processed correctly in C14N11 canonicalization"
 */
public class GxSantuario273Test extends TestCase {
    
    static {
        Init.init();
    }
    
    public static Test suite() {
        return new TestSuite(GxSantuario273Test.class);
    }

    /**
     * This test is kind of a silly one to carry over from the official project, because
     * the port of the canonicalization code makes sure that the underlying document isn't
     * changed - simply by passing the immutable untyped model, instead of the mutable one.
     * 
     * @param <N>
     * @throws Exception
     */
    public <N> void testC14n11Base_gx() throws Exception {

        XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
        XmlContext<N> xmlCtx = testCtx.getXmlContext();
        
        byte inputBytes[] = Santuario273Test.input.getBytes();
        DocumentHandler<N> docHandler = xmlCtx.docHandlerFactory.newDocumentHandler();
        N doc = docHandler.parse(new ByteArrayInputStream(inputBytes), null);
        
        Canonicalizer c14n =
            Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N11_OMIT_COMMENTS);

        Map<String, String> nscontext = new HashMap<String, String>();
        nscontext.put("ds", Constants.SignatureSpecNS);
        
        N signedInfo = XmlTestContext.selectSingleNodeViaXPath(xmlCtx.model, doc, "//ds:SignedInfo", nscontext);
        byte[] output = c14n.canonicalizeSubtree(xmlCtx.model, signedInfo);

        assertEquals( new String(output, "UTF-8"), Santuario273Test.expectedResult);
    }

}
