package org.apache.xml.security.test.algorithms;

import java.security.KeyPairGenerator;
import java.security.PrivateKey;

import org.apache.xml.security.algorithms.SignatureAlgorithm;
import org.apache.xml.security.signature.XMLSignature;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.utils.XmlContext;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GxSignatureAlgorithmTest<N> extends TestCase {

	static {
	    org.apache.xml.security.Init.init();
	}

	public void testGxSameKeySeveralAlgorithSigning() throws Exception {
		XmlTestContext<N> testCtx = XmlTestContext.getTestContext();
		XmlContext<N> ctx = XmlTestContext.getContext();
		N doc = testCtx.getNodeFactory().createDocument(null, null);
		SignatureAlgorithm<N> signatureAlgorithm = new SignatureAlgorithm<N>(ctx.mutableModel, doc,XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA1, false);
		PrivateKey pk=KeyPairGenerator.getInstance("RSA").genKeyPair().getPrivate();
		signatureAlgorithm.initSign(pk);
		signatureAlgorithm.update((byte)2);
		signatureAlgorithm.sign();
		SignatureAlgorithm<N> otherSignatureAlgorithm = new SignatureAlgorithm<N>(ctx.mutableModel, doc,XMLSignature.ALGO_ID_SIGNATURE_RSA_SHA256, false);
		otherSignatureAlgorithm.initSign(pk);
		otherSignatureAlgorithm.update((byte)2);
		otherSignatureAlgorithm.sign();
	}
	public static Test suite() {
		return new TestSuite(GxSignatureAlgorithmTest.class);
	}
}
