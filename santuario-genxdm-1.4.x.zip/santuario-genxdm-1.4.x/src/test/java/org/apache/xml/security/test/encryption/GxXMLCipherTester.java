/*
 * Copyright 1999-2007 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.test.encryption;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.security.Key;
import java.security.KeyPairGenerator;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.SecretKeySpec;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.apache.xml.security.algorithms.JCEMapper;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.encryption.EncryptedData;
import org.apache.xml.security.encryption.EncryptedKey;
import org.apache.xml.security.encryption.EncryptionMethod;
import org.apache.xml.security.encryption.CipherData;
import org.apache.xml.security.test.gxml.XmlTestContext;
import org.apache.xml.security.transforms.params.XPathContainer;
import org.apache.xml.security.utils.EncryptionConstants;
import org.apache.xml.security.utils.IdResolver;
import org.apache.xml.security.utils.XmlContext;
import org.apache.xml.security.keys.KeyInfo;
import org.genxdm.io.DocumentHandler;
import org.genxdm.mutable.NodeFactory;
import org.genxdm.compat.DomCompatibility;

/**
 *
 * @author  Axl Mattheus
 * @author  Berin Lautenbach
 */
public class GxXMLCipherTester<N> extends TestCase {

    /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(GxXMLCipherTester.class.getName());
    
    private String documentName;
    private String elementName;
    private String elementIndex;
    private XMLCipher<N> cipher;
    private String basedir;
    private boolean haveISOPadding;
    private boolean haveKeyWraps;
    private String tstBase64EncodedString;

    private XmlTestContext<N> testCtx;
    private XmlContext<N> ctx;
    private DocumentHandler<N> docHandler;
    
    public GxXMLCipherTester(String test) {
       super(test);
    }

    protected void setUp() {
    	
    	testCtx = XmlTestContext.getTestContext();
    	ctx = XmlTestContext.getContext();
    	docHandler = ctx.docHandlerFactory.newDocumentHandler();
    	
        basedir = System.getProperty("basedir",".");
        documentName = System.getProperty("org.apache.xml.enc.test.doc",
            basedir + "/build.xml");
        elementName = System.getProperty("org.apache.xml.enc.test.elem",
            "path");
        elementIndex = System.getProperty("org.apache.xml.enc.test.idx",
            "0");

		tstBase64EncodedString = new String("YmNkZWZnaGlqa2xtbm9wcRrPXjQ1hvhDFT+EdesMAPE4F6vlT+y0HPXe0+nAGLQ8");

		// Determine if we have ISO 10126 Padding - needed for Bulk AES or
		// 3DES encryption

		haveISOPadding = false;
		String algorithmId = 
			JCEMapper.translateURItoJCEID(org.apache.xml.security.utils.EncryptionConstants.ALGO_ID_BLOCKCIPHER_AES128);

		if (algorithmId != null) {
			try {
				if (Cipher.getInstance(algorithmId) != null)
					haveISOPadding = true;
			} catch (NoSuchAlgorithmException nsae) {
			} catch (NoSuchPaddingException nspe) {
			}
		}

		haveKeyWraps = (JCEMapper.translateURItoJCEID(org.apache.xml.security.utils.EncryptionConstants.ALGO_ID_KEYWRAP_AES128) != null);

    }

    protected void tearDown() {
    }

    private N document() {
        N d = null;
        try {
            File f = new File(documentName);
            d = docHandler.parse( new FileInputStream(f), f.toURI());
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }

        return (d);
    }

    private String element() {
        return (elementName);
    }

    private int index() {
        int result = -1;

        try {
            result = Integer.parseInt(elementIndex);
        } catch (NumberFormatException nfe) {
            nfe.printStackTrace();
            System.exit(-1);
        }

        return (result);
    }

    private N getChosenElement(N doc) {
    	
    	Iterable<N> matching = DomCompatibility.getDescendantOrSelfElementsByName(ctx.model, doc, "", element());
    	int count = index();
    	N result = null;
    	for ( N item : matching) {
    		result = item;
    		count--;
    		if (count < 0)
    			break;
    	}
    	
    	return result;
    }
    
	/**
	 * Test encryption using a generated AES 128 bit key that is
	 * encrypted using a AES 192 bit key.  Then reverse using the KEK
	 */

	public void testGxAES128ElementAES192KWCipherUsingKEK() throws Exception {

		N d = document(); // source
		N ed = null;
		N dd = null;
		N e = getChosenElement(d);
		N ee = null;

		String source = null;
		String target = null;

        if (haveISOPadding && haveKeyWraps) {

			source = toString(d);

			// Set up a Key Encryption Key
			byte[] bits192 = "abcdefghijklmnopqrstuvwx".getBytes();
			Key kek = new SecretKeySpec(bits192, "AES");

			// Generate a traffic key
			KeyGenerator keygen = KeyGenerator.getInstance("AES");
			keygen.init(128);
			Key key = keygen.generateKey();

            cipher = XMLCipher.getInstance(XMLCipher.AES_192_KeyWrap);
			cipher.init(XMLCipher.WRAP_MODE, kek);
			EncryptedKey<N> encryptedKey = cipher.encryptKey(ctx, d, key);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_128);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
			EncryptedData<N> builder = cipher.getEncryptedData();

			KeyInfo<N> builderKeyInfo = builder.getKeyInfo();
			if (builderKeyInfo == null) {
				builderKeyInfo = new KeyInfo<N>(ctx, d);
				builder.setKeyInfo(builderKeyInfo);
			}

			builderKeyInfo.add(encryptedKey);

            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
			key = null;
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
            
            cipher = XMLCipher.getInstance(XMLCipher.AES_128);
            cipher.init(XMLCipher.DECRYPT_MODE, null);
			cipher.setKEK(kek);
			dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);

			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testAES128ElementAES192KWCipherUsingKEK skipped as necessary algorithms not available");
		}
    }
  
	/**
	 * Test encryption using a generated AES 256 bit key that is
	 * encrypted using an RSA key.  Reverse using KEK
	 */

	public void testGxAES128ElementRSAKWCipherUsingKEK() throws Exception {

		N d = document(); // source
		N ed = null;
		N dd = null;
		N e = getChosenElement(d);
		N ee = null;

		String source = null;
		String target = null;

        if (haveISOPadding) {

			source = toString(d);

            // Generate an RSA key
            KeyPairGenerator rsaKeygen = KeyPairGenerator.getInstance("RSA");
            KeyPair kp = rsaKeygen.generateKeyPair();
            PrivateKey priv = kp.getPrivate();
            PublicKey pub = kp.getPublic();
            
			// Generate a traffic key
			KeyGenerator keygen = KeyGenerator.getInstance("AES");
			keygen.init(256);
			Key key = keygen.generateKey();

            
            cipher = XMLCipher.getInstance(XMLCipher.RSA_v1dot5);
			cipher.init(XMLCipher.WRAP_MODE, pub);
			EncryptedKey<N> encryptedKey = cipher.encryptKey(ctx, d, key);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_256);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
			EncryptedData<N> builder = cipher.getEncryptedData();

			KeyInfo<N> builderKeyInfo = builder.getKeyInfo();
			if (builderKeyInfo == null) {
				builderKeyInfo = new KeyInfo<N>(ctx, d);
				builder.setKeyInfo(builderKeyInfo);
			}

			builderKeyInfo.add(encryptedKey);

            ed = cipher.doFinalElement(ctx, d, e);
            log.debug("Encrypted document");
            log.debug(toString(ed));


            //decrypt
			key = null;
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
            cipher = XMLCipher.getInstance(XMLCipher.AES_128);
            cipher.init(XMLCipher.DECRYPT_MODE, null);
			cipher.setKEK(priv);
			dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);
            log.debug("Output document");
            log.debug(target);

			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testAES128ElementRSAKWCipherUsingKEK skipped as necessary algorithms not available");
		}
    }

	/**
	 * Test encryption using a generated AES 192 bit key that is
	 * encrypted using a 3DES key.  Then reverse by decrypting 
	 * EncryptedKey by hand
	 */

	public void testGxAES192ElementAES256KWCipher() throws Exception {

		N d = document(); // source
		N ed = null;
		N dd = null;
		N e = getChosenElement(d);
		N ee = null;

		String source = null;
		String target = null;

        if (haveISOPadding && haveKeyWraps) {

			source = toString(d);

			// Set up a Key Encryption Key
			byte[] bits192 = "abcdefghijklmnopqrstuvwx".getBytes();
            DESedeKeySpec keySpec = new DESedeKeySpec(bits192);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            Key kek = keyFactory.generateSecret(keySpec);

			// Generate a traffic key
			KeyGenerator keygen = KeyGenerator.getInstance("AES");
			keygen.init(192);
			Key key = keygen.generateKey();

            cipher = XMLCipher.getInstance(XMLCipher.TRIPLEDES_KeyWrap);
			cipher.init(XMLCipher.WRAP_MODE, kek);
			EncryptedKey<N> encryptedKey = cipher.encryptKey(ctx, d, key);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_192);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
			EncryptedData<N> builder = cipher.getEncryptedData();

			KeyInfo<N> builderKeyInfo = builder.getKeyInfo();
			if (builderKeyInfo == null) {
				builderKeyInfo = new KeyInfo<N>(ctx, d);
				builder.setKeyInfo(builderKeyInfo);
			}

			builderKeyInfo.add(encryptedKey);

            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
			key = null;
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
            cipher = XMLCipher.getInstance();
            cipher.init(XMLCipher.DECRYPT_MODE, null);

			EncryptedData<N> encryptedData = cipher.loadEncryptedData(ctx, ed, ee);
			
			if(encryptedData == null) {
				System.out.println("ed is null");
			}
			else if (encryptedData.getKeyInfo() == null) {
				System.out.println("ki is null");
			}
			EncryptedKey<N> ek = encryptedData.getKeyInfo().itemEncryptedKey(0);

			if (ek != null) {
				XMLCipher<N> keyCipher = XMLCipher.getInstance();
				keyCipher.init(XMLCipher.UNWRAP_MODE, kek);
				key = keyCipher.decryptKey(ctx, ek, encryptedData.getEncryptionMethod().getAlgorithm());
			}

			// Create a new cipher just to be paranoid
			XMLCipher<N> cipher3 = XMLCipher.getInstance();
			cipher3.init(XMLCipher.DECRYPT_MODE, key);
            dd = cipher3.doFinalElement(ctx, ed, ee);

            target = toString(dd);

			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testAES192ElementAES256KWCipher skipped as necessary algorithms not available");
		}
    }

    public void testGxTripleDesElementCipher() throws Exception {
        N d = document(); // source
        N ed = null;      // target
        N dd = null;      // target
		N e = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model, d, "", element());
        N ee = null;

        String source = null;
        String target = null;

        if (haveISOPadding) {

			source = toString(d);

            // prepare for encryption
            byte[] passPhrase = "24 Bytes per DESede key!".getBytes();
            DESedeKeySpec keySpec = new DESedeKeySpec(passPhrase);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            SecretKey key = keyFactory.generateSecret(keySpec);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.TRIPLEDES);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
            cipher = XMLCipher.getInstance(XMLCipher.TRIPLEDES);
            cipher.init(XMLCipher.DECRYPT_MODE, key);
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
			EncryptedData<N> encryptedData = cipher.loadEncryptedData(ctx, ed, ee);
			Assert.assertEquals(encryptedData.getEncryptionMethod().getAlgorithm(), 
								XMLCipher.TRIPLEDES);
            dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);
			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testTrippleDesElementCipher skipped as necessary algorithms not available");
		}
    }

    public void testGxAes128ElementCipher() throws Exception {
        byte[] bits128 = {
            (byte) 0x10, (byte) 0x11, (byte) 0x12, (byte) 0x13,
            (byte) 0x14, (byte) 0x15, (byte) 0x16, (byte) 0x17,
            (byte) 0x18, (byte) 0x19, (byte) 0x1A, (byte) 0x1B,
            (byte) 0x1C, (byte) 0x1D, (byte) 0x1E, (byte) 0x1F};
        Key key = new SecretKeySpec(bits128, "AES");

        N d = document(); // source
        N ed = null;      // target
        N dd = null;      // target
		N e = getChosenElement(d);
        N ee = null;

        String source = null;
        String target = null;

        if (haveISOPadding) {

			source = toString(d);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_128);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_128);
            cipher.init(XMLCipher.DECRYPT_MODE, key);
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
			EncryptedData<N> encryptedData = cipher.loadEncryptedData(ctx, ed, ee);
			Assert.assertEquals(encryptedData.getEncryptionMethod().getAlgorithm(), 
								XMLCipher.AES_128);
            dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);
			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testAes128ElementCipher skipped as necessary algorithms not available");
		}
    }

    public void testGxAes192ElementCipher() throws Exception {
        byte[] bits192 = {
            (byte) 0x08, (byte) 0x09, (byte) 0x0A, (byte) 0x0B,
            (byte) 0x0C, (byte) 0x0D, (byte) 0x0E, (byte) 0x0F,
            (byte) 0x10, (byte) 0x11, (byte) 0x12, (byte) 0x13,
            (byte) 0x14, (byte) 0x15, (byte) 0x16, (byte) 0x17,
            (byte) 0x18, (byte) 0x19, (byte) 0x1A, (byte) 0x1B,
            (byte) 0x1C, (byte) 0x1D, (byte) 0x1E, (byte) 0x1F};
        Key key = new SecretKeySpec(bits192, "AES");

        N d = document(); // source
        N ed = null;      // target
        N dd = null;      // target
		N e = getChosenElement(d);
        N ee = null;

        String source = null;
        String target = null;

        if (haveISOPadding) {

			source = toString(d);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_192);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_192);
            cipher.init(XMLCipher.DECRYPT_MODE, key);
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
			EncryptedData<N> encryptedData = cipher.loadEncryptedData(ctx, ed, ee);
			Assert.assertEquals(encryptedData.getEncryptionMethod().getAlgorithm(), 
								XMLCipher.AES_192);
            dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);
			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testAes192ElementCipher skipped as necessary algorithms not available");
		}
    }

    public void testGxAes265ElementCipher() throws Exception {
        byte[] bits256 = {
            (byte) 0x00, (byte) 0x01, (byte) 0x02, (byte) 0x03,
            (byte) 0x04, (byte) 0x05, (byte) 0x06, (byte) 0x07,
            (byte) 0x08, (byte) 0x09, (byte) 0x0A, (byte) 0x0B,
            (byte) 0x0C, (byte) 0x0D, (byte) 0x0E, (byte) 0x0F,
            (byte) 0x10, (byte) 0x11, (byte) 0x12, (byte) 0x13,
            (byte) 0x14, (byte) 0x15, (byte) 0x16, (byte) 0x17,
            (byte) 0x18, (byte) 0x19, (byte) 0x1A, (byte) 0x1B,
            (byte) 0x1C, (byte) 0x1D, (byte) 0x1E, (byte) 0x1F};
        Key key = new SecretKeySpec(bits256, "AES");

        N d = document(); // source
        N ed = null;      // target
        N dd = null;      // target
		N e = getChosenElement(d);
        N ee = null;

        String source = null;
        String target = null;

        if (haveISOPadding) {

			source = toString(d);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_256);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
            cipher = XMLCipher.getInstance(XMLCipher.AES_256);
            cipher.init(XMLCipher.DECRYPT_MODE, key);
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
			EncryptedData<N> encryptedData = cipher.loadEncryptedData(ctx, ed, ee);
			Assert.assertEquals(encryptedData.getEncryptionMethod().getAlgorithm(), 
								XMLCipher.AES_256);
            dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);
			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testAes265ElementCipher skipped as necessary algorithms not available");
		}
    }

    /*
	 * Test case for when the entire document is encrypted and decrypted
	 * In this case the EncryptedData becomes the root element of the document
	 */

    public void testGxTripleDesDocumentCipher() throws Exception {
        N d = document(); // source
        N ed = null;      // target
        N dd = null;      // target
        N e = ctx.model.getFirstChildElement(d);
        N ee = null;

        String source = null;
        String target = null;

        if (haveISOPadding) {

			source = toString(d);

            // prepare for encryption
            byte[] passPhrase = "24 Bytes per DESede key!".getBytes();
            DESedeKeySpec keySpec = new DESedeKeySpec(passPhrase);
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
            SecretKey key = keyFactory.generateSecret(keySpec);

            // encrypt
            cipher = XMLCipher.getInstance(XMLCipher.TRIPLEDES);
            cipher.init(XMLCipher.ENCRYPT_MODE, key);
            ed = cipher.doFinalElement(ctx, d, e);

            //decrypt
            cipher = XMLCipher.getInstance(XMLCipher.TRIPLEDES);
            cipher.init(XMLCipher.DECRYPT_MODE, key);
            ee = DomCompatibility.getFirstDescendantOrSelfElementByName(ctx.model,
            		ed, EncryptionConstants.EncryptionSpecNS, "EncryptedData");
            dd = cipher.doFinalElement(ctx, ed, ee);

            target = toString(dd);

			Assert.assertEquals(source, target);
		}
		else {
			log.warn("Test testTrippleDesDocumentCipher skipped as necessary algorithms not available");
		}
    }

	/*
	 * Test a Cipher Reference
	 */

	public void testGxSameDocumentCipherReference() throws Exception {

        if (haveISOPadding) {

        	NodeFactory<N> factory = testCtx.getNodeFactory();
			N d = factory.createDocument(null, null);

			N docElement = factory.createElement("", "EncryptedDoc", "");
			ctx.mutableModel.appendChild(d, docElement);

			// Create the XMLCipher object
			cipher = XMLCipher.getInstance();

			EncryptedData<N> ed = 
				cipher.createEncryptedData(CipherData.REFERENCE_TYPE,
									   "#CipherTextId");
			EncryptionMethod<N> em =
				cipher.createEncryptionMethod(XMLCipher.AES_128);

			ed.setEncryptionMethod(em);

			org.apache.xml.security.encryption.Transforms<N> xencTransforms =
				cipher.createTransforms(ctx.mutableModel, d);
			ed.getCipherData().getCipherReference().setTransforms(xencTransforms);
			org.apache.xml.security.transforms.Transforms<N> dsTransforms =
				xencTransforms.getDSTransforms();

			// An XPath transform
			XPathContainer<N> xpc = new XPathContainer<N>(ctx.mutableModel, d);
			xpc.setXPath("self::text()[parent::CipherText[@Id=\"CipherTextId\"]]");
			dsTransforms.addTransform(org.apache.xml.security.transforms.Transforms.TRANSFORM_XPATH, 
									  xpc.getElementWrappedByReturns());

			// Add a Base64 Transforms
			dsTransforms.addTransform(
									  org.apache.xml.security.transforms.Transforms.TRANSFORM_BASE64_DECODE);

			N ee = cipher.martial(ctx.mutableModel, d, ed);

			ctx.mutableModel.appendChild(docElement, ee);

			// Add the cipher text
			N encryptedElement = factory.createElement("", "CipherText", "");
			ctx.mutableModel.insertAttribute(encryptedElement, factory.createAttribute("", "Id", "", "CipherTextId"));
			IdResolver.registerElementById(ctx.mutableModel, d, encryptedElement, "CipherTextId");
			ctx.mutableModel.appendChild(encryptedElement, factory.createText(tstBase64EncodedString));
			ctx.mutableModel.appendChild(docElement, encryptedElement);
			// dump(d);

			// Now the decrypt, with a brand new cipher
			XMLCipher<N> cipherDecrypt = XMLCipher.getInstance();
			Key key = 
				new SecretKeySpec("abcdefghijklmnop".getBytes("ASCII"), "AES");

			cipherDecrypt.init(XMLCipher.DECRYPT_MODE, key);
			byte[] decryptBytes = cipherDecrypt.decryptToByteArray(ctx, ee);

			Assert.assertEquals(new String(decryptBytes, "ASCII"), 
								new String("A test encrypted secret"));
		}
		else {
			log.warn("Test testSameDocumentCipherReference skipped as necessary algorithms not available");
		}

	}

    public void testGxSerializedData() throws Exception {
        byte[] bits128 = {
            (byte) 0x10, (byte) 0x11, (byte) 0x12, (byte) 0x13,
            (byte) 0x14, (byte) 0x15, (byte) 0x16, (byte) 0x17,
            (byte) 0x18, (byte) 0x19, (byte) 0x1A, (byte) 0x1B,
            (byte) 0x1C, (byte) 0x1D, (byte) 0x1E, (byte) 0x1F};
        Key key = new SecretKeySpec(bits128, "AES");

        N d = document(); // source
        N e = getChosenElement(d);

        // encrypt
        cipher = XMLCipher.getInstance(XMLCipher.AES_128);
        cipher.init(XMLCipher.ENCRYPT_MODE, key);

        // serialize element ...
        Canonicalizer canon =
            Canonicalizer.getInstance(Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        canon.setWriter(baos);
        canon.notReset();
        canon.canonicalizeSubtree(ctx.model, e);
        baos.close();
        String before = baos.toString("UTF-8");

	byte[] serialized = baos.toByteArray();
        EncryptedData<N> encryptedData = cipher.encryptData
            (ctx.mutableModel, d, EncryptionConstants.TYPE_ELEMENT,
             new ByteArrayInputStream(serialized));

        //decrypt
        XMLCipher<N> dcipher = XMLCipher.getInstance(XMLCipher.AES_128);
        dcipher.init(XMLCipher.DECRYPT_MODE, key);
        Assert.assertEquals
            (encryptedData.getEncryptionMethod().getAlgorithm(),
             XMLCipher.AES_128);
        byte[] bytes = dcipher.decryptToByteArray(ctx, dcipher.martial(ctx.mutableModel, encryptedData));
        String after = new String(bytes, "UTF-8");
        Assert.assertEquals(before, after);

	// test with null type
        encryptedData = cipher.encryptData
            (ctx.mutableModel, d, null, new ByteArrayInputStream(serialized));
    }

    public void testGxEncryptedKeyWithRecipient() throws Exception {

	String filename = 
	    "data/org/apache/xml/security/encryption/encryptedKey.xml";
        if (basedir != null && !"".equals(basedir)) {
            filename = basedir + "/" + filename;
        }
        File f = new File(filename);
        
        N document = docHandler.parse( new FileInputStream(f), f.toURI() );
        
        XMLCipher<N> keyCipher = XMLCipher.getInstance();
        keyCipher.init(XMLCipher.UNWRAP_MODE, null);
        
        Iterable<N> ekList = DomCompatibility.getDescendantOrSelfElementsByName(
        		ctx.model, document, EncryptionConstants.EncryptionSpecNS, EncryptionConstants._TAG_ENCRYPTEDKEY);
        
        for (N encryptedKey : ekList) {
            EncryptedKey<N> ek = keyCipher.loadEncryptedKey
    		(ctx, document, encryptedKey);
    	    assertNotNull(ek.getRecipient());
        }
    }

    private String toString (N n) throws Exception {

	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	Canonicalizer c14n = Canonicalizer.getInstance
	    (Canonicalizer.ALGO_ID_C14N_OMIT_COMMENTS);

	byte[] serBytes = c14n.canonicalizeSubtree(ctx.model, n);
	baos.write(serBytes);
	baos.close();

	return baos.toString("UTF-8");

    }
		
    static {
	org.apache.xml.security.Init.init();
    }
}
