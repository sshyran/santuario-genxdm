/*
 * Copyright 2005 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMStructure.java 375655 2006-02-07 18:35:54Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;

import org.genxdm.mutable.MutableModel;

/**
 * DOM-based abstract implementation of XMLStructure.
 *
 * @author Sean Mullan
 */
public abstract class DOMStructure<N> extends BaseStructure implements XMLStructure {

    // TODO - since the marshalling is into the "parent", it might
    // be more appropriate for the signature to be
    // public abstract <NT> void marshal(MutableModel<NT> model, NT parent...)
    public abstract void marshal(MutableModel<N> model, N parent, String dsPrefix, 
	XMLCryptoContext context) throws MarshalException;
}
