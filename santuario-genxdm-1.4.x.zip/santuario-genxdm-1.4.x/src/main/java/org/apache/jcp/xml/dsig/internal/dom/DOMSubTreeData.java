/*
 * Copyright 2006 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id$
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.NodeSetData;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.genxdm.Model;
import org.genxdm.NodeKind;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;

/**
 * This is a subtype of NodeSetData that represents a dereferenced
 * same-document URI as the root of a subdocument. The main reason is
 * for efficiency and performance, as some transforms can operate
 * directly on the subdocument and there is no need to convert it
 * first to an XPath node-set.
 */
public class DOMSubTreeData<N> implements NodeSetData {

    private boolean excludeComments;
    private N root;
    private final MutableModel<N> model;
    private final DocumentHandlerFactory<N> docHandlerFactory;

    public DOMSubTreeData(DocumentHandlerFactory<N> docHandlerFactory, MutableModel<N> model, N root, boolean excludeComments) {
    	this.model = model;
    	this.docHandlerFactory = docHandlerFactory;
	this.root = root;
	this.excludeComments = excludeComments;
    }

	public Iterator<N> iterator() {
	return new DelayedNodeIterator<N>(model, root, excludeComments);
    }

	public MutableModel<N> getModel() {
		return model;
	}
	
	public DocumentHandlerFactory<N> getDocumentHandlerFactory() {
		return docHandlerFactory;
	}
	
    public N getRoot() {
	return root;
    }

    public boolean excludeComments() {
	return excludeComments;
    }

    /**
     * This is an Iterator that contains a backing node-set that is
     * not populated until the caller first attempts to advance the iterator.
     */
    static class DelayedNodeIterator<N> implements Iterator<N> {
    	private N root;
    	private Model<N> model;
	private List<N> nodeSet;
	private ListIterator<N> li;
	private boolean withComments;

	DelayedNodeIterator(Model<N> model, N root, boolean excludeComments) {
		
			this.model = model;
            this.root = root;
            this.withComments = !excludeComments;
	}

        public boolean hasNext() {
            if (nodeSet == null) {
		nodeSet = dereferenceSameDocumentURI(root);
		li = nodeSet.listIterator();
            }
	    return li.hasNext();
        }

        public N next() {
            if (nodeSet == null) {
		nodeSet = dereferenceSameDocumentURI(root);
		li = nodeSet.listIterator();
            }
            if (li.hasNext()) {
		return li.next();
            } else {
                throw new NoSuchElementException();
	    }
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

	/**
         * Dereferences a same-document URI fragment.
	 *
	 * @param node the node (document or element) referenced by the
         *	 URI fragment. If null, returns an empty set.
	 * @return a set of nodes (minus any comment nodes)
	 */
	private List<N> dereferenceSameDocumentURI(N node) {
            List<N> nodeSet = new ArrayList<N>();
            if (node != null) {
		nodeSetMinusCommentNodes(model, node, nodeSet, null);
            }
            return nodeSet;
	}

	/**
         * Recursively traverses the subtree, and returns an XPath-equivalent
	 * node-set of all nodes traversed, excluding any comment nodes,
	 * if specified.
	 *
         * @param node the node to traverse
	 * @param nodeSet the set of nodes traversed so far
	 * @param the previous sibling node
	 */
	private void nodeSetMinusCommentNodes(Model<N> model, N node, List<N> nodeSet,
            N prevSibling) {
            switch (model.getNodeKind(node)) {
		case ELEMENT :
			for (N attr : model.getNamespaceAxis(node, false)) {
				nodeSet.add(attr);
			}
			for (N attr : model.getAttributeAxis(node, false)) {
				nodeSet.add(attr);
			}
                    nodeSet.add(node);
                    // this is meant to fall through.
		case DOCUMENT:
                    N pSibling = null;
                    for (N child : model.getChildAxis(node)) {
                    	nodeSetMinusCommentNodes(model, child, nodeSet, pSibling);
                    	pSibling = child;
                    }
                    break;
		case TEXT:
                    // emulate XPath which only returns the first node in
                    // contiguous text/cdata nodes
                    if (prevSibling != null &&
                        (model.getNodeKind(prevSibling) == NodeKind.TEXT)){			return;
                    }
		case PROCESSING_INSTRUCTION:
                    nodeSet.add(node);
	            break;
		case COMMENT:
		    if (withComments) { 
                        nodeSet.add(node);
		    }
            }
	}
    }
}
