/*
 * Copyright 2005-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMSignedInfo.java 793943 2009-07-14 15:33:19Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.Provider;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.xml.security.utils.Base64;
import org.apache.xml.security.utils.UnsyncBufferedOutputStream;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * DOM-based implementation of SignedInfo.
 *
 * @author Sean Mullan
 */
public final class DOMSignedInfo<N> extends DOMStructure<N> implements SignedInfo {

    private static Logger log = Logger.getLogger("org.apache.jcp.xml.dsig.internal.dom");
    
    // TODO - The "marshal" method assumes this is a list of DOMReference
    private List<Reference> references;
    // TODO - can this be cast to the internal implementation type?
    private CanonicalizationMethod canonicalizationMethod;
    private SignatureMethod signatureMethod;
    private String id;
    private N localSiElem;
    private MutableModel<N> model;
    private DocumentHandlerFactory<N> docHandlerFactory;
    private InputStream canonData;

    /**
     * Creates a <code>DOMSignedInfo</code> from the specified parameters. Use
     * this constructor when the <code>Id</code> is not specified.
     *
     * @param cm the canonicalization method
     * @param sm the signature method
     * @param references the list of references. The list is copied.
     * @throws NullPointerException if
     *    <code>cm</code>, <code>sm</code>, or <code>references</code> is 
     *    <code>null</code>
     * @throws IllegalArgumentException if <code>references</code> is empty
     * @throws ClassCastException if any of the references are not of
     *    type <code>Reference</code>
     */
    public DOMSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, 
	List<Reference> references) {
        if (cm == null || sm == null || references == null) {
            throw new NullPointerException();
        }
        this.canonicalizationMethod = cm;
        this.signatureMethod = sm;
	this.references = Collections.unmodifiableList
	    (new ArrayList<Reference>(references));
	if (this.references.isEmpty()) {
	    throw new IllegalArgumentException("list of references must " +
	        "contain at least one entry");
	}
	for (int i = 0, size = this.references.size(); i < size; i++) {
	    Object obj = this.references.get(i);
	    if (!(obj instanceof Reference)) {
		throw new ClassCastException("list of references contains " +
		    "an illegal type");
	    }
	}
    }

    /**
     * Creates a <code>DOMSignedInfo</code> from the specified parameters.
     *
     * @param cm the canonicalization method
     * @param sm the signature method
     * @param references the list of references. The list is copied.
     * @param id an optional identifer that will allow this
     *    <code>SignedInfo</code> to be referenced by other signatures and
     *    objects
     * @throws NullPointerException if <code>cm</code>, <code>sm</code>,
     *    or <code>references</code> is <code>null</code>
     * @throws IllegalArgumentException if <code>references</code> is empty
     * @throws ClassCastException if any of the references are not of
     *    type <code>Reference</code>
     */
    public DOMSignedInfo(CanonicalizationMethod cm, SignatureMethod sm, 
	List<Reference> references, String id) {
        this(cm, sm, references);
        this.id = id;
    }

    /**
     * Creates a <code>DOMSignedInfo</code> from an element.
     *
     * @param siElem a SignedInfo element
     */
    public DOMSignedInfo(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, N siElem, XMLCryptoContext context,
	Provider provider) throws MarshalException {
        this.docHandlerFactory = docFactory;
        this.model = model;
	localSiElem = siElem;
	
        // get Id attribute, if specified
        id = DOMUtils.getAttributeValue(model, siElem, "Id");

        // unmarshal CanonicalizationMethod
	N cmElem = model.getFirstChildElement(siElem);
	canonicalizationMethod = new DOMCanonicalizationMethod
	    (model, cmElem, context, provider);

        // unmarshal SignatureMethod
	N smElem = model.getNextSiblingElement(cmElem);
	signatureMethod = DOMSignatureMethod.unmarshal(model, smElem);

	// unmarshal References
	ArrayList<Reference> refList = new ArrayList<Reference>(5);
	N refElem = model.getNextSiblingElement(smElem);
	while (refElem != null) {
	    refList.add(new DOMReference<N>(model, refElem, context, provider));
	    refElem = model.getNextSiblingElement(refElem);
	}
	references = Collections.unmodifiableList(refList);
    }

    public CanonicalizationMethod getCanonicalizationMethod() {
        return canonicalizationMethod;
    }

    public SignatureMethod getSignatureMethod() {
        return signatureMethod;
    }

    public String getId() {
        return id;
    }

    public List<Reference> getReferences() {
	return references;
    }

    public InputStream getCanonicalizedData() {
	return canonData;
    }

    public void canonicalize(XMLCryptoContext context,ByteArrayOutputStream bos)
	throws XMLSignatureException {

	if (context == null) {
            throw new NullPointerException("context cannot be null");
	}

	OutputStream os = new UnsyncBufferedOutputStream(bos);
        try {
            os.close();
        } catch (IOException e) {
            // Impossible
        }

	DocumentHandlerFactory<N> docFactory = GenXDMCryptoContext.getDocumentHandlerFactory(context);
    DOMSubTreeData<N> subTree = new DOMSubTreeData<N>(docFactory, model, localSiElem, true);

	try {
	    ((DOMCanonicalizationMethod) 
		canonicalizationMethod).canonicalize(subTree, context, os);
	} catch (TransformException te) {
	    throw new XMLSignatureException(te);
	}

	byte[] signedInfoBytes = bos.toByteArray();

        // this whole block should only be done if logging is enabled
	if (log.isLoggable(Level.FINE)) {
            log.log(Level.FINE, "Canonicalized SignedInfo:"); 
            StringBuffer sb = new StringBuffer(signedInfoBytes.length);
            for (int i = 0; i < signedInfoBytes.length; i++) {
                sb.append((char) signedInfoBytes[i]);
            }
            log.log(Level.FINE, sb.toString());
	    log.log(Level.FINE, "Data to be signed/verified:"
                + Base64.encode(signedInfoBytes));
	}

	this.canonData = new ByteArrayInputStream(signedInfoBytes);
    }

    public void marshal(MutableModel<N> model, N parent, String dsPrefix, XMLCryptoContext context)
	throws MarshalException {
    	NodeFactory<N> factory = model.getFactory(parent);

	N siElem = factory.createElement
	    (XMLSignature.XMLNS, "SignedInfo", dsPrefix);

	// create and append CanonicalizationMethod element
	DOMCanonicalizationMethod dcm = 
	    (DOMCanonicalizationMethod) canonicalizationMethod;
	dcm.marshal(model, siElem, dsPrefix, context); 

	// create and append SignatureMethod element
	((DOMSignatureMethod) signatureMethod).marshal
	    (model, siElem, dsPrefix);

	// create and append Reference elements
	for (int i = 0, size = references.size(); i < size; i++) {
	    DOMReference<N> reference = (DOMReference<N>) references.get(i);
	    reference.marshal(model, siElem, dsPrefix, context);
	}

	// append Id attribute
        DOMUtils.setAttributeID(factory, model, siElem, "Id", id);
	    
	model.appendChild(parent, siElem);
	localSiElem = siElem;
	this.model = model;
    }

    public boolean equals(Object o) {
	if (this == o) {
	    return true;
	}

	if (!(o instanceof SignedInfo)) {
	    return false;
	}
	SignedInfo osi = (SignedInfo) o;

	boolean idEqual = (id == null ? osi.getId() == null : 
	    id.equals(osi.getId()));

	boolean canonMethodEqual = canonicalizationMethod.equals(osi.getCanonicalizationMethod());
	boolean sigMethodEqual = signatureMethod.equals(osi.getSignatureMethod());
	boolean referencesEqual = references.equals(osi.getReferences());
	return (canonMethodEqual 
	    && sigMethodEqual && 
	    referencesEqual && idEqual);
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 59;
    }

	@SuppressWarnings("unchecked")
	public static List<Reference> getSignedInfoReferences(SignedInfo si) {
		return si.getReferences();
	}
}
