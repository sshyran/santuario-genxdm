/*
 * Copyright 2005-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMURIDereferencer.java 793943 2009-07-14 15:33:19Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import org.w3c.dom.Node;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.jcp.crypto.genxdm.GenXDMURIReference;
import org.apache.xml.security.Init;
import org.apache.xml.security.utils.IdResolver;
import org.apache.xml.security.utils.XmlContext;
import org.apache.xml.security.utils.resolver.ResourceResolver;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;

import javax.xml.crypto.*;
import javax.xml.crypto.dom.*;

/**
 * DOM-based implementation of URIDereferencer.
 *
 * <p>Note that this is called DOMURIReference simply to preserve continuity with original
 * Santuario code base, but it works even if the URIReference passed is a 
 * @author Sean Mullan
 */
public class DOMURIDereferencer implements URIDereferencer {
    
    static final URIDereferencer INSTANCE = new DOMURIDereferencer();

    private DOMURIDereferencer() {
	// need to call org.apache.xml.security.Init.init() 
        // before calling any apache security code
	Init.init();
    }

    public Data dereference(URIReference uriRef, XMLCryptoContext context)
	throws URIReferenceException {

	if (uriRef == null) {
	    throw new NullPointerException("uriRef cannot be null");
	}
	if (context == null) {
	    throw new NullPointerException("context cannot be null");
	}

	return dereferenceURI(uriRef, context);
    }

    private <N> Data dereferenceURI(URIReference uriRef, XMLCryptoContext context)
            throws URIReferenceException {
        
            MutableModel<N> model = getModelFromRef(uriRef);
            N uriAttr = getHereNode(model, uriRef);
        String uri = uriRef.getURI();
        
        // Check if same-document URI and register ID
        if (uri != null && uri.length() != 0 && uri.charAt(0) == '#') {
                String id = uri.substring(1);

            if (id.startsWith("xpointer(id(")) {
                int i1 = id.indexOf('\'');
                int i2 = id.indexOf('\'', i1+1);
        	id = id.substring(i1+1, i2);
            }

            if (context instanceof DOMCryptoContext) {
                DOMCryptoContext dcc = (DOMCryptoContext) context;
                // this is a bit of a hack to check for registered 
                // IDRefs and manually register them with Apache's IdResolver 
                // map which includes builtin schema knowledge of DSig/Enc IDs
                    Node referencedElem = dcc.getElementById(id);
                if (referencedElem != null) {
                    IdResolver.registerElementById(XmlContext.getDomModel(), referencedElem.getOwnerDocument(), referencedElem, id);
                }
            }
            else if (context instanceof GenXDMCryptoContext) {
                @SuppressWarnings("unchecked")
                GenXDMCryptoContext<N> gdcc = (GenXDMCryptoContext<N>) context;
                N referencedElem = gdcc.getElementById(id);
                if (referencedElem != null) {
                    IdResolver.registerElementById(model, model.getRoot(referencedElem), referencedElem, id);
                }
            }
        } 

            try {
            String baseURI = context.getBaseURI();
                ResourceResolver apacheResolver = 
                ResourceResolver.getInstance(model, uriAttr, baseURI);
                DocumentHandlerFactory<N> docFactory = GenXDMCryptoContext.getDocumentHandlerFactory(context);
                XmlContext<N> ctx = new XmlContext<N>(docFactory, model);
                XMLSignatureInput<N> in = apacheResolver.resolve(ctx, uriAttr, baseURI);
            if (in.isOctetStream()) {
                return new ApacheOctetStreamData<N>(in);
            } else {
                return new ApacheNodeSetData<N>(in);
            }
            } catch (Exception e) {
                throw new URIReferenceException(e);
            }
    }
    
    /**
     * Extracts a model from a URIReference, based on the reference type.
     * 
     * <p>Appears to be necessary to suppress warnings on this method.</p>
     * 
     * @param <N>
     * @param ref
     * @return 
     */
    @SuppressWarnings("unchecked")
    private static <N> MutableModel<N> getModelFromRef(URIReference ref) {
        // Note - must check for GenXDM form first, because an implementation
        // could choose to implement both APIs for maximum compatibility.
        if (ref instanceof GenXDMURIReference) {
            return ( (GenXDMURIReference<N>) ref).getModel();
        }
        else if (ref instanceof DOMURIReference) {
            return (MutableModel<N>) XmlContext.getContext().mutableModel;
        }
        else {
            throw new IllegalArgumentException("Unrecognized type of URIReference.");
        }
    }
    
    /**
     * Appears to be necessary to suppress warnings on this method.
     * @param <N>
     * @param ref
     * @return
     */
    @SuppressWarnings("unchecked")
    private static <N> N getHereNode(MutableModel<N> model, URIReference ref) {
        if (ref instanceof GenXDMURIReference) {
            return ( (GenXDMURIReference<N>) ref).getHereNode();
        }
        else if (ref instanceof DOMURIReference) {
            return (N) ( (DOMURIReference) ref).getHere();
        }
        else {
            throw new IllegalArgumentException("Unrecognized type of URIReference.");
        }
    }
    }
