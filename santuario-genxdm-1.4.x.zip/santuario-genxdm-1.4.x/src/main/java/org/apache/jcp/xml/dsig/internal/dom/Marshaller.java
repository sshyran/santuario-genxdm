package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.MarshalException;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.SignatureProperties;
import javax.xml.crypto.dsig.SignatureProperty;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyName;
import javax.xml.crypto.dsig.keyinfo.KeyValue;
import javax.xml.crypto.dsig.keyinfo.PGPData;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

class Marshaller {

    public static <N> void marshal(XMLStructure toMarshal, MutableModel<N> model, N parent, String dsPrefix, 
            XMLCryptoContext context) throws MarshalException {
        
        if (toMarshal instanceof KeyName) {
            DOMKeyName.marshal( (KeyName) toMarshal, model, parent, dsPrefix);
        }
        if (toMarshal instanceof KeyInfo) {
            DOMKeyInfo.marshal( (KeyInfo) toMarshal, model, parent, dsPrefix, context);
        }
        if (toMarshal instanceof KeyValue) {
            // Since DOMKeyValue allows for deserializing unrecognized keys, and that
            // capability isn't available via the KeyValue interface, this must continue
            // to cast to DOMKeyValue.
            DOMKeyValue dkv = (DOMKeyValue) toMarshal;
            dkv.marshal( model, parent, dsPrefix);
        }
        else if (toMarshal instanceof X509IssuerSerial) {
            DOMX509IssuerSerial.marshal( (X509IssuerSerial) toMarshal, model, parent, dsPrefix);
        }
        else if (toMarshal instanceof X509Data) {
            DOMX509Data.marshal( (X509Data) toMarshal, model, parent, dsPrefix, context);
        }
        else if (toMarshal instanceof DigestMethod) {
            DOMDigestMethod.marshal( (DigestMethod) toMarshal, model, parent, dsPrefix);
        }
        else if (toMarshal instanceof PGPData) {
            DOMPGPData.marshal( (PGPData) toMarshal, model, parent, dsPrefix, context);
        }
        else if (toMarshal instanceof SignatureProperty) {
            DOMSignatureProperty.marshal((SignatureProperty) toMarshal, model, parent, dsPrefix, context);
        }
        else if (toMarshal instanceof SignatureProperties) {
            DOMSignatureProperties.marshal((SignatureProperties) toMarshal, model, parent, dsPrefix, context);
        }
        else if (toMarshal instanceof DOMSignatureMethod) {
            ( (DOMSignatureMethod) toMarshal).marshal(model, parent, dsPrefix);
        }
        else if (toMarshal instanceof DOMStructure) {
            // Note - this assumes that the N type of the structure matches the model.
            @SuppressWarnings("unchecked")
            DOMStructure<N> struct = (DOMStructure<N>) toMarshal;
            struct.marshal(model, parent, dsPrefix, context);
        }
        else if (toMarshal instanceof javax.xml.crypto.dom.DOMStructure || toMarshal instanceof GenXDMStructure) {
            marshalGenericNode(model, parent, toMarshal);
        }
    }

    @SuppressWarnings("unchecked")
    private static <NT, NS> void marshalGenericNode(MutableModel<NT> targetModel, NT parent, XMLStructure xmlStruct) {
        MutableModel<NS> structModel = GenXDMStructure.getModel(xmlStruct);
        NS node = GenXDMStructure.getNode(structModel, xmlStruct);
        NodeFactory<NT> factory = targetModel.getFactory(parent);
        
        // if it is a namespace, make a copy.
        if (structModel.isNamespace(node)) {
            targetModel.insertNamespace(parent, structModel.getLocalName(node), structModel.getStringValue(node));
        }
        else if (structModel.isAttribute(node)) {
            // if it is an attribute, make a copy.
            NT newAttr = factory.createAttribute(structModel.getNamespaceURI(node),
                    structModel.getLocalName(node),
                    structModel.getPrefix(node),
                    structModel.getStringValue(node));
            targetModel.insertAttribute(parent, newAttr);
        }
        else {
            // TODO - what we really should be doing here is manufacturing nodes and elements by walking the
            // structure of the "node", rather than blindly inserting it here. Notice the bogus type-cast
            targetModel.appendChild(parent, (NT) node);
        }
    }
    
}
