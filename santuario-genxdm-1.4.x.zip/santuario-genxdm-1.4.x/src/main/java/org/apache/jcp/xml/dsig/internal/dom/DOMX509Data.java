/*
 * Copyright 2005 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMX509Data.java 647272 2008-04-11 19:22:21Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import java.io.ByteArrayInputStream;
import java.security.cert.*;
import java.util.*;
import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.security.auth.x500.X500Principal;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.apache.xml.security.exceptions.Base64DecodingException;
import org.apache.xml.security.utils.Base64;
import org.genxdm.Model;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * DOM-based implementation of X509Data.
 *
 * @author Sean Mullan
 */
//@@@ check for illegal combinations of data violating MUSTs in W3c spec
public final class DOMX509Data extends BaseStructure implements X509Data {

    private final List<Object> content;
    private CertificateFactory cf;

    /**
     * Creates a DOMX509Data.
     *
     * @param content a list of one or more X.509 data types. Valid types are
     *    {@link String} (subject names), <code>byte[]</code> (subject key ids),
     *    {@link java.security.cert.X509Certificate}, {@link X509CRL},
     *    or {@link javax.xml.dsig.XMLStructure} ({@link X509IssuerSerial}
     *    objects or elements from an external namespace). The list is 
     *    defensively copied to protect against subsequent modification.
     * @return a <code>X509Data</code>
     * @throws NullPointerException if <code>content</code> is <code>null</code>
     * @throws IllegalArgumentException if <code>content</code> is empty
     * @throws ClassCastException if <code>content</code> contains any entries
     *    that are not of one of the valid types mentioned above
     */
    public DOMX509Data(List<Object> content) {
        if (content == null) {
            throw new NullPointerException("content cannot be null");
        }
        List<Object> contentCopy = new ArrayList<Object>(content);
        if (contentCopy.isEmpty()) {
            throw new IllegalArgumentException("content cannot be empty");
        }
        for (int i = 0, size = contentCopy.size(); i < size; i++) {
	    Object x509Type = contentCopy.get(i);
	    if (x509Type instanceof String) {
		new X500Principal((String) x509Type);
	    } else if (!(x509Type instanceof byte[]) &&
                !(x509Type instanceof X509Certificate) &&
                !(x509Type instanceof X509CRL) &&
                !(x509Type instanceof XMLStructure)) {
                throw new ClassCastException
                    ("content["+i+"] is not a valid X509Data type");
            }
        }
        this.content = Collections.unmodifiableList(contentCopy);
    }

    /**
     * Creates a <code>DOMX509Data</code> from an element.
     *
     * @param xdElem an X509Data element
     * @throws MarshalException if there is an error while unmarshalling
     */
    public <N> DOMX509Data(MutableModel<N> model, N xdElem) throws MarshalException {
        // get all children nodes
    	List<Object> content = new ArrayList<Object>();

        for (N childElem : model.getChildElements(xdElem)) {
        	
	    String localName = model.getLocalName(childElem);
            if (localName.equals("X509Certificate")) {
                content.add(unmarshalX509Certificate(model, childElem));
            } else if (localName.equals("X509IssuerSerial")) {
                content.add(new DOMX509IssuerSerial(model, childElem));
            } else if (localName.equals("X509SubjectName")) {
                content.add( BaseStructure.textOfNode(model, childElem));
            } else if (localName.equals("X509SKI")) {
		try {
                    content.add(Base64.decode(model, childElem));
		} catch (Base64DecodingException bde) {
		    throw new MarshalException("cannot decode X509SKI", bde);
		}
            } else if (localName.equals("X509CRL")) {
                content.add(unmarshalX509CRL(model, childElem));
            } else {
                content.add(new GenXDMStructure<N>(model, childElem));
            }
        }
        this.content = Collections.unmodifiableList(content);
    }

    public List<Object> getContent() {
	return content;
    }

    public static <N> void marshal(X509Data x509Data, MutableModel<N> model, N parent, String dsPrefix, XMLCryptoContext context)
	throws MarshalException {
    	NodeFactory<N> factory = model.getFactory(parent);

        N xdElem = factory.createElement
            (XMLSignature.XMLNS, "X509Data", dsPrefix);

        List<Object> content = x509Data.getContent();
        // append children and preserve order
	for (int i = 0, size = content.size(); i < size; i++) {
	    Object object = content.get(i);
            if (object instanceof X509Certificate) {
                marshalCert(factory, model, (X509Certificate) object,xdElem,dsPrefix);
	    } else if (object instanceof XMLStructure) {
	        Marshaller.marshal( (XMLStructure) object, model, xdElem, dsPrefix, context);
	    } else if (object instanceof byte[]) {
                marshalSKI(factory, model, (byte[]) object, xdElem, dsPrefix);
            } else if (object instanceof String) {
                marshalSubjectName(factory, model, (String) object, xdElem, dsPrefix);
            } else if (object instanceof X509CRL) {
                marshalCRL(factory, model, (X509CRL) object, xdElem, dsPrefix);
            }
        }

        model.appendChild(parent, xdElem);
    }

    private static <N> void marshalSKI(NodeFactory<N> factory, MutableModel<N> model, byte[] skid, N parent,
	String dsPrefix) {

        N skidElem = factory.createElement
	    (XMLSignature.XMLNS, "X509SKI", dsPrefix);
        model.appendChild(skidElem, factory.createText(Base64.encode(skid)));
        model.appendChild(parent, skidElem);
    }

    private static <N> void marshalSubjectName(NodeFactory<N> factory, MutableModel<N> model, String name, N parent, 
	String dsPrefix) {

        N snElem = factory.createElement
	    (XMLSignature.XMLNS, "X509SubjectName", dsPrefix);
        model.appendChild(snElem, factory.createText(name));
        model.appendChild(parent, snElem);
    }

    private static <N> void marshalCert(NodeFactory<N> factory, MutableModel<N> model, X509Certificate cert, N parent,
	String dsPrefix) throws MarshalException {

        N certElem = factory.createElement
	    (XMLSignature.XMLNS, "X509Certificate", dsPrefix);
        try {
            model.appendChild(certElem, factory.createText
                (Base64.encode(cert.getEncoded())));
        } catch (CertificateEncodingException e) {
            throw new MarshalException("Error encoding X509Certificate", e);
        }
        model.appendChild(parent, certElem);
    }

    private static <N> void marshalCRL(NodeFactory<N> factory, MutableModel<N> model, X509CRL crl, N parent, 
	String dsPrefix) throws MarshalException {

        N crlElem = factory.createElement
	    (XMLSignature.XMLNS, "X509CRL", dsPrefix);
        try {
            model.appendChild(crlElem, factory.createText
                (Base64.encode(crl.getEncoded())));
        } catch (CRLException e) {
            throw new MarshalException("Error encoding X509CRL", e);
        }
        model.appendChild(parent, crlElem);
    }

    private <N> X509Certificate unmarshalX509Certificate(Model<N> model, N elem) 
	throws MarshalException {
        try {
            ByteArrayInputStream bs = unmarshalBase64Binary(model, elem);
            return (X509Certificate) cf.generateCertificate(bs);
        } catch (CertificateException e) {
            throw new MarshalException("Cannot create X509Certificate", e);
        }
    }

    private <N> X509CRL unmarshalX509CRL(Model<N> model, N elem) throws MarshalException {
        try {
            ByteArrayInputStream bs = unmarshalBase64Binary(model, elem);
            return (X509CRL) cf.generateCRL(bs);
        } catch (CRLException e) {
            throw new MarshalException("Cannot create X509CRL", e);
        }
    }

    private <N> ByteArrayInputStream unmarshalBase64Binary(Model<N> model, N elem) 
	throws MarshalException {
        try {
            if (cf == null) {
                cf = CertificateFactory.getInstance("X.509");
	    }
            return new ByteArrayInputStream(Base64.decode(model, elem));
        } catch (CertificateException e) {
            throw new MarshalException("Cannot create CertificateFactory", e);
        } catch (Base64DecodingException bde) {
            throw new MarshalException("Cannot decode Base64-encoded val", bde);
        }
    }

    @SuppressWarnings("unchecked")
	private static List<Object> getContent(X509Data data) {
    	return data.getContent();
    }
    
    public boolean equals(Object o) {
	if (this == o) {
            return true;
	}

        if (!(o instanceof X509Data)) {
            return false;
	}
        X509Data oxd = (X509Data) o;

	List<Object> ocontent = getContent(oxd);
	int size = content.size();
	if (size != ocontent.size()) {
	    return false;
	}

	for (int i = 0; i < size; i++) {
	    Object x = content.get(i);
	    Object ox = ocontent.get(i);
	    if (x instanceof byte[]) {
		if (!(ox instanceof byte[]) || 
		    !Arrays.equals((byte[]) x, (byte[]) ox)) {
		    return false;
		} 
	    } else {
		if (!(x.equals(ox))) {
		    return false;
		}
	    }
	}

	return true;
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 56;
    }
}
