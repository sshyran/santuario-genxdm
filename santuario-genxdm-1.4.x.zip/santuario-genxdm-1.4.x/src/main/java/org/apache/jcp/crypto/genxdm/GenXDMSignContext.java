package org.apache.jcp.crypto.genxdm;

import java.security.Key;

import javax.xml.crypto.KeySelector;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.dom.DOMCryptoContext;
import javax.xml.crypto.dsig.XMLSignContext;
import javax.xml.crypto.dsig.dom.DOMSignContext;

import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Node;

public class GenXDMSignContext<N> extends GenXDMCryptoContext<N> implements XMLSignContext {

    private N parent;
    private N nextSibling;

    /**
     * Get a parent node from a {@link XMLSignContext}, whether it be of the
     * {@link DOMSignContext} form or the {@link GenXDMSignContext} form.
     * 
     * @param <NT>
     * @param cryptoCtx
     * @param model Actually a place-holder for generics type-safety
     * @return
     */
    public static <NT> NT getParent(MutableModel<NT> model, XMLSignContext cryptoCtx) {
        if (cryptoCtx instanceof GenXDMSignContext) {
            return ( (GenXDMSignContext<NT>) cryptoCtx).getParent();
        }
        else if (cryptoCtx instanceof DOMSignContext) {
            return (NT) ( (DOMSignContext) cryptoCtx).getParent();
        }
        
        throw new ClassCastException("Unrecognized subclass of XMLSignContext. Must be either a GenXDMSignContext or a GenXDMSignContext");
    }
    
    /**
     * Get a parent node from a {@link XMLSignContext}, whether it be of the
     * {@link DOMSignContext} form or the {@link GenXDMSignContext} form.
     * 
     * @param <NT>
     * @param cryptoCtx
     * @param model Actually a place-holder for generics type-safety
     * @return
     */
    public static <NT> NT getNextSibling(MutableModel<NT> model, XMLSignContext cryptoCtx) {
        if (cryptoCtx instanceof GenXDMSignContext) {
            return ( (GenXDMSignContext<NT>) cryptoCtx).getNextSibling();
        }
        else if (cryptoCtx instanceof DOMSignContext) {
            return (NT) ( (DOMSignContext) cryptoCtx).getNextSibling();
        }
        
        throw new ClassCastException("Unrecognized subclass of XMLSignContext. Must be either a GenXDMSignContext or a DOMSignContext");
    }
    
    /**
     * Creates a <code>DOMSignContext</code> with the specified signing key
     * and parent node. The signing key is stored in a
     * {@link KeySelector#singletonKeySelector singleton KeySelector} that is
     * returned by the {@link #getKeySelector getKeySelector} method.
     * The marshalled <code>XMLSignature</code> will be added as the last 
     * child element of the specified parent node unless a next sibling node is 
     * specified by invoking the {@link #setNextSibling setNextSibling} method.
     *
     * @param signingKey the signing key
     * @param parent the parent node
     * @throws NullPointerException if <code>signingKey</code> or 
     *    <code>parent</code> is <code>null</code>
     */
    public GenXDMSignContext(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, Key signingKey, N parent) { 
        super(docFactory, model);
        
        if (signingKey == null) {
            throw new NullPointerException("signingKey cannot be null");
        } 
        if (parent == null) {
            throw new NullPointerException("parent cannot be null");
        }
        setKeySelector(KeySelector.singletonKeySelector(signingKey));
        this.parent = parent;
    }

    /**
     * Creates a <code>DOMSignContext</code> with the specified signing key,
     * parent and next sibling nodes. The signing key is stored in a
     * {@link KeySelector#singletonKeySelector singleton KeySelector} that is
     * returned by the {@link #getKeySelector getKeySelector} method.
     * The marshalled <code>XMLSignature</code> will be inserted as a child 
     * element of the specified parent node and immediately before the 
     * specified next sibling node.
     *
     * @param signingKey the signing key
     * @param parent the parent node
     * @param nextSibling the next sibling node
     * @throws NullPointerException if <code>signingKey</code>, 
     *    <code>parent</code> or <code>nextSibling</code> is <code>null</code>
     */
    public GenXDMSignContext(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, Key signingKey, N parent, N nextSibling) { 
        super(docFactory, model);

        if (signingKey == null) {
            throw new NullPointerException("signingKey cannot be null");
        }
        if (parent == null) {
            throw new NullPointerException("parent cannot be null");
        }
        if (nextSibling == null) {
            throw new NullPointerException("nextSibling cannot be null");
        }
        setKeySelector(KeySelector.singletonKeySelector(signingKey));
        this.parent = parent;
        this.nextSibling = nextSibling;
    }

    /**
     * Creates a <code>DOMSignContext</code> with the specified key selector
     * and parent node. The marshalled <code>XMLSignature</code> will be added 
     * as the last child element of the specified parent node unless a next 
     * sibling node is specified by invoking the 
     * {@link #setNextSibling setNextSibling} method.
     *
     * @param ks the key selector
     * @param parent the parent node
     * @throws NullPointerException if <code>ks</code> or <code>parent</code> 
     *    is <code>null</code>
     */
    public GenXDMSignContext(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, KeySelector ks, N parent) {
        super(docFactory, model);
        if (ks == null) {
            throw new NullPointerException("key selector cannot be null");
        } 
        if (parent == null) {
            throw new NullPointerException("parent cannot be null");
        }
        setKeySelector(ks);
        this.parent = parent;
    }

    /**
     * Creates a <code>DOMSignContext</code> with the specified key selector,
     * parent and next sibling nodes. The marshalled <code>XMLSignature</code> 
     * will be inserted as a child element of the specified parent node and 
     * immediately before the specified next sibling node.
     *
     * @param ks the key selector
     * @param parent the parent node
     * @param nextSibling the next sibling node
     * @throws NullPointerException if <code>ks</code>, <code>parent</code> or 
     *    <code>nextSibling</code> is <code>null</code>
     */
    public GenXDMSignContext(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, KeySelector ks, N parent, N nextSibling) { 
        super(docFactory, model);
        if (ks == null) {
            throw new NullPointerException("key selector cannot be null");
        }
        if (parent == null) {
            throw new NullPointerException("parent cannot be null");
        }
        if (nextSibling == null) {
            throw new NullPointerException("nextSibling cannot be null");
        }
        setKeySelector(ks);
        this.parent = parent;
        this.nextSibling = nextSibling;
    }

    /**
     * Sets the parent node.
     *
     * @param parent the parent node. The marshalled <code>XMLSignature</code> 
     *    will be added as a child element of this node.
     * @throws NullPointerException if <code>parent</code> is <code>null</code>
     * @see #getParent
     */
    public void setParent(N parent) {
    if (parent == null) {
        throw new NullPointerException("parent is null");
    }
    this.parent = parent;
    }

    /**
     * Sets the next sibling node. 
     *
     * @param nextSibling the next sibling node. The marshalled 
     *    <code>XMLSignature</code> will be inserted immediately before this 
     *    node. Specify <code>null</code> to remove the current setting. 
     * @see #getNextSibling
     */
    public void setNextSibling(N nextSibling) {
    this.nextSibling = nextSibling;
    }

    /**
     * Returns the parent node.
     *
     * @return the parent node (never <code>null</code>)
     * @see #setParent(Node)
     */
    public N getParent() {
    return parent;
    }

    /**
     * Returns the nextSibling node.
     *
     * @return the nextSibling node, or <code>null</code> if not specified.
     * @see #setNextSibling(Node)
     */
    public N getNextSibling() {
    return nextSibling;
    }

}
