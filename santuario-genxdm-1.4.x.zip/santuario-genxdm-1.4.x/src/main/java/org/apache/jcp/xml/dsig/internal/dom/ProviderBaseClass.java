package org.apache.jcp.xml.dsig.internal.dom;

import java.security.AccessController;
import java.security.Provider;
import java.util.HashMap;
import java.util.Map;

import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.Transform;

public class ProviderBaseClass extends Provider{

    /* Default */
    private static final long serialVersionUID = 1L;
    
    private static final String INFO = "Apache Santuario XMLDSig " + 
    "(DOM XMLSignatureFactory; DOM KeyInfoFactory; GenXDM XMLSignatureFactory; GenXDM KeyInfoFactory)";

    public ProviderBaseClass(String variant) {
        
        /* We are the XMLDSig provider */
        super("XMLDSig-" + variant, 1.46, INFO);
        
        final Map<String, String> map = new HashMap<String, String>();
            map.put("XMLSignatureFactory." + variant, 
                "org.apache.jcp.xml.dsig.internal.dom.DOMXMLSignatureFactory");
            map.put("KeyInfoFactory." + variant, 
                "org.apache.jcp.xml.dsig.internal.dom.DOMKeyInfoFactory");

        // Inclusive C14N
        map.put((String)"TransformService." + CanonicalizationMethod.INCLUSIVE,
            "org.apache.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14NMethod");
        map.put("Alg.Alias.TransformService.INCLUSIVE", 
            CanonicalizationMethod.INCLUSIVE);
        map.put((String)"TransformService." + CanonicalizationMethod.INCLUSIVE +
            " MechanismType", "DOM");

        // InclusiveWithComments C14N
        map.put((String) "TransformService." + 
            CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS,
            "org.apache.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14NMethod");
        map.put("Alg.Alias.TransformService.INCLUSIVE_WITH_COMMENTS", 
            CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS);
        map.put((String) "TransformService." + 
            CanonicalizationMethod.INCLUSIVE_WITH_COMMENTS + 
            " MechanismType", variant);

        // Inclusive C14N 1.1
        map.put((String)"TransformService." + 
            "http://www.w3.org/2006/12/xml-c14n11",
            "org.apache.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14N11Method");
        map.put((String)"TransformService." + 
            "http://www.w3.org/2006/12/xml-c14n11" +
            " MechanismType", variant);

        // InclusiveWithComments C14N 1.1 
        map.put((String)"TransformService." + 
            "http://www.w3.org/2006/12/xml-c14n11#WithComments",
            "org.apache.jcp.xml.dsig.internal.dom.DOMCanonicalXMLC14N11Method");
        map.put((String)"TransformService." + 
            "http://www.w3.org/2006/12/xml-c14n11#WithComments" +
            " MechanismType", variant);

        // Exclusive C14N
        map.put((String) "TransformService." + CanonicalizationMethod.EXCLUSIVE,
            "org.apache.jcp.xml.dsig.internal.dom.DOMExcC14NMethod");
        map.put("Alg.Alias.TransformService.EXCLUSIVE", 
            CanonicalizationMethod.EXCLUSIVE);
        map.put((String)"TransformService." + CanonicalizationMethod.EXCLUSIVE +
            " MechanismType", variant);

        // ExclusiveWithComments C14N
        map.put((String) "TransformService." + 
            CanonicalizationMethod.EXCLUSIVE_WITH_COMMENTS,
            "org.apache.jcp.xml.dsig.internal.dom.DOMExcC14NMethod");
        map.put("Alg.Alias.TransformService.EXCLUSIVE_WITH_COMMENTS", 
            CanonicalizationMethod.EXCLUSIVE_WITH_COMMENTS);
        map.put((String) "TransformService." + 
            CanonicalizationMethod.EXCLUSIVE_WITH_COMMENTS +
            " MechanismType", variant);

        // Base64 Transform
        map.put((String) "TransformService." + Transform.BASE64,
            "org.apache.jcp.xml.dsig.internal.dom.DOMBase64Transform");
        map.put("Alg.Alias.TransformService.BASE64", Transform.BASE64);
        map.put((String) "TransformService." + Transform.BASE64 + 
            " MechanismType", variant);

        // Enveloped Transform
        map.put((String) "TransformService." + Transform.ENVELOPED,
            "org.apache.jcp.xml.dsig.internal.dom.DOMEnvelopedTransform");
        map.put("Alg.Alias.TransformService.ENVELOPED", Transform.ENVELOPED);
        map.put((String) "TransformService." + Transform.ENVELOPED + 
            " MechanismType", variant);

        // XPath2 Transform
        map.put((String) "TransformService." + Transform.XPATH2,
            "org.apache.jcp.xml.dsig.internal.dom.DOMXPathFilter2Transform");
        map.put("Alg.Alias.TransformService.XPATH2", Transform.XPATH2);
        map.put((String) "TransformService." + Transform.XPATH2 + 
            " MechanismType", variant);

        // XPath Transform
        map.put((String) "TransformService." + Transform.XPATH,
            "org.apache.jcp.xml.dsig.internal.dom.DOMXPathTransform");
        map.put("Alg.Alias.TransformService.XPATH", Transform.XPATH);
        map.put((String) "TransformService." + Transform.XPATH + 
            " MechanismType", variant);

        // XSLT Transform
        map.put((String) "TransformService." + Transform.XSLT,
            "org.apache.jcp.xml.dsig.internal.dom.DOMXSLTTransform");
        map.put("Alg.Alias.TransformService.XSLT", Transform.XSLT);
        map.put((String) "TransformService." + Transform.XSLT + 
            " MechanismType", variant);

        AccessController.doPrivileged(new java.security.PrivilegedAction<Object>() {
            public Object run() {
            putAll(map);
            return null;
            }
        });
        }
}
