/*
 * Copyright 2005 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * ===========================================================================
 *
 * (C) Copyright IBM Corp. 2003 All Rights Reserved.
 *
 * ===========================================================================
 */
/*
 * Portions copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMXPathFilter2Transform.java 656799 2008-05-15 19:23:15Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.crypto.dsig.spec.XPathType;
import javax.xml.crypto.dsig.spec.XPathFilter2ParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import org.genxdm.mutable.NodeFactory;
import org.genxdm.names.NamespaceBinding;

/**
 * DOM-based implementation of XPath Filter 2.0 Transform.
 * (Uses Apache XML-Sec Transform implementation)
 *
 * @author Joyce Leung
 */
public final class DOMXPathFilter2Transform<N> extends ApacheTransform<N> {

    public void init(TransformParameterSpec params)
        throws InvalidAlgorithmParameterException {
        if (params == null) {
	    throw new InvalidAlgorithmParameterException("params are required");
	} else if (!(params instanceof XPathFilter2ParameterSpec)) {
	    throw new InvalidAlgorithmParameterException
		("params must be of type XPathFilter2ParameterSpec");
        }
	this.params = params;
    }

    public void init(XMLStructure parent, XMLCryptoContext context)
        throws InvalidAlgorithmParameterException {

	super.init(parent, context);
	try {
	    unmarshalParams(model.getFirstChildElement(transformElem));
	} catch (MarshalException me) {
	    throw (InvalidAlgorithmParameterException)
		new InvalidAlgorithmParameterException().initCause(me);
	}
    }

    private void unmarshalParams(N curXPathElem) throws MarshalException {
        List<XPathType> list = new ArrayList<XPathType>();
	while (curXPathElem != null) {
	    String xPath = BaseStructure.textOfNode(model, curXPathElem);
	    String filterVal = 
		model.getAttributeStringValue(curXPathElem, "", "Filter");
	    if (filterVal == null) {
		throw new MarshalException("filter cannot be null");
	    }
	    XPathType.Filter filter = null;
            if (filterVal.equals("intersect")) {
                filter = XPathType.Filter.INTERSECT;
            } else if (filterVal.equals("subtract")) {   
                filter = XPathType.Filter.SUBTRACT;
            } else if (filterVal.equals("union")) {
                filter = XPathType.Filter.UNION;
            } else {
                throw new MarshalException("Unknown XPathType filter type" 
		    + filterVal);
            }
	        Map<String, String> namespaceMap = new HashMap<String, String>();
	        for (NamespaceBinding nsBind : model.getNamespaceBindings(curXPathElem)) {
	        	
	        	// TODO - it would be good to document why this code only cares to add
	        	// the non-empty namespace prefixes.
	        	if (nsBind.getPrefix().length() > 0) {
	        		namespaceMap.put(nsBind.getPrefix(), nsBind.getNamespaceURI());
	        	}
	        }
	        list.add(new XPathType(xPath, filter, namespaceMap));

	    curXPathElem = model.getNextSiblingElement(curXPathElem);
	}
        this.params = new XPathFilter2ParameterSpec(list);
    }

    @SuppressWarnings("unchecked")
	private static List<XPathType> getParameterSpecXPathList(XPathFilter2ParameterSpec paramSpec) {
    	return paramSpec.getXPathList();
    }
    
    @SuppressWarnings("unchecked")
	private static Map<String, String> getXPathTypeNamespaceMap(XPathType xpathType) {
    	return xpathType.getNamespaceMap();
    }
    
    public void marshalParams(XMLStructure parent, XMLCryptoContext context)
        throws MarshalException {

	super.marshalParams(parent, context);
	XPathFilter2ParameterSpec xp = 
	    (XPathFilter2ParameterSpec) getParameterSpec();
        String prefix = DOMUtils.getNSPrefix(context, Transform.XPATH2);
	List<XPathType> list = getParameterSpecXPathList(xp);
	NodeFactory<N> factory = model.getFactory(transformElem);
	for (int i = 0, size = list.size(); i < size; i++) {
            XPathType xpathType = list.get(i);
            N elem = factory.createElement
                (Transform.XPATH2, "XPath", prefix);
            model.appendChild(elem, factory.createText(xpathType.getExpression()));
	    DOMUtils.setAttribute
		(factory, model, elem, "Filter", xpathType.getFilter().toString());
	    model.insertNamespace(elem, prefix, Transform.XPATH2);

            // add namespace attributes, if necessary
            Iterator<Map.Entry<String, String>> it = getXPathTypeNamespaceMap(xpathType).entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> entry = it.next();
                model.insertNamespace(elem, entry.getKey(), entry.getValue());
            }

            model.appendChild(transformElem, elem);
        }
    }
}
