/*
 * Copyright 2005 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMXMLObject.java 647272 2008-04-11 19:22:21Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;

import java.security.Provider;
import java.util.*;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;
import org.w3c.dom.Node;

/**
 * DOM-based implementation of XMLObject.
 *
 * @author Sean Mullan
 */
public final class DOMXMLObject extends BaseStructure implements XMLObject {
 
    private final String id;
    private final String mimeType;
    private final String encoding;
    private final List<XMLStructure> content;
    // official version of code stores the object element passed to one of the
    // constructors. However, that ties the marshaling code to be specific to the
    // particular subclass of XMLObject, and shouldn't be necessary.

    /**
     * Creates an <code>XMLObject</code> from the specified parameters.
     *
     * @param content a list of {@link XMLStructure}s. The list
     *    is defensively copied to protect against subsequent modification.
     *    May be <code>null</code> or empty.
     * @param id the Id (may be <code>null</code>)
     * @param mimeType the mime type (may be <code>null</code>)
     * @param encoding the encoding (may be <code>null</code>)
     * @return an <code>XMLObject</code>
     * @throws ClassCastException if <code>content</code> contains any
     *    entries that are not of type {@link XMLStructure}
     */
    public DOMXMLObject(List<XMLStructure> content, String id, String mimeType, 
	String encoding) {
        if (content == null || content.isEmpty()) {
            this.content = Collections.emptyList();
        } else {
            List<XMLStructure> contentCopy = new ArrayList<XMLStructure>(content);
            for (int i = 0, size = contentCopy.size(); i < size; i++) {
                if (!(contentCopy.get(i) instanceof XMLStructure)) {
                    throw new ClassCastException
                        ("content["+i+"] is not a valid type");
                }
            }
            this.content = Collections.unmodifiableList(contentCopy);
        }
	this.id = id;
	this.mimeType = mimeType;
	this.encoding = encoding;
    }

    /**
     * Creates an <code>XMLObject</code> from an element.
     *
     * @param objElem an Object element
     * @throws MarshalException if there is an error when unmarshalling
     */
    public <N> DOMXMLObject(MutableModel<N> model, N objElem, XMLCryptoContext context,
	Provider provider) throws MarshalException {
        List<XMLStructure> content = new ArrayList<XMLStructure>();
        
        // unmarshal attributes
        String encoding = null;
        String id = null;
        String mimeType = null;
        for (N attr : model.getAttributeAxis(objElem, false)) {
            if (model.getNamespaceURI(attr).equals("")) {
                if (model.getLocalName(attr).equals("Encoding")) {
                    encoding = model.getStringValue(attr);
                }
                else if (model.getLocalName(attr).equals("Id")) {
                    id = model.getStringValue(attr);
                }
                else if (model.getLocalName(attr).equals("MimeType")) {
                    mimeType = model.getStringValue(attr);
                }
            }
            else {
                content.add(new GenXDMStructure<N>(model, attr));
            }
        }
        this.encoding = encoding;
        this.id = id;
        this.mimeType = mimeType;

	for (N childElem : model.getChildAxis(objElem)) {
		
                String tag = model.getLocalName(childElem);
                if ("Manifest".equals(tag)) {
                    content.add(new DOMManifest<N>(model, childElem, context, provider));
		    continue;
                } else if ("SignatureProperties".equals(tag)) {
                    content.add(new DOMSignatureProperties(model, childElem));
		    continue;
                } else if ("X509Data".equals(tag)) {
                    content.add(new DOMX509Data(model, childElem));
		    continue;
			//@@@FIXME: check for other dsig structures
		}
        	    content.add(new GenXDMStructure<N>(model, childElem));
	    }
	
	    // starting with 1.4.6 of the official library, there's an attempt to preserve
	    // declared namespaces by preserving the original object, but then inserting said
	    // object into the target of marshaling - which could, of course, remove it from
	    // its original place in whatever document it comes from - which might be bad.
	    // so here we capture namespaces as GenXDMStructures - then the marshaller looks
	    // for GenXDMStructures that are isNamespace()....
	    for (N nsDecls : model.getNamespaceAxis(objElem, false)) {
	        content.add(new GenXDMStructure<N>(model, nsDecls));
	    }
	    
        if (content.isEmpty()) {
            this.content = Collections.emptyList();
        } else {
            this.content = Collections.unmodifiableList(content);
        }
    }

    public List<XMLStructure> getContent() {
        return content;
    }

    public String getId() {
        return id;
    }

    public String getMimeType() {
        return mimeType;
    }

    public String getEncoding() {
        return encoding;
    }

    public static <N> void marshal(XMLObject xmlObj, MutableModel<N> model, N parent, String dsPrefix, XMLCryptoContext context)
	throws MarshalException {
        
    	NodeFactory<N> factory = model.getFactory(parent);

        N objElem = factory.createElement
            (XMLSignature.XMLNS, "Object", dsPrefix);

        // set attributes
        DOMUtils.setAttributeID(factory, model, objElem, "Id", xmlObj.getId());
        DOMUtils.setAttribute(factory, model, objElem, "MimeType", xmlObj.getMimeType());
        DOMUtils.setAttribute(factory, model, objElem, "Encoding", xmlObj.getEncoding() );

        // create and append any elements and mixed content, if necessary
        @SuppressWarnings("unchecked")
        List<XMLStructure> content = xmlObj.getContent();
        for (XMLStructure object : content) {
            Marshaller.marshal(object, model, objElem, dsPrefix, context);
        }
	    
	model.appendChild(parent, objElem);
    }

    @SuppressWarnings("unchecked")
	public static List<XMLStructure> getXmlObjectContent(XMLObject xo) {
    	return xo.getContent();
    }
    
    public boolean equals(Object o) {
	if (this == o) {
            return true;
	}

        if (!(o instanceof XMLObject)) {
            return false;
	}
        XMLObject oxo = (XMLObject) o;

	boolean idsEqual = (id == null ? oxo.getId() == null :
	    id.equals(oxo.getId()));
	boolean encodingsEqual = (encoding == null ? oxo.getEncoding() == null :
	    encoding.equals(oxo.getEncoding()));
	boolean mimeTypesEqual = (mimeType == null ? oxo.getMimeType() == null :
	    mimeType.equals(oxo.getMimeType()));

	return (idsEqual && encodingsEqual && mimeTypesEqual && 
	    equalsContent(getXmlObjectContent(oxo)));
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 53;
    }

    private boolean equalsContent(List<XMLStructure> otherContent) {
        return equalsContent(content, otherContent);
    }

    /**
     * This is a public method because the DOMSignatureProperty shares the same logic.
     */
    public static boolean equalsContent(List<XMLStructure> content, List<XMLStructure> otherContent) {
        if (content.size() != otherContent.size()) {
            return false;
        }
        for (int i = 0, osize = otherContent.size(); i < osize; i++) {
            XMLStructure oxs = otherContent.get(i);
            XMLStructure xs = content.get(i);
            if (!areStructuresEqual(oxs, xs)) {
                return false;
            }
        }

        return true;
        }

    private static boolean areStructuresEqual(XMLStructure oxs, XMLStructure xs) {
        // is one or the other an instance of DOMStructure?
        // if so, we need to compare directly, since the DOMStructure equals method doesn't do
        // what we need.
        boolean oxsIsDom = oxs instanceof javax.xml.crypto.dom.DOMStructure;
        boolean xsIsDom = xs instanceof javax.xml.crypto.dom.DOMStructure;
        if (oxsIsDom || xsIsDom) {
            if (xsIsDom && !oxsIsDom) {
                return areDomAndNonDomEqual( (javax.xml.crypto.dom.DOMStructure) xs, oxs);
            }
            else if (!xsIsDom && oxsIsDom) {
                return areDomAndNonDomEqual( (javax.xml.crypto.dom.DOMStructure) oxs, xs);
            }
            
            return areDomStructuresEqual( (javax.xml.crypto.dom.DOMStructure) xs,  (javax.xml.crypto.dom.DOMStructure) oxs);
        }
        else {
            return xs.equals(oxs);
        }
        
    }
    
    private static boolean areDomStructuresEqual(javax.xml.crypto.dom.DOMStructure domStruct, javax.xml.crypto.dom.DOMStructure otherDomStruct) {

        return DOMUtils.nodesEqual(domStruct.getNode(), otherDomStruct.getNode() );
    }

    private static boolean areDomAndNonDomEqual(javax.xml.crypto.dom.DOMStructure domStruct, XMLStructure otherStruct) {
        
        // can we even compare?
        if (otherStruct instanceof GenXDMStructure) {
            // yes, potentially we can compare, but let's check
            GenXDMStructure<?> gxos = (GenXDMStructure<?>) otherStruct;
            Object node = gxos.getNode();
            if (node instanceof Node) {
                return DOMUtils.nodesEqual(domStruct.getNode(), (Node) node);
            }
        }
        
        return false;
    }
}
