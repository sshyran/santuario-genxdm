/*
 * Copyright 2005 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMKeyValue.java 647272 2008-04-11 19:22:21Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.keyinfo.KeyValue;

import java.math.BigInteger;
import java.security.KeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.DSAParams;
import java.security.interfaces.DSAPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.RSAPublicKeySpec;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.apache.xml.security.utils.Base64;
import org.genxdm.Model;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * DOM-based implementation of KeyValue.
 *
 * @author Sean Mullan
 */
public final class DOMKeyValue extends BaseStructure implements KeyValue {

    private KeyFactory rsakf, dsakf;
    private PublicKey publicKey;
    private XMLStructure externalPublicKey;

    public DOMKeyValue(PublicKey key)  throws KeyException {
	if (key == null) {
	    throw new NullPointerException("key cannot be null");
	}
	this.publicKey = key;
	if (key instanceof DSAPublicKey) {
        // used to save members - no longer necessary.
	} else if (key instanceof RSAPublicKey) {
	    // used to save members - no longer necessary.
	} else {
	    throw new KeyException("unsupported key algorithm: " +
		key.getAlgorithm());
	}
    }

    /**
     * Creates a <code>DOMKeyValue</code> from an element.
     *
     * @param kvElem a KeyValue element
     */
    public <N> DOMKeyValue(MutableModel<N> model, N kvElem) throws MarshalException {
	N kvtElem = model.getFirstChildElement(kvElem);
        if (model.getLocalName(kvtElem).equals("DSAKeyValue")) {
            publicKey = unmarshalDSAKeyValue(model, kvtElem);
        } else if (model.getLocalName(kvtElem).equals("RSAKeyValue")) {
            publicKey = unmarshalRSAKeyValue(model, kvtElem);
        } else {
	    publicKey = null;
	    externalPublicKey = new GenXDMStructure<N>(model, kvtElem);
	}
    }

    public PublicKey getPublicKey() throws KeyException {
	if (publicKey == null) {
	    throw new KeyException("can't convert KeyValue to PublicKey");
	} else {
            return publicKey;
	}
    }

    public <N> void marshal(MutableModel<N> model, N parent, String dsPrefix)
	throws MarshalException {
        NodeFactory<N> factory = model.getFactory(parent);

        // create KeyValue element
        N kvElem = factory.createElement
	    (XMLSignature.XMLNS, "KeyValue", dsPrefix);
        marshalPublicKey(factory, model, kvElem, dsPrefix);

        model.appendChild(parent, kvElem);
    }

    private <N> void marshalPublicKey(NodeFactory<N> factory, MutableModel<N> model, N parent, String dsPrefix) throws MarshalException {
        if (publicKey != null) {
            if (publicKey instanceof DSAPublicKey) {
                // create and append DSAKeyValue element
                marshalDSAPublicKey( (DSAPublicKey) publicKey, factory, model, parent, dsPrefix);
            } else if (publicKey instanceof RSAPublicKey) {
                // create and append RSAKeyValue element
                marshalRSAPublicKey( (RSAPublicKey) publicKey, factory, model, parent, dsPrefix);
            } else {
                throw new MarshalException(publicKey.getAlgorithm() +
                    " public key algorithm not supported");
            }
        } else {
            Marshaller.marshal(externalPublicKey, model, parent, dsPrefix, null);
        }
    }

    private static <N> void marshalDSAPublicKey(DSAPublicKey dsaKey, NodeFactory<N> factory, MutableModel<N> model, N parent,
    		String dsPrefix) throws MarshalException {
        DSAParams params = dsaKey.getParams();
        N dsaElem = factory.createElement
	    (XMLSignature.XMLNS, "DSAKeyValue", dsPrefix);
        // parameters J, Seed & PgenCounter are not included
        N pElem = factory.createElement
	    (XMLSignature.XMLNS, "P", dsPrefix);
        N qElem = factory.createElement
	    (XMLSignature.XMLNS, "Q", dsPrefix);
        N gElem = factory.createElement
	    (XMLSignature.XMLNS, "G", dsPrefix);
        N yElem = factory.createElement
	    (XMLSignature.XMLNS, "Y", dsPrefix);
        marshal(params.getP(), model, pElem, dsPrefix);
        marshal(params.getQ(), model, qElem, dsPrefix);
        marshal(params.getG(), model, gElem, dsPrefix);
        marshal(dsaKey.getY(), model, yElem, dsPrefix);
        model.appendChild(dsaElem, pElem);
        model.appendChild(dsaElem, qElem);
        model.appendChild(dsaElem, gElem);
        model.appendChild(dsaElem, yElem);
        model.appendChild(parent, dsaElem);
    }

    private static <N> void marshalRSAPublicKey(RSAPublicKey rsaKey, NodeFactory<N> factory, MutableModel<N> model, N parent,
	String dsPrefix) throws MarshalException {
        N rsaElem = factory.createElement
	    (XMLSignature.XMLNS, "RSAKeyValue", dsPrefix);
        N modulusElem = factory.createElement
	    (XMLSignature.XMLNS, "Modulus", dsPrefix);
        N exponentElem = factory.createElement
	    (XMLSignature.XMLNS, "Exponent", dsPrefix);
	marshal(rsaKey.getModulus(), model, modulusElem, dsPrefix);
	marshal(rsaKey.getPublicExponent(), model, exponentElem, dsPrefix);
        model.appendChild(rsaElem, modulusElem);
        model.appendChild(rsaElem, exponentElem);
        model.appendChild(parent, rsaElem);
    }

    private <N> DSAPublicKey unmarshalDSAKeyValue(MutableModel<N> model, N kvtElem) 
	throws MarshalException {
	if (dsakf == null) {
	    try {
	        dsakf = KeyFactory.getInstance("DSA");
	    } catch (NoSuchAlgorithmException e) {
	        throw new RuntimeException("unable to create DSA KeyFactory: " +
		    e.getMessage());
	    }
	}
	N curElem = model.getFirstChildElement(kvtElem);
	// check for P and Q
	BigInteger p = null;
	BigInteger q = null;
	if (model.getLocalName(curElem).equals("P")) {
	    p = decode(model, curElem);
	    curElem = model.getNextSiblingElement(curElem);
	    q = decode(model, curElem);
	    curElem = model.getNextSiblingElement(curElem);
	}
	BigInteger g = null;
        if (model.getLocalName(curElem).equals("G")) {
            g = decode(model, curElem);
	    curElem = model.getNextSiblingElement(curElem);
	}
        BigInteger y = decode(model, curElem);
        curElem = model.getNextSiblingElement(curElem);
        if (curElem != null && model.getLocalName(curElem).equals("J")) {
        	// it appears that the "j" value is unused 
	    /*j = new DOMCryptoBinary(curElem.getFirstChild()); */
	    curElem = model.getNextSiblingElement(curElem);
	}
	if (curElem != null) {
	    /* seed = new DOMCryptoBinary(curElem.getFirstChild()); */
	    curElem = model.getNextSiblingElement(curElem);
	    /* pgen = new DOMCryptoBinary(curElem.getFirstChild()); */
	}
	//@@@ do we care about j, pgenCounter or seed?
	DSAPublicKeySpec spec = new DSAPublicKeySpec
	    (y, p, q, g);
        return (DSAPublicKey) generatePublicKey(dsakf, spec);
    }

    private <N> RSAPublicKey unmarshalRSAKeyValue(Model<N> model, N kvtElem) 
	throws MarshalException {
	if (rsakf == null) {
	    try {
	        rsakf = KeyFactory.getInstance("RSA");
	    } catch (NoSuchAlgorithmException e) {
	        throw new RuntimeException("unable to create RSA KeyFactory: " +
		    e.getMessage());
	    }
	}
	N modulusElem = model.getFirstChildElement(kvtElem);
        BigInteger modulus = decode(model, modulusElem);
	N exponentElem = model.getNextSiblingElement(modulusElem);
        BigInteger exponent = decode(model, exponentElem);
        
        RSAPublicKeySpec spec = new RSAPublicKeySpec(modulus, exponent);
        return (RSAPublicKey) generatePublicKey(rsakf, spec);
    }

    private PublicKey generatePublicKey(KeyFactory kf, KeySpec keyspec) {
        try {
            return kf.generatePublic(keyspec);
        } catch (InvalidKeySpecException e) {
	    //@@@ should dump exception to log
	    return null;
        }
    }
    
    public boolean equals(Object obj) {
	if (this == obj) {
	    return true;
	}
        if (!(obj instanceof KeyValue)) {
            return false;
        }
	try {
            KeyValue kv = (KeyValue) obj;
            if (publicKey == null ) {
                if (kv.getPublicKey() != null) {
                    return false;
                }
            } else if (!publicKey.equals(kv.getPublicKey())) {
                return false;
            }
	} catch (KeyException ke) {
	    // no practical way to determine if the keys are equal
	    return false;
	}
        
        return true;
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 45;
    }

    public static <N> BigInteger decode(Model<N> model, N elem) throws MarshalException {
        try {
            String base64str = BaseStructure.textOfNode(model, elem);
            return Base64.decodeBigIntegerFromString(base64str);
        } catch (Exception ex) {
            throw new MarshalException(ex);
        }
    }

    public static <N> void marshal(BigInteger bigNum, MutableModel<N> model, N parent, String prefix) {
        NodeFactory<N> factory = model.getFactory(parent);
        model.appendChild(parent, factory.createText( Base64.encode(bigNum)));
    }
}
