/*
 * Copyright 2005 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMX509IssuerSerial.java 647272 2008-04-11 19:22:21Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;

import java.math.BigInteger;
import javax.security.auth.x500.X500Principal;

import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * DOM-based implementation of X509IssuerSerial.
 *
 * @author Sean Mullan
 */
public final class DOMX509IssuerSerial extends BaseStructure
    implements X509IssuerSerial {

    private final String issuerName;
    private final BigInteger serialNumber;

    /**
     * Creates a <code>DOMX509IssuerSerial</code> containing the specified 
     * issuer distinguished name/serial number pair.
     *
     * @param issuerName the X.509 issuer distinguished name in RFC 2253 
     *    String format
     * @param serialNumber the serial number
     * @throws IllegalArgumentException if the format of <code>issuerName</code>
     *    is not RFC 2253 compliant
     * @throws NullPointerException if <code>issuerName</code> or 
     *    <code>serialNumber</code> is <code>null</code> 
     */
    public DOMX509IssuerSerial(String issuerName, BigInteger serialNumber) {
	if (issuerName == null) {
	    throw new NullPointerException("issuerName cannot be null");
	}
	if (serialNumber == null) {
	    throw new NullPointerException("serialNumber cannot be null");
	}
	// check that issuer distinguished name conforms to RFC 2253
	new X500Principal(issuerName);
	this.issuerName = issuerName;
	this.serialNumber = serialNumber;
    }

    /**
     * Creates a <code>DOMX509IssuerSerial</code> from an element.
     *
     * @param isElem an X509IssuerSerial element
     */
    public <N> DOMX509IssuerSerial(MutableModel<N> model, N isElem) {
        N iNElem = model.getFirstChildElement(isElem);
        N sNElem = model.getNextSiblingElement(iNElem);
        issuerName = textOfNode(model, iNElem);
	serialNumber = new BigInteger(textOfNode(model, sNElem));
    }

    public String getIssuerName() {
	return issuerName;
    }

    public BigInteger getSerialNumber() {
	return serialNumber;
    }

    public static <N> void marshal(X509IssuerSerial issuerSerial, MutableModel<N> model, N parent, String dsPrefix)
	throws MarshalException {
    	NodeFactory<N> factory = model.getFactory(parent);

        N isElem = factory.createElement
            (XMLSignature.XMLNS, "X509IssuerSerial", dsPrefix);
        N inElem = factory.createElement
            (XMLSignature.XMLNS, "X509IssuerName", dsPrefix);
        N snElem = factory.createElement
            (XMLSignature.XMLNS, "X509SerialNumber", dsPrefix);
        model.appendChild(inElem, factory.createText( issuerSerial.getIssuerName()));
        model.appendChild(snElem, factory.createText( issuerSerial.getSerialNumber().toString()));
        model.appendChild(isElem, inElem);
        model.appendChild(isElem, snElem);
        model.appendChild(parent, isElem);
    }

    public boolean equals(Object obj) {
	if (this == obj) {
            return true;
	}
        if (!(obj instanceof X509IssuerSerial)) {
            return false;
	}
        X509IssuerSerial ois = (X509IssuerSerial) obj;
	return (issuerName.equals(ois.getIssuerName()) && 
	    serialNumber.equals(ois.getSerialNumber()));
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 52;
    }
}
