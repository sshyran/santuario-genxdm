/*
 * Copyright 2005-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Portions copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * ===========================================================================
 *
 * (C) Copyright IBM Corp. 2003 All Rights Reserved.
 *
 * ===========================================================================
 */
/*
 * $Id: DOMXMLSignature.java 889299 2009-12-10 15:38:07Z mullan $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.Provider;
import java.util.Collections;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.jcp.crypto.genxdm.GenXDMSignContext;
import org.apache.jcp.crypto.genxdm.GenXDMValidateContext;
import org.apache.xml.security.exceptions.Base64DecodingException;
import org.apache.xml.security.utils.Base64;
import org.genxdm.Model;
import org.genxdm.compat.DomCompatibility;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * DOM-based implementation of XMLSignature.
 *
 * @author Sean Mullan
 * @author Joyce Leung
 */
public final class DOMXMLSignature<N> extends DOMStructure<N>
    implements XMLSignature {

    private static Logger log = Logger.getLogger("org.jcp.xml.dsig.internal.dom");
    private String id;
    private SignatureValue sv;
    private KeyInfo ki;
    private List<XMLObject> objects;
    private SignedInfo si;
    private boolean validationStatus;
    private boolean validated = false;
    private KeySelectorResult ksr;
    private HashMap<String, XMLStructure> signatureIdMap;

    static {
	org.apache.xml.security.Init.init();
    }
 
    /**
     * Creates a <code>DOMXMLSignature</code> from the specified components.
     *
     * @param si the <code>SignedInfo</code>
     * @param ki the <code>KeyInfo</code>, or <code>null</code> if not specified
     * @param objs a list of <code>XMLObject</code>s or <code>null</code>
     *  if not specified. The list is copied to protect against subsequent
     *  modification.
     * @param id an optional id (specify <code>null</code> to omit)
     * @param signatureValueId an optional id (specify <code>null</code> to
     *  omit)
     * @throws NullPointerException if <code>si</code> is <code>null</code>
     */
    public DOMXMLSignature(SignedInfo si, KeyInfo ki, List<XMLObject> objs, String id, 
	String signatureValueId)
    {
        if (si == null) {
            throw new NullPointerException("signedInfo cannot be null");
        }
        this.si = si;
        this.id = id;
        this.sv = new DOMSignatureValue<N>(signatureValueId);
        if (objs == null) {
            this.objects = Collections.emptyList();
        } else {
            List<XMLObject> objsCopy = new ArrayList<XMLObject>(objs);
            for (int i = 0, size = objsCopy.size(); i < size; i++) {
                if (!(objsCopy.get(i) instanceof XMLObject)) {
                    throw new ClassCastException
                        ("objs["+i+"] is not an XMLObject");
                }
            }
            this.objects = Collections.unmodifiableList(objsCopy);
        }
        this.ki = ki;                
    }

    /**
     * Creates a <code>DOMXMLSignature</code> from XML.
     *
     * @param sigElem Signature element
     * @throws MarshalException if XMLSignature cannot be unmarshalled
     */
    public DOMXMLSignature(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, N sigElem, XMLCryptoContext context,
	Provider provider) throws MarshalException {
        N localSigElem = sigElem;

        // get Id attribute, if specified
	id = DOMUtils.getAttributeValue(model, localSigElem, "Id");

	// unmarshal SignedInfo
	N siElem = model.getFirstChildElement(localSigElem);
	si = new DOMSignedInfo<N>(docFactory, model, siElem, context, provider);

	// unmarshal SignatureValue 
	N sigValElem = model.getNextSiblingElement(siElem);
	sv = new DOMSignatureValue<N>(model, sigValElem);

	// unmarshal KeyInfo, if specified
	N nextSibling = model.getNextSiblingElement(sigValElem);
	if (nextSibling != null && model.getLocalName(nextSibling).equals("KeyInfo")) {
	    ki = new DOMKeyInfo(docFactory, model, nextSibling, context, provider);
	    nextSibling = model.getNextSiblingElement(nextSibling);
	}

	// unmarshal Objects, if specified
	if (nextSibling == null) {
	    objects = Collections.emptyList();
	} else {
	    List<XMLObject> tempObjects = new ArrayList<XMLObject>();
	    while (nextSibling != null) {
	        tempObjects.add
		    (new DOMXMLObject(model, nextSibling, context, provider));
	        nextSibling = model.getNextSiblingElement(nextSibling);
	    }
	    objects = Collections.unmodifiableList(tempObjects);	
	}
    }

    public String getId() {
        return id;
    }

    public KeyInfo getKeyInfo() {
        return ki;
    }

    public SignedInfo getSignedInfo() {
        return si;
    }

    public List<XMLObject> getObjects() {
        return objects;
    }

    public SignatureValue getSignatureValue() {
	return sv;
    }

    public KeySelectorResult getKeySelectorResult() {
	return ksr;
    }

    public void marshal(MutableModel<N> model, N parent, String dsPrefix, XMLCryptoContext context)
	throws MarshalException {
	marshal(model, parent, null, dsPrefix, context);
    }

    public void marshal(MutableModel<N> model, N parent, N nextSibling, String dsPrefix,
        XMLCryptoContext context) throws MarshalException {
    	NodeFactory<N> factory = model.getFactory(parent); 

    	// rationalize the prefix.
    	if (dsPrefix == null) {
    	    dsPrefix = "";
    	}
        N sigElem = factory.createElement
            (XMLSignature.XMLNS, "Signature", dsPrefix);

        // append xmlns attribute
    	model.insertNamespace(sigElem, dsPrefix, XMLSignature.XMLNS);

	// create and append SignedInfo element
	((DOMSignedInfo<N>) si).marshal(model, sigElem, dsPrefix, context);

        // create and append SignatureValue element
	((DOMSignatureValue) sv).marshal(model, sigElem, dsPrefix, context);

	// create and append KeyInfo element if necessary
	if (ki != null) {
	    DOMKeyInfo.marshal(ki, model, sigElem, dsPrefix, context);
	}

	// create and append Object elements if necessary
	for (XMLObject xmlObj : objects) {
	    DOMXMLObject.marshal(xmlObj, model, sigElem, dsPrefix, context);
	}

	// append Id attribute
        DOMUtils.setAttributeID(factory, model, sigElem, "Id", id);
	    
        DomCompatibility.insertBefore(model, parent, sigElem, nextSibling);
    }

    public boolean validate(XMLValidateContext vc) 
	throws XMLSignatureException {

	if (vc == null) {
	    throw new NullPointerException("validateContext is null");
	}

        if (!(vc instanceof DOMValidateContext) && !(vc instanceof GenXDMValidateContext)) {
            throw new ClassCastException
                ("validateContext must be of type DOMValidateContext or GenXDMValidateContext");
        }

	if (validated) {
	    return validationStatus;
	}

        // validate the signature
        boolean sigValidity = sv.validate(vc);
        if (!sigValidity) {
            validationStatus = false;
            validated = true;
            return validationStatus;
        }

        // validate all References
        List<Reference> refs = DOMSignedInfo.getSignedInfoReferences(this.si);
        boolean validateRefs = true;
        for (int i = 0, size = refs.size(); validateRefs && i < size; i++) {
            Reference ref = refs.get(i);
            boolean refValid = ref.validate(vc);
	    if (log.isLoggable(Level.FINE)) {
                log.log(Level.FINE, "Reference[" + ref.getURI() + "] is valid: "
		    + refValid);
	    }
            validateRefs &= refValid;
        }
        if (!validateRefs) {
	    if (log.isLoggable(Level.FINE)) {
                log.log(Level.FINE, "Couldn't validate the References");
	    }
	    validationStatus = false;
	    validated = true;
	    return validationStatus;
        }

	// validate Manifests, if property set
        boolean validateMans = true;
	if (Boolean.TRUE.equals(vc.getProperty
	    ("org.jcp.xml.dsig.validateManifests"))) {

	    for (int i=0, size=objects.size(); validateMans && i < size; i++) {
                XMLObject xo = (XMLObject) objects.get(i);
                List<XMLStructure> content = DOMXMLObject.getXmlObjectContent(xo);
		int csize = content.size();
                for (int j = 0; validateMans && j < csize; j++) {
                    XMLStructure xs = content.get(j);
                    if (xs instanceof Manifest) {
	    		if (log.isLoggable(Level.FINE)) {
                            log.log(Level.FINE, "validating manifest");
			}
                        Manifest man = (Manifest) xs;
                        List<Reference> manRefs = DOMManifest.getManifestReferences(man);
			int rsize = manRefs.size();
                        for (int k = 0; validateMans && k < rsize; k++) {
                            Reference ref = (Reference) manRefs.get(k);
                            boolean refValid = ref.validate(vc);
	    		    if (log.isLoggable(Level.FINE)) {
                                log.log(Level.FINE, "Manifest ref[" 
				    + ref.getURI() + "] is valid: " + refValid);
			    }
			    validateMans &= refValid;
			}
                    }
                }
            }
	}

	validationStatus = validateMans;
	validated = true;
	return validationStatus;
    }

    public void sign(XMLSignContext signContext) 
	throws MarshalException, XMLSignatureException {
	if (signContext == null) {
	    throw new NullPointerException("signContext cannot be null");
	}
        MutableModel<N> model = GenXDMCryptoContext.getModel(signContext);
        N parent = GenXDMSignContext.getParent(model, signContext);
        N nextSibling = GenXDMSignContext.getNextSibling(model, signContext);
        
        marshal( model, parent, nextSibling,
            DOMUtils.getSignaturePrefix(signContext), signContext);

	// generate references and signature value
	List<Reference> allReferences = new ArrayList<Reference>();

	// traverse the Signature and register all objects with IDs that
	// may contain References
	signatureIdMap = new HashMap<String, XMLStructure>();
	signatureIdMap.put(id, this);
	signatureIdMap.put(si.getId(), si);
	List<Reference> refs = DOMSignedInfo.getSignedInfoReferences(si);
	for (int i = 0, size = refs.size(); i < size; i++) {
            Reference ref = refs.get(i);
            signatureIdMap.put(ref.getId(), ref);
	}
	for (int i = 0, size = objects.size(); i < size; i++) {
            XMLObject obj = objects.get(i);
            signatureIdMap.put(obj.getId(), obj);
            List<XMLStructure> content = DOMXMLObject.getXmlObjectContent(obj);
	    for (int j = 0, csize = content.size(); j < csize; j++) {
		XMLStructure xs = content.get(j);
		if (xs instanceof Manifest) {
                    Manifest man = (Manifest) xs;
                    signatureIdMap.put(man.getId(), man);
                    List<Reference> manRefs = DOMManifest.getManifestReferences(man);
                    for (Reference ref : manRefs) {
                        allReferences.add(ref);
                        signatureIdMap.put(ref.getId(), ref);
                    }
		        }
            }
	}
        // always add SignedInfo references after Manifest references so
        // that Manifest reference are digested first
        allReferences.addAll(DOMSignedInfo.getSignedInfoReferences(si));

        // generate/digest each reference
	for (int i = 0, size = allReferences.size(); i < size; i++) {
            DOMReference<N> ref = (DOMReference<N>) allReferences.get(i);
            digestReference(ref, signContext);
	}

        // do final sweep to digest any references that were skipped or missed
	for (int i = 0, size = allReferences.size(); i < size; i++) {
            DOMReference<N> ref = (DOMReference<N>) allReferences.get(i);
            if (ref.isDigested()) {
		continue;
            }
            ref.digest(signContext);
	}

        Key signingKey = null;
	KeySelectorResult ksr = null;
	try {
            ksr = signContext.getKeySelector().select
		(ki, KeySelector.Purpose.SIGN,
		si.getSignatureMethod(), signContext);
            signingKey = ksr.getKey();
            if (signingKey == null) {
		throw new XMLSignatureException("the keySelector did not " +
            	"find a signing key");
            }
	} catch (KeySelectorException kse) {
            throw new XMLSignatureException("cannot find signing key", kse);
	}

	// calculate signature value
	byte[] val = null;
	try {
            val = ((DOMSignatureMethod) si.getSignatureMethod()).sign
		(signingKey, (DOMSignedInfo<N>) si, signContext);
	} catch (InvalidKeyException ike) {
            throw new XMLSignatureException(ike);
	}

	((DOMSignatureValue<N>) sv).setValue(model, val);

	this.ksr = ksr;
    }

    public boolean equals(Object o) {
	if (this == o) {
	    return true;
	}

	if (!(o instanceof XMLSignature)) {
	    return false;
	}
	XMLSignature osig = (XMLSignature) o;

	boolean idEqual = 
	    (id == null ? osig.getId() == null : id.equals(osig.getId()));
	boolean keyInfoEqual = 
	    (ki == null ? osig.getKeyInfo() == null : 
	     ki.equals(osig.getKeyInfo()));

	boolean svEqual = sv.equals(osig.getSignatureValue());
	boolean sigInfoEqual = si.equals(osig.getSignedInfo());
	boolean objectsEqual = objects.equals(osig.getObjects());
	return (idEqual && keyInfoEqual && 
	    svEqual &&
	    sigInfoEqual && 
	    objectsEqual);
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 54;
    }

    private void digestReference(DOMReference ref, XMLSignContext signContext)
	throws XMLSignatureException {
	if (ref.isDigested()) {
       	    return;
	}
        // check dependencies
	String uri = ref.getURI();
	if (Utils.sameDocumentURI(uri)) {
            String id = Utils.parseIdFromSameDocumentURI(uri);
            if (id != null && signatureIdMap.containsKey(id)) {
		Object obj = signatureIdMap.get(id);
		if (obj instanceof DOMReference) {
                    digestReference((DOMReference) obj, signContext);
		} else if (obj instanceof Manifest) {
                    Manifest man = (Manifest) obj;
                    List<Reference> manRefs = DOMManifest.getManifestReferences(man);
		    for (int i = 0, size = manRefs.size(); i < size; i++) {
			digestReference
                 	    ((DOMReference) manRefs.get(i), signContext);
		    }
		}
            }
	    // if uri="" and there are XPath Transforms, there may be
	    // reference dependencies in the XPath Transform - so be on
	    // the safe side, and skip and do at end in the final sweep
	    if (uri.length() == 0) {
		List<Transform> transforms = ref.getTransforms();
		for (int i = 0, size = transforms.size(); i < size; i++) {
		    Transform transform = transforms.get(i);
		    String transformAlg = transform.getAlgorithm();
		    if (transformAlg.equals(Transform.XPATH) ||
			transformAlg.equals(Transform.XPATH2)) {
                	return;
                    }
            	}
            }
	}
	ref.digest(signContext);
    }

    public class DOMSignatureValue<NT> extends DOMStructure<NT>
	implements SignatureValue {

	private String id;
        private byte[] value;
        private String valueBase64;
        private NT sigValueElem;
	private boolean validated = false;
	private boolean validationStatus;

	DOMSignatureValue(String id) {
	    this.id = id;
	}

	DOMSignatureValue(Model<NT> model, NT sigValueElem) throws MarshalException {
	    try {
	        // base64 decode signatureValue
	        value = Base64.decode(model, sigValueElem);
	    } catch (Base64DecodingException bde) {
	        throw new MarshalException(bde);
	    }

	    id = DOMUtils.getAttributeValue(model, sigValueElem, "Id");
	    this.sigValueElem = sigValueElem;
	}

	public String getId() {
	    return id;
	}

        public byte[] getValue() {
	    return (value == null) ? null : (byte[]) value.clone();
        }

        public boolean validate(XMLValidateContext validateContext) 
	    throws XMLSignatureException {

	    if (validateContext == null) {
		throw new NullPointerException("context cannot be null");
	    }

	    if (validated) {
		return validationStatus;
	    }

	    // get validating key
	    SignatureMethod sm = si.getSignatureMethod();
	    Key validationKey = null;
	    KeySelectorResult ksResult;
	    try {
		ksResult = validateContext.getKeySelector().select
		    (ki, KeySelector.Purpose.VERIFY, sm, validateContext);
		validationKey = ksResult.getKey();
		if (validationKey == null) {
		    throw new XMLSignatureException("the keyselector did " +
			"not find a validation key");
		}
	    } catch (KeySelectorException kse) {
		throw new XMLSignatureException("cannot find validation " +
		    "key", kse);
	    }

	    // canonicalize SignedInfo and verify signature
	    try {
		validationStatus = ((DOMSignatureMethod) sm).verify
		    (validationKey, (DOMSignedInfo<N>) si, value, validateContext);
	    } catch (Exception e) {
		throw new XMLSignatureException(e);
	    }

	    validated = true;
	    ksr = ksResult;
	    return validationStatus;
        }

        public boolean equals(Object o) {
	    if (this == o) {
	        return true;
	    }

	    if (!(o instanceof SignatureValue)) {
	        return false;
	    }
	    SignatureValue osv = (SignatureValue) o;

	    boolean idEqual = 
	        (id == null ? osv.getId() == null : id.equals(osv.getId()));

	    //XXX compare signature values?
	    return idEqual;
	}
    
        public int hashCode() {
	    assert false : "hashCode not designed";
	    return 55;
	}

	public void marshal(MutableModel<NT> model, NT parent, String dsPrefix,
	    XMLCryptoContext context) throws MarshalException {

		NodeFactory<NT> factory = model.getFactory(parent);
            // create SignatureValue element
            sigValueElem = factory.createElement
                (XMLSignature.XMLNS, "SignatureValue", dsPrefix);
	    if (valueBase64 != null) {
	        model.appendChild(sigValueElem, factory.createText(valueBase64));
	    }

            // append Id attribute, if specified
            DOMUtils.setAttributeID(factory, model, sigValueElem, "Id", id);
            model.appendChild(parent, sigValueElem);
	}

	void setValue(MutableModel<NT> model, byte[] value) {
	    this.value = value;
            valueBase64 = Base64.encode(value);
            NodeFactory<NT> factory = model.getFactory(sigValueElem);
            model.appendChild(sigValueElem, factory.createText(valueBase64));
	}
    }
}
