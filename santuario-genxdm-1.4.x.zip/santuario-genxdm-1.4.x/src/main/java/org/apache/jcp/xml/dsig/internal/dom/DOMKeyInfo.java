/*
 * Copyright 2005-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: DOMKeyInfo.java 793943 2009-07-14 15:33:19Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import javax.xml.crypto.*;
import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;

import java.security.Provider;
import java.util.*;

import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.genxdm.compat.DomCompatibility;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

/**
 * DOM-based implementation of KeyInfo.
 *
 * @author Sean Mullan
 */
public final class DOMKeyInfo extends BaseStructure implements KeyInfo {

    private final String id;
    private final List<XMLStructure> keyInfoTypes;

    /**
     * A utility function to suppress casting warnings.
     * @param ki
     * @return
     */
    @SuppressWarnings("unchecked")
    public static List<XMLStructure> getContent(KeyInfo ki) {
        return ki.getContent();
    }
    
    /**
     * Creates a <code>DOMKeyInfo</code>.
     *
     * @param content a list of one or more {@link XMLStructure}s representing
     *    key information types. The list is defensively copied to protect
     *    against subsequent modification.
     * @param id an ID attribute
     * @throws NullPointerException if <code>content</code> is <code>null</code>
     * @throws IllegalArgumentException if <code>content</code> is empty
     * @throws ClassCastException if <code>content</code> contains any entries
     *    that are not of type {@link XMLStructure}
     */
    public DOMKeyInfo(List<XMLStructure> content, String id) {
        if (content == null) {
            throw new NullPointerException("content cannot be null");
	}
	List<XMLStructure> typesCopy = new ArrayList<XMLStructure>(content);
	if (typesCopy.isEmpty()) {
	    throw new IllegalArgumentException("content cannot be empty");
	}
	for (int i = 0, size = typesCopy.size(); i < size; i++) {
	    if (!(typesCopy.get(i) instanceof XMLStructure)) {
		throw new ClassCastException
		    ("content["+i+"] is not a valid KeyInfo type");
	    }
	}
	this.keyInfoTypes = Collections.unmodifiableList(typesCopy);
        this.id = id;
    }

    /**
     * Creates a <code>DOMKeyInfo</code> from XML.
     *
     * @param kiElem KeyInfo element
     */
    public <N> DOMKeyInfo(DocumentHandlerFactory<N> docFactory, MutableModel<N> model, N kiElem, XMLCryptoContext context,
	Provider provider) throws MarshalException {
	// get Id attribute, if specified
	id = DOMUtils.getAttributeValue(model, kiElem, "Id");

	List<XMLStructure> content = new ArrayList<XMLStructure>();
	
		for (N childElem : model.getChildElements(kiElem)) {
			
	    String localName = model.getLocalName(childElem);
            if (localName.equals("X509Data")) {
	        content.add(new DOMX509Data(model, childElem));
            } else if (localName.equals("KeyName")) {
	        content.add(new DOMKeyName(model, childElem));
            } else if (localName.equals("KeyValue")) {
	        content.add(new DOMKeyValue(model, childElem));
            } else if (localName.equals("RetrievalMethod")) {
	        content.add
		    (new DOMRetrievalMethod<N>(model, childElem, context, provider));
            } else if (localName.equals("PGPData")) {
	        content.add(new DOMPGPData(model, childElem));
	    } else { //may be MgmtData, SPKIData or element from other namespace
	        content.add(new GenXDMStructure<N>(model, childElem));
	    }
        }
	keyInfoTypes = Collections.unmodifiableList(content);
    }

    public String getId() {
	return id;
    }

    public List<XMLStructure> getContent() {
	return keyInfoTypes;
    }

    public void marshal(XMLStructure parent, XMLCryptoContext context)
        throws MarshalException {
        if (parent == null) {
            throw new NullPointerException("parent is null");
        }

        internalMarshal(parent, context);
    }

    private <N> void internalMarshal(XMLStructure parent, XMLCryptoContext context)
            throws MarshalException {
        MutableModel<N> model = GenXDMStructure.getModel(parent);
        N pNode = GenXDMStructure.getNode(model, parent);
        String dsPrefix = DOMUtils.getSignaturePrefix(context);
        NodeFactory<N> factory = model.getFactory(pNode); 
        N kiElem = factory.createElement
            (XMLSignature.XMLNS, "KeyInfo",
             dsPrefix);
        
        model.insertNamespace(kiElem, dsPrefix, XMLSignature.XMLNS);
        
        marshal(this, model, pNode, kiElem, null, dsPrefix, context);
    }

    public static <N> void marshal(KeyInfo ki, MutableModel<N> model, N parent, String dsPrefix, 
	XMLCryptoContext context) throws MarshalException {
        NodeFactory<N> factory = model.getFactory(parent);

        N kiElem = factory.createElement
            (XMLSignature.XMLNS, "KeyInfo", dsPrefix);
        marshal(ki, model, parent, kiElem, null, dsPrefix, context);
    }

    private static <N> void marshal(KeyInfo ki, MutableModel<N> model, N parent, N kiElem, N nextSibling,
        String dsPrefix, XMLCryptoContext context) throws MarshalException {
    	
    	NodeFactory<N> factory = model.getFactory(parent);
        // create and append KeyInfoType elements
    	List<XMLStructure> keyInfoTypes = getContent(ki);
    	for (XMLStructure kiType : keyInfoTypes) {
    	    Marshaller.marshal(kiType, model, kiElem, dsPrefix, context);
        }

        // append id attribute
        DOMUtils.setAttributeID(factory, model, kiElem, "Id", ki.getId());

        DomCompatibility.insertBefore(model, parent, kiElem, nextSibling);
    }

    public boolean equals(Object o) {
	if (this == o) {
            return true;
	}

        if (!(o instanceof KeyInfo)) {
            return false;
	}
        KeyInfo oki = (KeyInfo) o;

	boolean idsEqual = (id == null ? oki.getId() == null :
	    id.equals(oki.getId()));

	return (keyInfoTypes.equals(oki.getContent()) && idsEqual);
    }

    public int hashCode() {
	assert false : "hashCode not designed";
	return 43;
    }
}
