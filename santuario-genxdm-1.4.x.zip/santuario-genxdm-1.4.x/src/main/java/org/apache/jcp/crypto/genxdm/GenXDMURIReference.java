package org.apache.jcp.crypto.genxdm;

import javax.xml.crypto.URIReference;
import javax.xml.crypto.dom.DOMURIReference;

import org.genxdm.mutable.MutableModel;

/**
 * A GenXDM specific reference to a node, following the pattern of the
 * {@link DOMURIReference}
 */
public interface GenXDMURIReference<N> extends URIReference {

    /**
     * Returns the here node.
     *
     * @return the attribute or processing instruction node or the
     *    parent element of the text node that directly contains the URI 
     */
    N getHereNode();
    
    /**
     * In GenXDM, the "node" is meaningless without the model to
     * go with it, so this returns the model associated with the "here" node.
     * 
     * @return The appropriate model. 
     */
    MutableModel<N> getModel();
}
