package org.apache.jcp.xml.dsig.internal.dom;

public class XMLDSigGenXDM extends ProviderBaseClass {

    private static final long serialVersionUID = 7771056201768266964L;

    public XMLDSigGenXDM(String variant) {
        super("GenXDM");
    }

}
