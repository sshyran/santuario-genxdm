/*
 * Copyright 2005-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
/*
 * Copyright 2005 Sun Microsystems, Inc. All rights reserved.
 */
/*
 * $Id: ApacheCanonicalizer.java 793943 2009-07-14 15:33:19Z coheigea $
 */
package org.apache.jcp.xml.dsig.internal.dom;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.security.spec.AlgorithmParameterSpec;
import java.security.InvalidAlgorithmParameterException;
import java.util.Set;
import java.util.logging.Logger;
import java.util.logging.Level;
import javax.xml.crypto.*;
import javax.xml.crypto.dom.DOMCryptoContext;
import javax.xml.crypto.dsig.TransformException;
import javax.xml.crypto.dsig.TransformService;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;

import org.apache.jcp.crypto.genxdm.GenXDMCryptoContext;
import org.apache.jcp.crypto.genxdm.GenXDMStructure;
import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.Transform;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Node;

public abstract class ApacheCanonicalizer<N> extends TransformService {

    static {
	org.apache.xml.security.Init.init();
    }

    private static Logger log = Logger.getLogger("org.apache.jcp.xml.dsig.internal.dom");
    protected Canonicalizer apacheCanonicalizer;
    private Transform<N> apacheTransform;
    protected String inclusiveNamespaces;
    protected C14NMethodParameterSpec params;
    protected MutableModel<N> model;
    protected N ownerDoc;
    protected N transformElem;
    
    public final AlgorithmParameterSpec getParameterSpec() {
	return params;
    }

    public void init(XMLStructure parent, XMLCryptoContext context)
	throws InvalidAlgorithmParameterException {
        validateContext(context);
        membersFromStructure(parent);
    }

    private void membersFromStructure(XMLStructure parent) {
        model = GenXDMStructure.getModel(parent);
        transformElem = GenXDMStructure.getNode(model, parent);
        ownerDoc = model.getRoot(transformElem);
    }

    public void marshalParams(XMLStructure parent, XMLCryptoContext context)
	throws MarshalException {
        validateContext(context);
	    membersFromStructure(parent);
    }

    /**
     * Make sure we validate the context parameter consistently.
     * @param context
     */
    private void validateContext(XMLCryptoContext context) {
        if (context != null && !(context instanceof DOMCryptoContext) && !(context instanceof GenXDMCryptoContext)) {
            throw new ClassCastException
        	("context must be of type DOMCryptoContext or GenXDMCryptoContext");
        }
    }
    
    public Data canonicalize(Data data, XMLCryptoContext xc) 
	throws TransformException {
	return canonicalize(data, xc, null);
    }

    public Data canonicalize(Data data, XMLCryptoContext xc, OutputStream os) 
	throws TransformException {

	if (apacheCanonicalizer == null) {
	    try {
                apacheCanonicalizer = Canonicalizer.getInstance(getAlgorithm());
		if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE, "Created canonicalizer for algorithm: " 
		        + getAlgorithm());
		}
	    } catch (InvalidCanonicalizerException ice) {
                throw new TransformException
		    ("Couldn't find Canonicalizer for: " + getAlgorithm() +
			": " + ice.getMessage(), ice);
	    }
	}

	if (os != null) {
	    apacheCanonicalizer.setWriter(os);
	} else {
	    apacheCanonicalizer.setWriter(new ByteArrayOutputStream());
	}

	try {
	    Set<N> nodeSet = null;
	    if (data instanceof ApacheData) {
		XMLSignatureInput<N> in = 
		    ((ApacheData<N>) data).getXMLSignatureInput();
		if (in.isElement()) {
		    if (inclusiveNamespaces != null) {
                        return new OctetStreamData(new ByteArrayInputStream
                            (apacheCanonicalizer.canonicalizeSubtree
                                (in.getContext().mutableModel, in.getSubNodeN(), inclusiveNamespaces)));
                    } else {
                        return new OctetStreamData(new ByteArrayInputStream
                            (apacheCanonicalizer.canonicalizeSubtree
                                (in.getContext().mutableModel, in.getSubNodeN())));
                    }
                } else if (in.isNodeSet()) {
                    nodeSet = in.getNodeSet();
		} else {
		    return new OctetStreamData(new ByteArrayInputStream(
		        apacheCanonicalizer.canonicalize(
        		    Utils.readBytesFromStream(in.getOctetStream()))));
		}
	    } else if (data instanceof DOMSubTreeData) {
	        DOMSubTreeData<N> subTree = (DOMSubTreeData<N>) data;
	        if (inclusiveNamespaces != null) {
	            return new OctetStreamData(new ByteArrayInputStream
		        (apacheCanonicalizer.canonicalizeSubtree
		         (subTree.getModel(), subTree.getRoot(), inclusiveNamespaces)));
	        } else {
	            return new OctetStreamData(new ByteArrayInputStream
		        (apacheCanonicalizer.canonicalizeSubtree
		         (subTree.getModel(), subTree.getRoot())));
	        }
	    } else if (data instanceof NodeSetData) {
	        // TODO - this makes no sense to attempt to work with an unknown NodeSetData type
	        NodeSetData nsd = (NodeSetData) data;
	        // convert Iterator to Set
	        nodeSet = (Set<N>) Utils.toNodeSet(ApacheNodeSetData.getNodeSetDataIterator(nsd));
		if (log.isLoggable(Level.FINE)) {
	            log.log(Level.FINE, "Canonicalizing " + nodeSet.size() 
		        + " nodes");
		}
            } else {
		return new OctetStreamData(new ByteArrayInputStream(
		    apacheCanonicalizer.canonicalize(
        		Utils.readBytesFromStream(
        		((OctetStreamData)data).getOctetStream()))));
	    }
	    if (inclusiveNamespaces != null) {
	        return new OctetStreamData(new ByteArrayInputStream(
                    canonicalizeXpathNodeSet(model, nodeSet)));
	    } else {
	        return new OctetStreamData(new ByteArrayInputStream(
                    apacheCanonicalizer.canonicalizeXPathNodeSet(
                    		model, nodeSet)));
	    }
	} catch (Exception e) {
            throw new TransformException(e);
	}
    }

	private byte[] canonicalizeXpathNodeSet(MutableModel<N> model, Set<N> nodeSet)
			throws CanonicalizationException {
		return apacheCanonicalizer.canonicalizeXPathNodeSet
      (model, nodeSet, inclusiveNamespaces);
	}

    public Data transform(Data data, XMLCryptoContext xc, OutputStream os)
        throws TransformException {
	if (data == null) {
	    throw new NullPointerException("data must not be null");
	}
	if (os == null) {
	    throw new NullPointerException("output stream must not be null");
	}

        if (ownerDoc == null) {
            throw new TransformException("transform must be marshalled");
        }

        if (apacheTransform == null) {
            try {
                apacheTransform = Transform.getInstance
                    (model, ownerDoc, getAlgorithm(), model.getChildAxis(transformElem));
                apacheTransform.setElementNode(transformElem, xc.getBaseURI());
		if (log.isLoggable(Level.FINE)) {
                    log.log(Level.FINE, "Created transform for algorithm: " 
		        + getAlgorithm());            
		}
	    } catch (Exception ex) {
                throw new TransformException
                    ("Couldn't find Transform for: " + getAlgorithm(), ex);
            }
        }

        XMLSignatureInput<N> in;
        if (data instanceof ApacheData) {
	    if (log.isLoggable(Level.FINE)) {
                log.log(Level.FINE, "ApacheData = true");
	    }
            in = ((ApacheData<N>) data).getXMLSignatureInput();
        } else if (data instanceof NodeSetData) {
	    if (log.isLoggable(Level.FINE)) {
                log.log(Level.FINE, "isNodeSet() = true");
	    }
            if (data instanceof DOMSubTreeData) {
                DOMSubTreeData<N> subTree = (DOMSubTreeData<N>) data;
                XmlContext<N> xmlCtx = new XmlContext<N>(subTree.getDocumentHandlerFactory(), subTree.getModel());
                in = new XMLSignatureInput<N>(xmlCtx, subTree.getRoot());
		in.setExcludeComments(subTree.excludeComments());
            } else {
                // TODO - the following is a folly to assume that it is a NodeSetData that holds DOM,
                // but that's how the official project does it.
                Set<Node> nodeSet =
                    Utils.toNodeSet(ApacheNodeSetData.getNodeSetDataIterator((NodeSetData) data));
                in = (XMLSignatureInput<N>) new XMLSignatureInput<Node>(XmlContext.getContext(), nodeSet);
            }
        } else {
	    if (log.isLoggable(Level.FINE)) {
                log.log(Level.FINE, "isNodeSet() = false");
	    }
            try {
                DocumentHandlerFactory<N> docFactory = GenXDMCryptoContext.getDocumentHandlerFactory(xc);
                XmlContext<N> xmlCtx = new XmlContext<N>(docFactory, model);
                in = new XMLSignatureInput<N>
                    (xmlCtx, ((OctetStreamData)data).getOctetStream());
            } catch (Exception ex) {
                throw new TransformException(ex);
            }
        }

        try {
            in = apacheTransform.performTransform(in, os);
	    if (!in.isNodeSet() && !in.isElement()) {
	        return null;
	    }
	    if (in.isOctetStream()) {
                return new ApacheOctetStreamData<N>(in);
	    } else {
                return new ApacheNodeSetData<N>(in);
	    }
        } catch (Exception ex) {
            throw new TransformException(ex);
        }
    }

    public final boolean isFeatureSupported(String feature) {
        if (feature == null) {
            throw new NullPointerException();
        } else {
            return false;
        }
    }
}
