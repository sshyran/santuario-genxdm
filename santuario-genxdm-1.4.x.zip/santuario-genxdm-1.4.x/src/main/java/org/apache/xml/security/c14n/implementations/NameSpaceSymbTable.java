/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.c14n.implementations;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.w3c.dom.Attr;


/**
 * A stack based Symbol Table.
 *<br>For speed reasons all the symbols are introduced in the same map,
 * and at the same time in a list so it can be removed when the frame is pop back.
 * @author Raul Benito
 **/
public class NameSpaceSymbTable<N> {
	
	/**The map between prefix-> entry table. */
	SymbMap<N> symb;
	/**The level of nameSpaces (for Inclusive visibility).*/
	int nameSpaces=0;
	/**The stacks for removing the definitions when doing pop.*/
	List<SymbMap<N>> level;
    boolean cloned=true;	
	static final String XMLNS="xmlns";
	
    /**
     * Default constructor
     **/		
    public NameSpaceSymbTable() {    	
    	level = new ArrayList<SymbMap<N>>(10);
    	//Insert the default binding for xmlns.
    	symb = new SymbMap<N>();
    	NameSpaceSymbEntry<N> defaultEntry = new NameSpaceSymbEntry<N>("", null, true, XMLNS);
    	defaultEntry.lastrendered = "";
    	symb.put("", defaultEntry);
    }
    
    /**
	 * Get all the unrendered nodes in the name space.
	 * For Inclusive rendering
	 * 
	 * <p>Note that clients almost certainly want to use {@link #getUnrenderedNodeWrappers(Collection)}.
	 * This method might return a <code>null</code> result to signify the need
	 * to declare the default namespace.
     * @param result the list where to fill the unrendered xmlns definitions.
     *
     * @deprecated New clients should use {@link #getUnrenderedNodeWrappers(Collection)}
	 **/       
	public  void getUnrenderedNodes(Collection< Object > result) {
		
		List<AttrInfo> wraps = new ArrayList<AttrInfo>();
		getUnrenderedNodeWrappers(wraps);
		
		for (AttrInfo wrap : wraps) {
			result.add(wrap.getWrappedNode());
		}
	}
	
    /**
	 * Get all the unrendered nodes in the name space.
	 * For Inclusive rendering
     * @param result the list where to fill the unrendered xmlns definitions.
	 **/       
	public  void getUnrenderedNodeWrappers(Collection<AttrInfo > result) {		
	   //List result=new ArrayList();
	   Iterator<NameSpaceSymbEntry<N> > it=symb.entrySet().iterator();
	   while (it.hasNext()) {	   	   
	   		NameSpaceSymbEntry<N> n= it.next();
	   		//put them rendered?
	   		if ((!n.rendered) && (n.n!=null)) {
	   			n = cloneNameSpaceSymbEntry(n);
                needsClone();
                symb.put(n.prefix,n);         
                n.lastrendered=n.uri;
                n.rendered=true;
                
	   			result.add(n.n);
	   			
	   		}
	   }	   
	}
	
	/**
     * Push a frame for visible namespace. 
     * For Inclusive rendering.
     **/
	public void outputNodePush() {
		nameSpaces++;
		push();
	}
	
	/**
     * Pop a frame for visible namespace.
     **/
	public void outputNodePop() {
		nameSpaces--;
		pop();
	}
	
	/**
     * Push a frame for a node.
     * Inclusive or Exclusive.
     **/
	public void push() {		
		//Put the number of namespace definitions in the stack.
        level.add(null);
        cloned=false;
	}
	
	/**
     * Pop a frame.
     * Inclusive or Exclusive.
     **/
	public void pop() {
        int size=level.size()-1;
        SymbMap<N> ob = level.remove(size);
        if (ob!=null) {
        	symb= ob;
            if (size==0) {
               cloned=false;   
            } else
            	cloned=(level.get(size-1)!=symb);
        } else {
        	cloned=false;
        }
        
        
	}
	
	final void needsClone() {
		if (!cloned) {			
            level.set(level.size()-1,symb);
			symb = symb.clone();
            cloned=true;
        }
    }

	/**
	 * Gets the attribute node that defines the binding for the prefix.      
     * @param prefix the prefix to obtain the attribute.
     * @return null if there is no need to render the prefix. Otherwise the node of
     * definition.
     * 
     * @deprecated New clients should use {@link #getMappingWrap(String)}
     **/
	public Attr getMapping(String prefix) {
		AttrInfo wrap = getMappingWrap(prefix);
		return wrap != null ? wrap.getAttr() : null;
	}

	/**
	 * Gets the attribute node that defines the binding for the prefix.      
     * @param prefix the prefix to obtain the attribute.
     * @return null if there is no need to render the prefix. Otherwise the node of
     * definition.
     **/
	public AttrInfo getMappingWrap(String prefix) {					
		NameSpaceSymbEntry<N> entry=symb.get(prefix);
		if (entry==null) {
			//There is no definition for the prefix(a bug?).
			return null;
		}
		if (entry.rendered) {		
			//No need to render an entry already rendered.
			return null;		
		}
		// Mark this entry as render.
        entry = cloneNameSpaceSymbEntry(entry);
        needsClone();
        symb.put(prefix,entry);
		entry.rendered=true;
		entry.level=nameSpaces;
		entry.lastrendered=entry.uri;				
		// Return the node for outputing.
		return entry.n;
	}

	@SuppressWarnings("unchecked")
	private NameSpaceSymbEntry<N> cloneNameSpaceSymbEntry(
			NameSpaceSymbEntry<N> entry) {
		return (NameSpaceSymbEntry<N>) entry.clone();
	}
	
	/**
     * Gets a definition without mark it as render. 
     * For render in exclusive c14n the namespaces in the include prefixes.
     * @param prefix The prefix whose definition is neaded.
     * @return the attr to render, null if there is no need to render
     **/
	public AttrInfo getMappingWithoutRendered(String prefix) {					
		NameSpaceSymbEntry<N> entry= symb.get(prefix);
		if (entry==null) {		   
			return null;
		}
		if (entry.rendered) {		
			return null;		
		}
		return entry.n;
	}
	
	/**
	 * 
	 * @param prefix
	 * @param uri
	 * @param n
	 * @return
	 * 
	 * @deprecated New clients should use {@link #addMapping(Model, String, String, Object)
	 */
	@SuppressWarnings("unchecked")
	public boolean addMapping( String prefix, String uri, Attr n) {
		return addMapping((Model<N>) XmlContext.getDomModel(), prefix, uri, (N) n);
	}
	
	/**
     * Adds the mapping for a prefix.
     * @param prefix the prefix of definition
     * @param uri the Uri of the definition
     * @param n the attribute that have the definition
     * @return true if there is already defined.
     **/
	public boolean addMapping(Model<N> model, String prefix, String uri, N n) {						
		NameSpaceSymbEntry<N> ob = symb.get(prefix);		
		if ((ob!=null) && uri.equals(ob.uri)) {
			//If we have it previously defined. Don't keep working.
			return false;
		}			
		//Creates and entry in the table for this new definition.
		NameSpaceSymbEntry<N> ne=new NameSpaceSymbEntry<N>(uri, AttrInfo.createNamespace(n, prefix, uri),false,prefix);		
        needsClone();
		symb.put(prefix, ne);
		if (ob != null) {
			//We have a previous definition store it for the pop.			
			//Check if a previous definition(not the inmidiatly one) has been rendered.			
			ne.lastrendered=ob.lastrendered;			
			if ((ob.lastrendered!=null)&& (ob.lastrendered.equals(uri))) {
				//Yes it is. Mark as rendered.
				ne.rendered=true;
			}			
		} 			
        return true;
	}

    /**
     * Adds a definition and mark it as render.
     * For inclusive c14n.
     * @param prefix the prefix of definition
     * @param uri the Uri of the definition
     * @param attr the attribute that have the definition
     * @return the attr to render, null if there is no need to render
     * 
     * @deprecated Only for use with old DOM compatible APIs.  New clients should
     * be using {@link #addMappingAndRenderAttr(String, String, Object)}
     **/
    @SuppressWarnings("unchecked")
	public Attr addMappingAndRender(String prefix, String uri, Attr attr) {
    	
    	AttrInfo wrapper = addMappingAndRenderAttr((Model<N>) XmlContext.getDomModel(), prefix, uri, (N) attr); 
    	return wrapper != null ? wrapper.getAttr() : null;
    }

    /**
     * Adds a definition and mark it as render.
     * For inclusive c14n.
     * @param prefix the prefix of definition
     * @param uri the Uri of the definition
     * @param attr the attribute that have the definition
     * @return the attr to render, null if there is no need to render
     **/
    public AttrInfo addMappingAndRenderAttr(Model<N> model, String prefix, String uri, N attr) {
    	
        NameSpaceSymbEntry<N> ob = symb.get(prefix);
        
        if ((ob!=null) && uri.equals(ob.uri)) {
            if (!ob.rendered) {                 
                ob = cloneNameSpaceSymbEntry(ob);
                needsClone();
                symb.put(prefix,ob);         
                ob.lastrendered=uri;
                ob.rendered=true;
                return ob.n;
            }           
            return null;
        }   
        
        NameSpaceSymbEntry<N> ne=new NameSpaceSymbEntry<N>(uri, AttrInfo.createAttribute(model, attr),true,prefix);
        ne.lastrendered=uri;
        needsClone();
        symb.put(prefix, ne);
        if (ob != null) {           
            
            if ((ob.lastrendered!=null)&& (ob.lastrendered.equals(uri))) {
                ne.rendered=true;
                return null;
            }
        }       
        return ne.n;
    }

	public int getLevel() {
		return level.size();
	}

	public void removeMapping(String prefix) {
		NameSpaceSymbEntry<N> ob = symb.get(prefix);
        
        if (ob!=null) {
            needsClone();
            symb.put(prefix,null);         
        }
	}

	public void removeMappingIfNotRender(String prefix) {
		NameSpaceSymbEntry<N> ob = symb.get(prefix);
        
        if (ob!=null && !ob.rendered) {
            needsClone();
            symb.put(prefix,null);         
        }
	}

	public boolean removeMappingIfRender(String prefix) {
		NameSpaceSymbEntry<N> ob = symb.get(prefix);
        
        if (ob!=null && ob.rendered) {
            needsClone();
            symb.put(prefix,null);         
        }
        return false;
	}
}

/**
 * The internal structure of NameSpaceSymbTable.
 **/
class NameSpaceSymbEntry<N> implements Cloneable {
    NameSpaceSymbEntry(String name,AttrInfo n,boolean rendered,String prefix) {
        this.uri=name;          
        this.rendered=rendered;
        this.n=n;            
        this.prefix=prefix;
    }
    /** @inheritDoc */
    public Object clone() {         
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
    /** the level where the definition was rendered(Only for inclusive) */
    int level=0;
    String prefix;
    /**The URI that the prefix defines */
    String uri;
    /**The last output in the URI for this prefix (This for speed reason).*/
    String lastrendered=null;
    /**This prefix-URI has been already render or not.*/
    boolean rendered=false;
    
    /**The attribute to include.*/
    AttrInfo n;        
};

// TODO - EEJ - why is there code for a custom Map class that doesn't implement the Map
// interface?
class SymbMap<N> implements Cloneable {
    int free=23;
    NameSpaceSymbEntry<N>[] entries;
    String[] keys;
	SymbMap() {
		entries=createNewEntriesArray(free);
		keys=new String[free];
	}
	
	@SuppressWarnings("unchecked")
	private NameSpaceSymbEntry<N>[] createNewEntriesArray(int capacity) {
		return new NameSpaceSymbEntry[capacity];
	}
    void put(String key, NameSpaceSymbEntry<N> value) {		
        int index = index(key);
        Object oldKey = keys[index];
        keys[index] = key;
        entries[index] = value;
        if (oldKey==null || !oldKey.equals(key)) {	        	        
            if (--free == 0) {
            	free=entries.length;
            	int newCapacity = free<<2;				
            	rehash(newCapacity);			
            }
        }
    }
	
    List<NameSpaceSymbEntry<N> > entrySet() {
    	List<NameSpaceSymbEntry<N>> a=new ArrayList<NameSpaceSymbEntry<N> >();
    	for (int i=0;i<entries.length;i++) {
    		if ((entries[i]!=null) && !("".equals(entries[i].uri))) {
    			a.add(entries[i]);
	    }
    	}
    	return a;		
    }

    protected int index(Object obj) {		
        Object[] set = keys;
        int length = set.length;
        //abs of index
        int index = (obj.hashCode() & 0x7fffffff) %  length;
        Object cur = set[index];

        if (cur == null || (cur.equals( obj))) {
        	return index;
        }
        length=length-1;
        do {
        	index=index==length? 0:++index;
        	cur = set[index];
        } while (cur != null && (!cur.equals(obj)));       
        return index;
    }

    /**
     * rehashes the map to the new capacity.
     *
     * @param newCapacity an <code>int</code> value
     */
    protected void rehash(int newCapacity) {
        int oldCapacity = keys.length;
        String oldKeys[] = keys;
        NameSpaceSymbEntry<N> oldVals[] = entries;

        keys = new String[newCapacity];        
        entries = createNewEntriesArray(newCapacity);

        for (int i = oldCapacity; i-- > 0;) {
            if(oldKeys[i] != null) {
                String o = oldKeys[i];
                int index = index(o);
                keys[index] = o;
                entries[index] = oldVals[i];
            }
        }
    }

    NameSpaceSymbEntry<N> get(String key) {
        return  entries[index(key)];
    }

    protected SymbMap<N> clone()  {
    	try {
   			SymbMap<N> copy=invokeSuperClone();
    		copy.entries=createNewEntriesArray(entries.length);
    		System.arraycopy(entries,0,copy.entries,0,entries.length);
    		copy.keys=new String[keys.length];
    		System.arraycopy(keys,0,copy.keys,0,keys.length);
			
    		return copy;
	} catch (CloneNotSupportedException e) {
		// exception not expected.
	    e.printStackTrace();
	}
	return null;
    }

	@SuppressWarnings("unchecked")
	private SymbMap<N> invokeSuperClone() throws CloneNotSupportedException {
		return (SymbMap<N>) super.clone();
	}
}
