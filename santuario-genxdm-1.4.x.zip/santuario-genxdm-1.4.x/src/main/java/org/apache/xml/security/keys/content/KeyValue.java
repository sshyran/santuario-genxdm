/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.keys.content;

import java.security.PublicKey;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
import org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * The KeyValue element contains a single public key that may be useful in
 * validating the signature. Structured formats for defining DSA (REQUIRED)
 * and RSA (RECOMMENDED) public keys are defined in Signature Algorithms
 * (section 6.4). The KeyValue element may include externally defined public
 * keys values represented as PCDATA or element types from an external 
 * namespace.
 *
 * @author $Author: mullan $
 */
public class KeyValue<N> extends SignatureElementProxy<N> implements KeyInfoContent {

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param dsaKeyValue
     * 
     * @deprecated New clients should use {@link #KeyValue(XmlContext, Object, DSAKeyValue)}
     */
    @SuppressWarnings("unchecked")
	public KeyValue(Document doc, @SuppressWarnings("rawtypes") DSAKeyValue dsaKeyValue) {
    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, dsaKeyValue);
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param dsaKeyValue
     */
    public KeyValue(MutableModel<N> model, N doc, DSAKeyValue<N> dsaKeyValue) {

    	super(model, doc);

    	addReturnToSelf();
    	appendSelf(dsaKeyValue.getElementNode());
    	addReturnToSelf();
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param rsaKeyValue
     * 
     * @deprecated New clients should use {@link #KeyValue(XmlContext, Object, RSAKeyValue)}
     */
    @SuppressWarnings("unchecked")
	public KeyValue(Document doc, @SuppressWarnings("rawtypes") RSAKeyValue rsaKeyValue) {
    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, rsaKeyValue);
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param rsaKeyValue
     */
    public KeyValue(MutableModel<N> model, N doc, RSAKeyValue<N> rsaKeyValue) {

    	super(model, doc);

    	addReturnToSelf();
    	appendSelf(rsaKeyValue.getElementNode());
    	addReturnToSelf();
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param unknownKeyValue
     * 
     * @deprecated New clients should use {@link #KeyValue(XmlContext, Object, Object)}
     */
    @SuppressWarnings("unchecked")
	public KeyValue(Document doc, Element unknownKeyValue) {

    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, (N) unknownKeyValue);
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param unknownKeyValue
     */
    public KeyValue(MutableModel<N> model, N doc, N unknownKeyValue) {

        super(model, doc);

    	addReturnToSelf();
    	model.appendChild(getElementNode(), unknownKeyValue);
    	addReturnToSelf();
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param pk
     * 
     * @deprecated New clients should use {@link #KeyValue(XmlContext, Object, PublicKey)}
     */
    @SuppressWarnings("unchecked")
	public KeyValue(Document doc, PublicKey pk) {

    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, pk);
    }

    /**
     * Constructor KeyValue
     *
     * @param doc
     * @param pk
     */
    public KeyValue(MutableModel<N> model, N doc, PublicKey pk) {

        super(model, doc);

        addReturnToSelf();

        if (pk instanceof java.security.interfaces.DSAPublicKey) {
            DSAKeyValue<N> dsa = new DSAKeyValue<N>(model, getDocumentNode(), pk);
            appendSelf(dsa.getElementNode());
        	addReturnToSelf();
        } else if (pk instanceof java.security.interfaces.RSAPublicKey) {
            RSAKeyValue<N> rsa = new RSAKeyValue<N>(model, getDocumentNode(), pk);
            appendSelf(rsa.getElementNode());
        	addReturnToSelf();
        }
    }

    /**
     * Constructor KeyValue
     *
     * @param element
     * @param BaseURI
     * @throws XMLSecurityException
     * 
     * @deprecated New clients should use {@link #KeyValue(XmlContext, Object, String)}
     */
    @SuppressWarnings("unchecked")
	public KeyValue(Element element, String BaseURI)
           throws XMLSecurityException {
    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) element, BaseURI);
    }

    /**
     * Constructor KeyValue
     *
     * @param element
     * @param BaseURI
     * @throws XMLSecurityException
     */
    public KeyValue(MutableModel<N> model, N element, String BaseURI)
           throws XMLSecurityException {
        super(model, element, BaseURI);
    }

    /**
     * Method getPublicKey
     *
     * @return the public key
     * @throws XMLSecurityException
     */
    public PublicKey getPublicKey() throws XMLSecurityException {

    	N rsa = _model.getFirstChildElementByName(getElementNode(),
    			Constants.SignatureSpecNS, Constants._TAG_RSAKEYVALUE);
	 		     
		if (rsa != null) {
	            RSAKeyValue<N> kv = new RSAKeyValue<N>(_model, rsa, this._baseURI);
	            return kv.getPublicKey();
		}

		N dsa = _model.getFirstChildElementByName(getElementNode(),
				Constants.SignatureSpecNS, Constants._TAG_DSAKEYVALUE);
		
		if (dsa != null) {
	            DSAKeyValue<N> kv = new DSAKeyValue<N>(_model, dsa, this._baseURI);
	            return kv.getPublicKey();
		}
	
		return null;
    }

    /** @inheritDoc */
    public String getBaseLocalName() {
        return Constants._TAG_KEYVALUE;
    }
}
