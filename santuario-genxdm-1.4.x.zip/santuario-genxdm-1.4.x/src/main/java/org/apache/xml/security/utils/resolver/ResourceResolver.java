/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.utils.resolver;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.w3c.dom.Attr;
import org.w3c.dom.Node;

/**
 * During reference validation, we have to retrieve resources from somewhere.
 * This is done by retrieving a Resolver. The resolver needs two arguments: The
 * URI in which the link to the new resource is defined and the BaseURI of the
 * file/entity in which the URI occurs (the BaseURI is the same as the SystemId.
 *
 * <UL xml:lang="DE" LANG="DE">
 * <LI> Verschiedene Implementierungen k??nnen sich als Resolver registrieren.
 * <LI> Standardm????ig werden erste Implementierungen auf dem XML config file registrirt.
 * <LI> Der Benutzer kann bei Bedarf Implementierungen voranstellen oder anf??gen.
 * <LI> Implementierungen k??nnen mittels Features customized werden ??
 *      (z.B. um Proxy-Passworter ??bergeben zu k??nnen).
 * <LI> Jede Implementierung bekommt das URI Attribut und den Base URI
 *      ??bergeben und muss antworten, ob sie aufl??sen kann.
 * <LI> Die erste Implementierung, die die Aufgabe erf??llt, f??hrt die Aufl??sung durch.
 * </UL>
 *
 * @author $Author: coheigea $
 */
public class ResourceResolver {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(ResourceResolver.class.getName());

   /** these are the system-wide resolvers */
   private static ArrayList<ResourceResolver> _resolverVector = new ArrayList<ResourceResolver>(10);
   
   private static boolean allThreadSafeInList=true;

   /** Field transformSpi */
   protected ResourceResolverSpi _resolverSpi = null;

   /**
    * Constructor ResourceResolver
    *
    * @param className
    * @throws ClassNotFoundException
    * @throws IllegalAccessException
    * @throws InstantiationException
    */
   private ResourceResolver(String className)
           throws ClassNotFoundException, IllegalAccessException,
                  InstantiationException {
      this._resolverSpi =
         (ResourceResolverSpi) Class.forName(className).newInstance();
   }

   /**
    * Constructor ResourceResolver
    *
    * @param resourceResolver
    */
   public ResourceResolver(ResourceResolverSpi resourceResolver) {
      this._resolverSpi = resourceResolver;
   }

   
   /**
    * Method getInstance
    *
    * @param uri
    * @param BaseURI
    * @return the instnace
    *
    * @throws ResourceResolverException
    */
   public static final <N> ResourceResolver getInstance(Model<N> model, N uriAttr, String BaseURI)
           throws ResourceResolverException {
      int length=ResourceResolver._resolverVector.size();
      for (int i = 0; i < length; i++) {
		  ResourceResolver resolver = ResourceResolver._resolverVector.get(i);
		  ResourceResolver resolverTmp=null;
		  try {
			resolverTmp =  allThreadSafeInList || resolver._resolverSpi.engineIsThreadSafe() ? resolver : 
				  	new ResourceResolver((ResourceResolverSpi)resolver._resolverSpi.getClass().newInstance());
		  } catch (InstantiationException e) {
			  throw new ResourceResolverException("",e, getSafeAttrValue(model, uriAttr), BaseURI);
		  } catch (IllegalAccessException e) {
			  throw new ResourceResolverException("",e, getSafeAttrValue(model, uriAttr), BaseURI);			
		  }

         if (log.isDebugEnabled())
         	log.debug("check resolvability by class " + resolver._resolverSpi.getClass().getName());

         if ((resolver != null) && resolverTmp.canResolve(model, uriAttr, BaseURI)) {
            return resolverTmp;
         }
      }

      Object exArgs[] = { ((uriAttr != null)
                           ? getSafeAttrValue(model, uriAttr) : "null"), BaseURI };

      throw new ResourceResolverException("utils.resolver.noClass", exArgs,
                                          getSafeAttrValue(model, uriAttr), BaseURI);
   }

   private static <N> String getSafeAttrValue(Model<N> model, N attr) {
	   return attr != null ? model.getStringValue(attr) : null;
   }
   
   /**
    * Method getInstance
    *
    * @param uri
    * @param BaseURI
    * @return the instnace
    *
    * @throws ResourceResolverException
    * 
    * @deprecated	New clients should use {@link #getInstance(Model, Object, String)}
    */
   public static final ResourceResolver getInstance(Attr uri, String BaseURI)
           throws ResourceResolverException {
	   return getInstance(XmlContext.getDomModel(), uri, BaseURI);
	   
   }

   /**
    * Method getInstance
    *
    * @param uri
    * @param BaseURI
    * @param individualResolvers
    * @return the instance
    *
    * @throws ResourceResolverException
    */
   public static final <N> ResourceResolver getInstance(
           Model<N> model, N uriAttr, String BaseURI, List<ResourceResolver> individualResolvers)
              throws ResourceResolverException {
      if (log.isDebugEnabled()) {
    	  
      	log.debug("I was asked to create a ResourceResolver and got " + (individualResolvers==null? 0 : individualResolvers.size()) );
      	log.debug(" extra resolvers to my existing " + ResourceResolver._resolverVector.size() + " system-wide resolvers");
      }

      // first check the individual Resolvers
	  int size=0;
      if ((individualResolvers != null) && ((size=individualResolvers.size()) > 0)) {
         for (int i = 0; i < size; i++) {
            ResourceResolver resolver = individualResolvers.get(i);

            if (resolver != null) {
               String currentClass = resolver._resolverSpi.getClass().getName();
               if (log.isDebugEnabled())
               	log.debug("check resolvability by class " + currentClass);

               if (resolver.canResolve(model, uriAttr, BaseURI)) {
                  return resolver;
               }
            }
         }
      }

	  return getInstance(model, uriAttr ,BaseURI);
   }

   /**
    * Method getInstance
    *
    * @param uri
    * @param BaseURI
    * @param individualResolvers
    * @return the instance
    *
    * @throws ResourceResolverException
    * 
    * @deprecated Use {@link #getInstance(Model, Object, String, List)} instead.
    */
   public static final ResourceResolver getInstance(
           Attr uri, String BaseURI, List<ResourceResolver> individualResolvers)
              throws ResourceResolverException {
	   
	   return getInstance(XmlContext.getDomModel(), uri, BaseURI, individualResolvers);
   }

   /**
    * The init() function is called by org.apache.xml.security.Init.init()
    */
   public static void init() {
   }

    /**
     * Registers a ResourceResolverSpi class. This method logs a warning if
     * the class cannot be registered.
     *
     * @param className the name of the ResourceResolverSpi class to be 
     *    registered
     */
    public static void register(String className) {
 	register(className, false);
    }

    /**
     * Registers a ResourceResolverSpi class at the beginning of the provider
     * list. This method logs a warning if the class cannot be registered.
     *
     * @param className the name of the ResourceResolverSpi class to be 
     *    registered
     */
    public static void registerAtStart(String className) {
	register(className, true);
    }

    private static void register(String className, boolean start) {
        try {
            ResourceResolver resolver = new ResourceResolver(className);
	    if (start) {
	        ResourceResolver._resolverVector.add(0, resolver);
	        log.debug("registered resolver");
	    } else {	       
	        ResourceResolver._resolverVector.add(resolver);
	    }
	    if (!resolver._resolverSpi.engineIsThreadSafe()) {
        	allThreadSafeInList=false; 
        }
        } catch (Exception e) {
	    log.warn("Error loading resolver " + className +" disabling it");
        } catch (NoClassDefFoundError e) {
	    log.warn("Error loading resolver " + className +" disabling it");
        }
    }

   /**
    * Method resolve
    *
    * @param uri
    * @param BaseURI
    * @return the resource
    *
    * @throws ResourceResolverException
    */
   public static XMLSignatureInput<Node> resolveStatic(Attr uri, String BaseURI)
           throws ResourceResolverException {

      ResourceResolver myResolver = ResourceResolver.getInstance(XmlContext.getDomModel(), uri, BaseURI);

      return myResolver.resolve(uri, BaseURI);
   }

   /**
    * Method resolve
    *
    * @param uri
    * @param BaseURI
    * @return the resource
    *
    * @throws ResourceResolverException
    */
   public <N> XMLSignatureInput<N> resolve(XmlContext<N> ctx, N uriAttr, String BaseURI)
           throws ResourceResolverException {
      return this._resolverSpi.engineResolveURI(ctx, uriAttr, BaseURI);
   }

   /**
    * Method resolve
    *
    * @param uri
    * @param BaseURI
    * @return the resource
    *
    * @throws ResourceResolverException
    * 
    * @deprecated Use {@link #resolve(XmlContext, Object, String)} instead.
    */
   public XMLSignatureInput<Node> resolve(Attr uri, String BaseURI)
           throws ResourceResolverException {
	   return this.resolve( XmlContext.getContext(), uri, BaseURI);
   }

   /**
    * Method setProperty
    *
    * @param key
    * @param value
    */
   public void setProperty(String key, String value) {
      this._resolverSpi.engineSetProperty(key, value);
   }

   /**
    * Method getProperty
    *
    * @param key
    * @return the value of the property
    */
   public String getProperty(String key) {
      return this._resolverSpi.engineGetProperty(key);
   }

   /**
    * Method addProperties
    *
    * @param properties
    */
   public void addProperties(Map<String, String> properties) {
      this._resolverSpi.engineAddProperies(properties);
   }

   /**
    * Method getPropertyKeys
    *
    * @return all property keys.
    */
   public String[] getPropertyKeys() {
      return this._resolverSpi.engineGetPropertyKeys();
   }

   /**
    * Method understandsProperty
    *
    * @param propertyToTest
    * @return true if the resolver understands the property
    */
   public boolean understandsProperty(String propertyToTest) {
      return this._resolverSpi.understandsProperty(propertyToTest);
   }

   /**
    * Method canResolve
    *
    * @param uri
    * @param BaseURI
    * @return true if it can resolve the uri
    */
   private <N> boolean canResolve(Model<N> model, N uriAttr, String BaseURI) {
      return this._resolverSpi.engineCanResolveURI(model, uriAttr, BaseURI);
   }

}
