package org.apache.xml.security.transforms.implementations;

import java.util.Collection;

import javax.xml.namespace.QName;

import org.genxdm.Model;
import org.genxdm.processor.xpath.v10.XPathToolkitFactoryImpl;
import org.genxdm.xpath.v10.ExprContextDynamic;
import org.genxdm.xpath.v10.ExprContextDynamicArgs;
import org.genxdm.xpath.v10.ExprContextStatic;
import org.genxdm.xpath.v10.ExprException;
import org.genxdm.xpath.v10.ExprParseException;
import org.genxdm.xpath.v10.NodeIterator;
import org.genxdm.xpath.v10.NodeSetExpr;
import org.genxdm.xpath.v10.Variant;
import org.genxdm.xpath.v10.XPathToolkit;
import org.genxdm.xpath.v10.extend.Function;
import org.genxdm.xpath.v10.extend.ConvertibleExpr;
import org.genxdm.xpath.v10.extend.XPathExtendToolkit;
import org.genxdm.xpath.v10.extend.XPathExtendToolkitFactory;


public class XPathHelper {

	static class HereExpression implements NodeSetExpr {
		
		public <N> NodeIterator<N> nodeIterator(Model<N> model, N contextNode,
				ExprContextDynamic<N> dynEnv) throws ExprException {
			
			NodeVariant<N> hereValue = (NodeVariant<N>) dynEnv.getVariableValue(HERE_VARIABLE);
			return new SingleNodeIterator<N>(hereValue.getNode());
		}
		
	}

	/**
	 * The "here()" function returns an "expression" which does the work of
	 * performing the XPath operation. 
	 */
	static class HereFunction implements Function {
	
		public HereFunction(XPathExtendToolkit toolkit) {
			m_toolkit = toolkit;
		}
		
		public ConvertibleExpr makeCallExpr(ConvertibleExpr[] args,
				ExprContextStatic statEnv) throws ExprParseException {
			
			return m_toolkit.wrapNodeSetExpr(hereExpression, 0);
		}
		
		private XPathExtendToolkit m_toolkit;
		
		private NodeSetExpr hereExpression = new HereExpression(); 
	}

	public static QName HERE_VARIABLE =
		new QName("http://implementations.transforms.security.xml.apache.org", "hereState");
	
	static class NodeVariant<N> implements Variant<N> {

		public NodeVariant(N node) {
			m_node = node;
		}
		
		public N getNode() {
			return m_node;
		}
		
		@Override
		public boolean convertToBoolean() throws ExprException {
			return false;
		}

		@Override
		public NodeIterator<N> convertToNodeSet() throws ExprException {
			return null;
		}

		@Override
		public double convertToNumber() throws ExprException {
			return 0;
		}

		@Override
		public boolean convertToPredicate(ExprContextDynamic<N> context)
				throws ExprException {
			return false;
		}

		@Override
		public String convertToString() throws ExprException {
			return null;
		}

		@Override
		public boolean isBoolean() {
			return false;
		}

		@Override
		public boolean isNodeSet() {
			return true;
		}

		@Override
		public boolean isNumber() {
			return false;
		}

		@Override
		public boolean isString() {
			return false;
		}

		@Override
		public Variant<N> makePermanent() throws ExprException {
			return null;
		}
		
		private N m_node;
		
	}

	private static class SingleNodeIterator<N> implements NodeIterator<N> {

		public SingleNodeIterator(N node) {
			m_node = node;
		}
		
		@Override
		public N next() throws ExprException {
			N result = m_node;
			m_node = null;
			return result;
		}
		
		private N m_node;
		
	}
	
	public static <N> void bindHereNode(Model<N> model, N node, ExprContextDynamicArgs<N> dynArgs) {
		Variant<N> nodeVariant = new NodeVariant<N>(node);
		dynArgs.bindVariableValue(XPathHelper.HERE_VARIABLE, nodeVariant);
	}
	
	public static XPathToolkit getXPathToolkitWithHereFunction() {
		return sm_xpathToolkit;
	}

	private static XPathExtendToolkit sm_xpathToolkit;

    static {
		XPathExtendToolkitFactory factory = new XPathToolkitFactoryImpl();
		sm_xpathToolkit = factory.newXPathToolkit();
		sm_xpathToolkit.declareFunction( "here", new HereFunction(sm_xpathToolkit) );
		
    }

	public static <N> void declareNamespacesFromContextNode(Model<N> model, N xpathElement,
			ExprContextStatic staticArgs) {
		for (N nsn : model.getNamespaceAxis(xpathElement, true)) {
			staticArgs.declareNamespace(model.getLocalName(nsn), model.getStringValue(nsn) );
		}
	}

	public static <N, C extends Collection<N>> C nodeIteratorIntoCollection(
			NodeIterator<N> nodeIter, C nodeSet) throws ExprException {
		for (N aNode = nodeIter.next() ; aNode != null ; aNode = nodeIter.next() ) {
			nodeSet.add(aNode);
		}
		return nodeSet;
	}
}
