
/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.utils.resolver;


import java.util.HashMap;
import java.util.Map;

import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.w3c.dom.Attr;

/**
 * During reference validation, we have to retrieve resources from somewhere.
 *
 * @author $Author: raul $
 */
public abstract class ResourceResolverSpi {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(
                    ResourceResolverSpi.class.getName());

   /** Field _properties */
   protected Map<String, String> _properties = null;

   /**
    * This is the workhorse method used to resolve resources.
    *
    * @param uri
    * @param BaseURI
    * @return the resource wrapped arround a XMLSignatureInput
    *
    * @throws ResourceResolverException
    * 
    * @deprecated New clients should override {@link #engineResolveURI(XmlContext, Object, String)}
    */
   public <N> XMLSignatureInput<N> engineResolve(Attr uri, String BaseURI)
      throws ResourceResolverException {
	   throw new UnsupportedOperationException();
   }

   /**
    * This is the workhorse method used to resolve resources.
    *
    * @param uri
    * @param BaseURI
    * @return the resource wrapped arround a XMLSignatureInput
 * @throws ResourceResolverException 
    *
    * @throws ResourceResolverException
    */
   public <N> XMLSignatureInput<N> engineResolveURI(XmlContext<N> ctx, N uriAttr, String BaseURI)
   		throws ResourceResolverException {
	   // The default implementation, to preserve backwards compatibility in the
	   // test cases, assumes that this is operating on a DOM, and therefore
	   // "N" must be "Attr"
	   return engineResolve( (Attr) uriAttr, BaseURI);

   }

   /**
    * Method engineSetProperty
    *
    * @param key
    * @param value
    */
   public void engineSetProperty(String key, String value) {
	  if (_properties==null) {
		  _properties=new HashMap<String, String>();
	  }
      this._properties.put(key, value);
   }

   /**
    * Method engineGetProperty
    *
    * @param key
    * @return the value of the property
    */
   public String engineGetProperty(String key) {
	  if (_properties==null) {
			return null;
	  }
      return (String) this._properties.get(key);
   }

   /**
    * 
    * @param properties
    */
   public void engineAddProperies(Map<String, String> properties) {
	  if (properties!=null) {
		  if (_properties==null) {
			  _properties=new HashMap<String, String>();
		  }
		  this._properties.putAll(properties);
	  }
   }
   /**
    * Tells if the implementation does can be reused by several threads safely.
    * It normally means that the implemantation does not have any member, or there is
    * member change betwen engineCanResolve & engineResolve invocations. Or it mantians all
    * member info in ThreadLocal methods.
    */
   public boolean engineIsThreadSafe() {
	   return false;
   }
   /**
    * This method helps the {@link ResourceResolver} to decide whether a
    * {@link ResourceResolverSpi} is able to perform the requested action.
    *
    * @param uri
    * @param BaseURI
    * @return true if the engine can resolve the uri
    * 
    * @deprecated See {@link #engineCanResolveURI(String, String)}
    */
   public boolean engineCanResolve(Attr uri, String BaseURI) {
	   // This method used to be abstract, so any calls to "super" are bogus.
	   throw new UnsupportedOperationException();
   }

   /**
    * This method helps the {@link ResourceResolver} to decide whether a
    * {@link ResourceResolverSpi} is able to perform the requested action.
    *
    * <p>New clients should override this method, and not override {@link #engineCanResolve(Attr, String)}
    * </p>
    * 
    * @param uri
    * @param BaseURI
    * @return true if the engine can resolve the uri
    */
   public <N> boolean engineCanResolveURI(Model<N> model, N uriAttr, String BaseURI) {
	   // The default implementation, to preserve backwards compatibility in the
	   // test cases, assumes we can cast to an Attr.  Newer implementations must
	   // override this method.
	   if (uriAttr instanceof Attr) {
		   return engineCanResolve( (Attr) uriAttr, BaseURI);
	   }
	   else {
		   // Note that we simply skip older resolvers that haven't been upgraded, and flag
		   // that they cannot resolve.  Works better than failing with an exception.
		   // Fixes a problem with the test cases, wherein "registered" list of resolvers
		   // doesn't get reset from one test case to another, and older resolvers cause
		   // newer test case to fail, unless those older resolvers can simply be ignored.
           if (log.isDebugEnabled())
              	log.debug("Attempting to use backwards compatible DOM mode for non DOM XML data.  Class "
        				   + getClass().getName() + " needs an upgrade.");
           
           return false;
	   }
   }

   /**
    * Method engineGetPropertyKeys
    *
    * @return the property keys
    */
   public String[] engineGetPropertyKeys() {
      return new String[0];
   }

   /**
    * Method understandsProperty
    *
    * @param propertyToTest
    * @return true if understands the property
    */
   public boolean understandsProperty(String propertyToTest) {

      String[] understood = this.engineGetPropertyKeys();

      if (understood != null) {
         for (int i = 0; i < understood.length; i++) {
            if (understood[i].equals(propertyToTest)) {
               return true;
            }
         }
      }

      return false;
   }


   /**
    * Fixes a platform dependent filename to standard URI form.
    *
    * @param str The string to fix.
    *
    * @return Returns the fixed URI string.
    */
   public static String fixURI(String str) {

      // handle platform dependent strings
      str = str.replace(java.io.File.separatorChar, '/');

      if (str.length() >= 4) {

         // str =~ /^\W:\/([^/])/ # to speak perl ;-))
         char ch0 = Character.toUpperCase(str.charAt(0));
         char ch1 = str.charAt(1);
         char ch2 = str.charAt(2);
         char ch3 = str.charAt(3);
         boolean isDosFilename = ((('A' <= ch0) && (ch0 <= 'Z'))
                                  && (ch1 == ':') && (ch2 == '/')
                                  && (ch3 != '/'));

         if (isDosFilename) {
            if (log.isDebugEnabled())
            	log.debug("Found DOS filename: " + str);
         }
      }

      // Windows fix
      if (str.length() >= 2) {
         char ch1 = str.charAt(1);

         if (ch1 == ':') {
            char ch0 = Character.toUpperCase(str.charAt(0));

            if (('A' <= ch0) && (ch0 <= 'Z')) {
               str = "/" + str;
            }
         }
      }

      // done
      return str;
   }
   
}
