/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.signature;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.xml.security.algorithms.SignatureAlgorithm;
import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.Canonicalizer;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.apache.xml.security.transforms.params.InclusiveNamespaces;
import org.genxdm.io.DocumentHandler;
import org.genxdm.mutable.NodeFactory;
import org.genxdm.compat.DomCompatibility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Handles <code>&lt;ds:SignedInfo&gt;</code> elements
 * This <code>SignedInfo<code> element includes the canonicalization algorithm,
 * a signature algorithm, and one or more references.
 *
 * @author Christian Geuer-Pollmann
 */
public class SignedInfo<N> extends Manifest<N> {

    /** Field _signatureAlgorithm */
    private SignatureAlgorithm<N> _signatureAlgorithm = null;

    /** Field _c14nizedBytes           */
    private byte[] _c14nizedBytes = null;

    private N c14nMethod;
    private N signatureMethod;

    /**
     * Overwrites {@link Manifest#addDocument} because it creates another 
     * Element.
     *
     * @param doc the {@link Document} in which <code>XMLsignature</code> will 
     *    be placed
     * @throws XMLSecurityException
     * 
     * @deprecated New clients should use {@link #SignedInfo(XmlContext, Object)}
     */
    @SuppressWarnings("unchecked")
	public SignedInfo(Document doc) throws XMLSecurityException {
        this( (XmlContext<N>) XmlContext.getContext(), (N) doc);
    }

    /**
     * Overwrites {@link Manifest#addDocument} because it creates another 
     * Element.
     *
     * @param doc the {@link Document} in which <code>XMLsignature</code> will 
     *    be placed
     * @throws XMLSecurityException
     */
    public SignedInfo(XmlContext<N> ctx, N doc) throws XMLSecurityException {
        this(ctx, doc, XMLSignature.ALGO_ID_SIGNATURE_DSA, 
	     Canonicalizer.ALGO_ID_C14N_OMIT_COMMENTS);
    }

    /**
     * Constructs {@link SignedInfo} using given Canonicalization algorithm and 
     * Signature algorithm.
     *
     * @param doc <code>SignedInfo</code> is placed in this document
     * @param signatureMethodURI URI representation of the Digest and 
     *    Signature algorithm
     * @param canonicalizationMethodURI URI representation of the 
     *    Canonicalization method
     * @throws XMLSecurityException
     * 
     * @deprecated New clients should use {@link #SignedInfo(XmlContext, Object, String, String)}
     */
    @SuppressWarnings("unchecked")
	public SignedInfo(Document doc, String signatureMethodURI, 
	String canonicalizationMethodURI) throws XMLSecurityException {
        this( (XmlContext<N>) XmlContext.getContext(), (N) doc, signatureMethodURI, canonicalizationMethodURI);
    }

    /**
     * Constructs {@link SignedInfo} using given Canonicalization algorithm and 
     * Signature algorithm.
     *
     * @param doc <code>SignedInfo</code> is placed in this document
     * @param signatureMethodURI URI representation of the Digest and 
     *    Signature algorithm
     * @param canonicalizationMethodURI URI representation of the 
     *    Canonicalization method
     * @throws XMLSecurityException
     */
    public SignedInfo(XmlContext<N> ctx, N doc, String signatureMethodURI, 
	String canonicalizationMethodURI) throws XMLSecurityException {
        this(ctx, doc, signatureMethodURI, 0, canonicalizationMethodURI);
    }

    /**
     * Constructor SignedInfo
     *
     * @param doc <code>SignedInfo</code> is placed in this document
     * @param signatureMethodURI URI representation of the Digest and 
     *    Signature algorithm
     * @param hMACOutputLength
     * @param canonicalizationMethodURI URI representation of the 
     *    Canonicalization method
     * @throws XMLSecurityException
     * 
     * @deprecated New clients should use {@link #SignedInfo(XmlContext, Object, String, int, String)}
     */
    @SuppressWarnings("unchecked")
	public SignedInfo(Document doc, String signatureMethodURI, 
	int hMACOutputLength, String canonicalizationMethodURI)
              throws XMLSecurityException {

    	this( (XmlContext<N>) XmlContext.getContext(), (N) doc, signatureMethodURI,
    			hMACOutputLength, canonicalizationMethodURI);
    }
   
    /**
     * Constructor SignedInfo
     *
     * @param doc <code>SignedInfo</code> is placed in this document
     * @param signatureMethodURI URI representation of the Digest and 
     *    Signature algorithm
     * @param hMACOutputLength
     * @param canonicalizationMethodURI URI representation of the 
     *    Canonicalization method
     * @throws XMLSecurityException
     */
    public SignedInfo(XmlContext<N> ctx, N doc, String signatureMethodURI, 
	int hMACOutputLength, String canonicalizationMethodURI)
              throws XMLSecurityException {

        super(ctx, doc);

        NodeFactory<N> factory = getNodeFactory();
		c14nMethod = XMLUtils.createElementInSignatureSpace(factory,
                                Constants._TAG_CANONICALIZATIONMETHOD);

        DomCompatibility.setAttribute(ctx.mutableModel, c14nMethod, "", Constants._ATT_ALGORITHM, "", canonicalizationMethodURI);
        appendSelf(c14nMethod);
        addReturnToSelf();

        if (hMACOutputLength > 0) {
            this._signatureAlgorithm = new SignatureAlgorithm<N>(_model, getDocumentNode(),
                    signatureMethodURI, hMACOutputLength);
        } else {
            this._signatureAlgorithm = new SignatureAlgorithm<N>(_model, getDocumentNode(),
                    signatureMethodURI, false);
        }

        signatureMethod = this._signatureAlgorithm.getElementNode();
        appendSelf(signatureMethod);
        addReturnToSelf();
    }
   
    /**
     * @param doc
     * @param signatureMethodElem
     * @param canonicalizationMethodElem
     * @throws XMLSecurityException
     * 
     * @deprecated New clients should use {@link #SignedInfo(XmlContext, Object, Object, Object)}
     */
    @SuppressWarnings("unchecked")
	public SignedInfo(Document doc, Element signatureMethodElem, 
	Element canonicalizationMethodElem) throws XMLSecurityException {

    	this( (XmlContext<N>) XmlContext.getContext(), (N) doc, (N) signatureMethodElem, (N) canonicalizationMethodElem);
    }

    /**
     * @param doc
     * @param signatureMethodElem
     * @param canonicalizationMethodElem
     * @throws XMLSecurityException
     */
    public SignedInfo(XmlContext<N> ctx, N doc, N signatureMethodElem, 
    		N canonicalizationMethodElem) throws XMLSecurityException {

        super(ctx, doc);
        // Check this?
        this.c14nMethod = canonicalizationMethodElem;
        appendSelf(c14nMethod);
        addReturnToSelf();
   
        this._signatureAlgorithm = 
	    new SignatureAlgorithm<N>(_model, signatureMethodElem, null);

        signatureMethod = this._signatureAlgorithm.getElementNode();
        appendSelf(signatureMethod);
      
        addReturnToSelf();
    }

    /**
     * Build a {@link SignedInfo} from an {@link Element}
     *
     * @param element <code>SignedInfo</code>
     * @param baseURI the URI of the resource where the XML instance was stored
     * @throws XMLSecurityException
     * @see <A HREF="http://lists.w3.org/Archives/Public/w3c-ietf-xmldsig/2001OctDec/0033.html">Question</A>
     * @see <A HREF="http://lists.w3.org/Archives/Public/w3c-ietf-xmldsig/2001OctDec/0054.html">Answer</A>
     * 
     * @deprecated New clients should use {@link #SignedInfo(XmlContext, Object, String)}
     */
    @SuppressWarnings("unchecked")
	public SignedInfo(Element element, String baseURI)
           throws XMLSecurityException {

    	this( (XmlContext<N>) XmlContext.getContext(), (N) element, baseURI);
    }

    /**
     * Build a {@link SignedInfo} from an {@link Element}
     *
     * @param element <code>SignedInfo</code>
     * @param baseURI the URI of the resource where the XML instance was stored
     * @throws XMLSecurityException
     * @see <A HREF="http://lists.w3.org/Archives/Public/w3c-ietf-xmldsig/2001OctDec/0033.html">Question</A>
     * @see <A HREF="http://lists.w3.org/Archives/Public/w3c-ietf-xmldsig/2001OctDec/0054.html">Answer</A>
     */
    public SignedInfo(XmlContext<N> ctx, N element, String baseURI)
           throws XMLSecurityException {

        // Parse the Reference children and Id attribute in the Manifest
        super(ctx, reparseSignedInfoElem(ctx, element), baseURI);

        c14nMethod = _model.getFirstChildElement(element);
        signatureMethod = _model.getNextSiblingElement(c14nMethod);
        this._signatureAlgorithm =
            new SignatureAlgorithm<N>(_model, signatureMethod, this.getBaseURI());
    }

    private static <N> N reparseSignedInfoElem(XmlContext<N> ctx, N element)
        throws XMLSecurityException {

        /* 
         * If a custom canonicalizationMethod is used, canonicalize 
         * ds:SignedInfo, reparse it into a new document
         * and replace the original not-canonicalized ds:SignedInfo by
         * the re-parsed canonicalized one.
         */
        N c14nMethod = ctx.model.getFirstChildElement(element);
        String c14nMethodURI = ctx.model.getAttributeStringValue(c14nMethod, "", Constants._ATT_ALGORITHM);
        if (!(c14nMethodURI.equals(Canonicalizer.ALGO_ID_C14N_OMIT_COMMENTS) ||
            c14nMethodURI.equals(Canonicalizer.ALGO_ID_C14N_WITH_COMMENTS) ||
	    c14nMethodURI.equals(Canonicalizer.ALGO_ID_C14N_EXCL_OMIT_COMMENTS) ||
	    c14nMethodURI.equals(Canonicalizer.ALGO_ID_C14N_EXCL_WITH_COMMENTS) ||
	    c14nMethodURI.equals(Canonicalizer.ALGO_ID_C14N11_OMIT_COMMENTS) ||
	    c14nMethodURI.equals(Canonicalizer.ALGO_ID_C14N11_WITH_COMMENTS))) {
      	    // the c14n is not a secure one and can rewrite the URIs or like 
	    // so reparse the SignedInfo to be sure    
            try {
                Canonicalizer c14nizer =
                    Canonicalizer.getInstance(c14nMethodURI);

                byte[] c14nizedBytes = c14nizer.canonicalizeSubtree(ctx.model, element);
                
                N prevSibling = ctx.model.getPreviousSibling(element);
                N parent = ctx.model.getParent(element);
                
                DocumentHandler<N> docHandler = ctx.docHandlerFactory.newDocumentHandler();
                N newdoc = docHandler.parse(new ByteArrayInputStream(c14nizedBytes), null);
                //N imported = ctx.mutableModel.importNode(ctx.mutableModel.getRoot(element),
                //		ctx.model.getFirstChildElement(newdoc), true);

                N newChild = ctx.model.getFirstChildElement(newdoc);
                // note that the implementation of "replace" is supposed to do the right thing
                // with respect to moving across tree boundaries.
                ctx.mutableModel.replace(element, newChild);

                N result = prevSibling == null ? ctx.model.getFirstChild(parent) : ctx.model.getNextSibling(prevSibling);
                return result;
            } catch (IOException ex) {
                throw new XMLSecurityException("empty", ex);
            }
        }
        return element;
    }

    /**
     * Tests core validation process
     *
     * @return true if verification was successful
     * @throws MissingResourceFailureException
     * @throws XMLSecurityException
     */
    public boolean verify()
           throws MissingResourceFailureException, XMLSecurityException {
        return super.verifyReferences(false);
    }

    /**
     * Tests core validation process
     *
     * @param followManifests defines whether the verification process has to verify referenced <CODE>ds:Manifest</CODE>s, too
     * @return true if verification was successful
     * @throws MissingResourceFailureException
     * @throws XMLSecurityException
     */
    public boolean verify(boolean followManifests)
           throws MissingResourceFailureException, XMLSecurityException {
        return super.verifyReferences(followManifests);
    }

    /**
     * Returns getCanonicalizedOctetStream
     *
     * @return the canonicalization result octet stream of <code>SignedInfo</code> element
     * @throws CanonicalizationException
     * @throws InvalidCanonicalizerException
     * @throws XMLSecurityException
     */
    public byte[] getCanonicalizedOctetStream()
           throws CanonicalizationException, InvalidCanonicalizerException,
                 XMLSecurityException {

        if (this._c14nizedBytes == null) {
            Canonicalizer c14nizer =
                Canonicalizer.getInstance(this.getCanonicalizationMethodURI());

            this._c14nizedBytes =
                c14nizer.canonicalizeSubtree(_model, getElementNode());
        }

        // make defensive copy
        return (byte[]) this._c14nizedBytes.clone();
    }
   
    /**
     * Output the C14n stream to the given OutputStream.
     * @param os
     * @throws CanonicalizationException
     * @throws InvalidCanonicalizerException
     * @throws XMLSecurityException
     */
    public void signInOctectStream(OutputStream os)            
        throws CanonicalizationException, InvalidCanonicalizerException,
            XMLSecurityException {

   	if (this._c14nizedBytes == null) {
            Canonicalizer c14nizer =
                Canonicalizer.getInstance(this.getCanonicalizationMethodURI());
            c14nizer.setWriter(os);
            String inclusiveNamespaces = this.getInclusiveNamespaces();

            if (inclusiveNamespaces == null) {
                c14nizer.canonicalizeSubtree(_model, getElementNode());
            } else {
                c14nizer.canonicalizeSubtree
                    (_model, getElementNode(), inclusiveNamespaces);
            }
        } else {
            try {
		os.write(this._c14nizedBytes);
	    } catch (IOException e) {
		throw new RuntimeException(e);
	    }  
        }    
    }

    /**
     * Returns the Canonicalization method URI
     *
     * @return the Canonicalization method URI
     */
    public String getCanonicalizationMethodURI() {
    	return _model.getAttributeStringValue(c14nMethod, "", Constants._ATT_ALGORITHM);
    }

    /**
     * Returns the Signature method URI
     *
     * @return the Signature method URI
     */
    public String getSignatureMethodURI() {

        N signatureElement = this.getSignatureMethodElement();

        if (signatureElement != null) {
            return _model.getAttributeStringValue(signatureElement, "", Constants._ATT_ALGORITHM);
        }

        return null;
    }

    /**
     * Method getSignatureMethodElement
     * @return returns the SignatureMethod Element   
     *
     */
    public N getSignatureMethodElement() {
        return signatureMethod;
    }

    /**
     * Creates a SecretKey for the appropriate Mac algorithm based on a
     * byte[] array password.
     *
     * @param secretKeyBytes
     * @return the secret key for the SignedInfo element.
     */
    public SecretKey createSecretKey(byte[] secretKeyBytes) {

        return new SecretKeySpec(secretKeyBytes,
                                 this._signatureAlgorithm
                                  .getJCEAlgorithmString());
    }

    protected SignatureAlgorithm<N> getSignatureAlgorithm() {
        return _signatureAlgorithm;
    }

    /**
     * Method getBaseLocalName
     * @inheritDoc
     *
     */
    public String getBaseLocalName() {
        return Constants._TAG_SIGNEDINFO;
    }

    public String getInclusiveNamespaces() {

        String c14nMethodURI = getCanonicalizationMethodURI();
        if (!(c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#") ||
        		c14nMethodURI.equals("http://www.w3.org/2001/10/xml-exc-c14n#WithComments"))) {
            return null;
        }

        N inclusiveElement = _model.getFirstChildElement(c14nMethod);

        if (inclusiveElement != null) {
            try {
                String inclusiveNamespaces = new InclusiveNamespaces<N>
                    (_model, inclusiveElement,
                     InclusiveNamespaces.ExclusiveCanonicalizationNamespace).getInclusiveNamespaces();
                return inclusiveNamespaces;
            } catch (XMLSecurityException e) {
                return null;
            }
        }
        return null;
    }
}
