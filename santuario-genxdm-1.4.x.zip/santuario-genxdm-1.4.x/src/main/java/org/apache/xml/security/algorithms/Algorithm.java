/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.algorithms;



import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.mutable.MutableModel;
import org.genxdm.compat.DomCompatibility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * The Algorithm class which stores the Algorithm URI as a string.
 *
 */
public abstract class Algorithm<N> extends SignatureElementProxy<N> {

   /**
    *
    * @param doc
    * @param algorithmURI is the URI of the algorithm as String
    * 
    * @deprecated New clients should use {@link #Algorithm(XmlContext, Object, String, boolean)}
    */
   @SuppressWarnings({ "unchecked" })
   public Algorithm(Document doc, String algorithmURI) {
	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, algorithmURI, false);
   }

   /**
   * Constructor that takes a document and an algorithm.
   * 
   * <p>Carefully note that this method takes an extra boolean so that it can be distinguished
   * from the other constructor that would otherwise have the same signature.
   * </p>
   * 
   * @param doc
   * @param algorithmURI is the URI of the algorithm as String
   * @param unusedDiscriminator Not used except to distinguish constructors at compile time.
   */
  public Algorithm(MutableModel<N> model, N doc, String algorithmURI, boolean unusedDiscriminator) {

     super(model, doc);
     this.setAlgorithmURI(algorithmURI);
  }

   /**
    * Constructor Algorithm
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    * 
    * @deprecated New clients should use {@link #Algorithm(XmlContext, Object, String)}
    */
   @SuppressWarnings({ "unchecked" })
   public Algorithm(Element element, String BaseURI)
           throws XMLSecurityException {
	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) element, BaseURI);
   }

   /**
    * Constructor Algorithm
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public Algorithm(MutableModel<N> model, N element, String BaseURI)
           throws XMLSecurityException {
      super(model, element, BaseURI);
   }

   /**
    * Method getAlgorithmURI
    *
    * @return The URI of the alogrithm
    */
   public String getAlgorithmURI() {
      return _model.getAttributeStringValue(getElementNode(), "",Constants._ATT_ALGORITHM);
   }

   /**
    * Sets the algorithm's URI as used in the signature.
    *
    * @param algorithmURI is the URI of the algorithm as String
    */
   protected void setAlgorithmURI(String algorithmURI) {

      if ( (algorithmURI != null)) {
    	  DomCompatibility.setAttribute(_model, getElementNode(), "", Constants._ATT_ALGORITHM, "", algorithmURI);
      }
   }
}
