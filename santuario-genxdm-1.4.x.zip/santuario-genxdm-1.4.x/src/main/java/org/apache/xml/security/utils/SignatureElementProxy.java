/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.utils;



import org.apache.xml.security.exceptions.XMLSecurityException;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * Class SignatureElementProxy
 *
 * @author $Author: raul $
 * @version $Revision: 609737 $
 */
public abstract class SignatureElementProxy<N> extends ElementProxy<N> {
	
   /**
    * Constructor SignatureElementProxy
    *
    * @param doc
    * 
    * @deprecated New clients should use {@link #SignatureElementProxy(XmlContext, Object)}
    */
	@SuppressWarnings("unchecked")
   	public SignatureElementProxy(Document doc) {
	   	this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc);
   	}

   /**
    * Constructor SignatureElementProxy
    *
    * @param ctx XML processing context
    * @param doc
    * 
    * @see Subclasses may instead wish to use {@link SignatureElementProxy#SignatureElementProxy(XmlContext, NodeFactory)
    */
   	public SignatureElementProxy(MutableModel<N> model, N doc) {
   		super(model);
   		if (doc == null) {
   			throw new RuntimeException("Document is null");
   		}

	    setDocumentNode(doc);
	    setElementNode( XMLUtils.createElementInSignatureSpace( getNodeFactory(),
	    		   this.getBaseLocalName()) );
   }

    /**
     * Constructor SignatureElementProxy
     *
     * @param ctx XML processing context
     * @param doc
     */
    	public SignatureElementProxy(MutableModel<N> model, NodeFactory<N> factory) {
    		super(model, factory);
    		
 	    setElementNode( XMLUtils.createElementInSignatureSpace( factory,
 	    		   this.getBaseLocalName()) );
    }

   /**
    * Constructor SignatureElementProxy
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    * 
    * @deprecated New clients should use {@link #SignatureElementProxy(XmlContext, Object, String)}
    */
   @SuppressWarnings("unchecked")
   public SignatureElementProxy(Element element, String BaseURI)
           throws XMLSecurityException {
      this( (MutableModel<N>) XmlContext.getDomModel(), (N) element, BaseURI);

   }

   /**
    * Constructor SignatureElementProxy
    *
    * @param ctx Context for working with XML.
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public SignatureElementProxy(MutableModel<N> model, N element, String BaseURI)
           throws XMLSecurityException {
      super(model, element, BaseURI);

   }

   /** @inheritDoc */
   public String getBaseNamespace() {
      return Constants.SignatureSpecNS;
   }
}
