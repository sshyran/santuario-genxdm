/*
 * Copyright  1999-2010 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.keys;



import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.crypto.SecretKey;

import org.apache.xml.security.encryption.EncryptedKey;
import org.apache.xml.security.encryption.XMLCipher;
import org.apache.xml.security.encryption.XMLEncryptionException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.KeyName;
import org.apache.xml.security.keys.content.KeyValue;
import org.apache.xml.security.keys.content.MgmtData;
import org.apache.xml.security.keys.content.PGPData;
import org.apache.xml.security.keys.content.RetrievalMethod;
import org.apache.xml.security.keys.content.SPKIData;
import org.apache.xml.security.keys.content.X509Data;
import org.apache.xml.security.keys.content.keyvalues.DSAKeyValue;
import org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
import org.apache.xml.security.keys.keyresolver.KeyResolver;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.keys.keyresolver.KeyResolverSpi;
import org.apache.xml.security.keys.storage.StorageResolver;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.utils.EncryptionConstants;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.IdResolver;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.NodeKind;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * This class stand for KeyInfo Element that may contain keys, names,
 * certificates and other public key management information,
 * such as in-band key distribution or key agreement data.
 * <BR />
 * KeyInfo Element has two basic functions:
 * One is KeyResolve for getting the public key in signature validation processing.
 * the other one is toElement for getting the element in signature generation processing.
 * <BR />
 * The <CODE>lengthXXX()</CODE> methods provide access to the internal Key
 * objects:
 * <UL>
 * <LI>If the <CODE>KeyInfo</CODE> was constructed from an Element
 * (Signature verification), the <CODE>lengthXXX()</CODE> methods searches
 * for child elements of <CODE>ds:KeyInfo</CODE> for known types. </LI>
 * <LI>If the <CODE>KeyInfo</CODE> was constructed from scratch (during
 * Signature generation), the <CODE>lengthXXX()</CODE> methods return the number
 * of <CODE>XXXs</CODE> objects already passed to the KeyInfo</LI>
 * </UL>
 * <BR />
 * The <CODE>addXXX()</CODE> methods are used for adding Objects of the
 * appropriate type to the <CODE>KeyInfo</CODE>. This is used during signature
 * generation.
 * <BR />
 * The <CODE>itemXXX(int i)</CODE> methods return the i'th object of the
 * corresponding type.
 * <BR />
 * The <CODE>containsXXX()</CODE> methods return <I>whether</I> the KeyInfo
 * contains the corresponding type.
 *
 * @author $Author: coheigea $
 */
public class KeyInfo<N> extends SignatureElementProxy<N> {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(KeyInfo.class.getName());
    List<X509Data<N>> x509Datas = null;
    List<EncryptedKey<N>> encryptedKeys = null;
    
    private final XmlContext<N> m_ctx;
    
    // We need at least one StorageResolver otherwise
    // the KeyResolvers would not be called.
    // The default StorageResolver is null.
    static final List<StorageResolver> nullList;
    static {
    	List<StorageResolver> list = new ArrayList<StorageResolver>();
        list.add(null);
        nullList = Collections.unmodifiableList(list);
    }

   /**
    * Constructor KeyInfo
    * @param doc
    * 
    * @deprecated New clients should use {@link #KeyInfo(XmlContext, Object)}
    */
   @SuppressWarnings("unchecked")
   public KeyInfo(Document doc) {

	   this( (XmlContext<N>) XmlContext.getContext(), (N) doc);
   }

   /**
    * Constructor KeyInfo
    * @param doc
    */
   public KeyInfo(XmlContext<N> ctx, N doc) {

      super(ctx.mutableModel, doc);
      m_ctx = ctx;
      addReturnToSelf();
      
   }

   /**
    * Constructor KeyInfo
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    * 
    * @deprecated New clients should use {@link #KeyInfo(XmlContext, Object, String)}
    */
   @SuppressWarnings("unchecked")
   public KeyInfo(Element element, String BaseURI) throws XMLSecurityException {
	   this( (XmlContext<N>) XmlContext.getContext(), (N) element, BaseURI);
   }

   /**
    * Constructor KeyInfo
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public KeyInfo(XmlContext<N> ctx, N element, String BaseURI) throws XMLSecurityException {
      super(ctx.mutableModel, element, BaseURI);
      m_ctx = ctx;
     // _storageResolvers.add(null);

   }

   /**
    * Sets the <code>Id</code> attribute
    *
    * @param Id ID
    */
   public void setId(String Id) {

      if ((Id != null)) {
    	  setLocalAttribute(Constants._ATT_ID, Id);
    	  IdResolver.registerElementById(_model, getDocumentNode(), getElementNode(), Id);
      }
   }

   /**
    * Returns the <code>Id</code> attribute
    *
    * @return the <code>Id</code> attribute
    */
   public String getId() {
	   return getLocalAttribute(Constants._ATT_ID);
   }

   /**
    * Method addKeyName
    *
    * @param keynameString
    */
   public void addKeyName(String keynameString) {
      this.add(new KeyName<N>(_model, getDocumentNode(), keynameString, false));
   }

   /**
    * Method add
    *
    * @param keyname
    */
   public void add(KeyName<N> keyname) {

	   appendSelf(keyname.getElementNode());
	   addReturnToSelf();
   }

   /**
    * Method addKeyValue
    *
    * @param pk
    */
   public void addKeyValue(PublicKey pk) {
      this.add(new KeyValue<N>(_model, getDocumentNode(), pk));
   }

   /**
    * Method addKeyValue
    *
    * @param unknownKeyValueElement
    */
   public void addKeyValue(N unknownKeyValueElement) {
      this.add(new KeyValue<N>(_model, getDocumentNode(), unknownKeyValueElement));
   }

   /**
    * Method add
    *
    * @param dsakeyvalue
    */
   public void add(DSAKeyValue<N> dsakeyvalue) {
      this.add(new KeyValue<N>(_model, getDocumentNode(), dsakeyvalue));
   }

   /**
    * Method add
    *
    * @param rsakeyvalue
    */
   public void add(RSAKeyValue<N> rsakeyvalue) {
      this.add(new KeyValue<N>(_model, getDocumentNode(), rsakeyvalue));
   }

   /**
    * Method add
    *
    * @param pk
    */
   public void add(PublicKey pk) {
      this.add(new KeyValue<N>(_model, getDocumentNode(), pk));
   }

   /**
    * Method add
    *
    * @param keyvalue
    */
   public void add(KeyValue<N> keyvalue) {
	   appendSelf(keyvalue.getElementNode());
	   addReturnToSelf();
   }

   /**
    * Method addMgmtData
    *
    * @param mgmtdata
    */
   public void addMgmtData(String mgmtdata) {
      this.add(new MgmtData<N>(_model, getDocumentNode(), mgmtdata, false));
   }

   /**
    * Method add
    *
    * @param mgmtdata
    */
   public void add(MgmtData<N> mgmtdata) {
	   appendSelf(mgmtdata.getElementNode());
	   addReturnToSelf();
   }

   /**
    * Method addPGPData
    *
    * @param pgpdata
    */
   	public void add(PGPData<N> pgpdata) {
   		appendSelf(pgpdata.getElementNode());
   		addReturnToSelf();
   	}

   /**
    * Method addRetrievalMethod
    *
    * @param URI
    * @param transforms
    * @param Type  
    */
   public void addRetrievalMethod(String URI, Transforms<N> transforms,
                                  String Type) {
      this.add(new RetrievalMethod<N>(m_ctx, getDocumentNode(), URI, transforms, Type));
   }

   /**
    * Method add
    *
    * @param retrievalmethod
    */
   public void add(RetrievalMethod<N> retrievalmethod) {
	   appendSelf(retrievalmethod.getElementNode());
  		addReturnToSelf();
   }

   /**
    * Method add
    *
    * @param spkidata
    */
   	public void add(SPKIData<N> spkidata) {
   		appendSelf(spkidata.getElementNode());
   		addReturnToSelf();
   	}

   /**
    * Method addX509Data
    *
    * @param x509data
    */
   public void add(X509Data<N> x509data) {
    	  if (x509Datas==null)
    		  x509Datas=new ArrayList<X509Data<N>>();
    	  x509Datas.add(x509data);
    	  appendSelf(x509data.getElementNode());
     		addReturnToSelf();
   }

	/**
	 * Method addEncryptedKey
	 *
	 * @param encryptedKey
	 * @throws XMLEncryptionException
	 */

	public void add(EncryptedKey<N> encryptedKey) 
		throws XMLEncryptionException {
			if (encryptedKeys==null)
				encryptedKeys=new ArrayList<EncryptedKey<N>>();
			encryptedKeys.add(encryptedKey);
			XMLCipher<N> cipher = XMLCipher.getInstance();
			appendSelf(cipher.martial(_model, encryptedKey));
	}

   /**
    * Method addUnknownElement
    *
    * @param element
    */
   public void addUnknownNode(N element) {
         appendSelf(element);
         addReturnToSelf();
   }

   /**
    * Method addUnknownElement
    *
    * @param element
    * 
    * @deprecated New clients should use {@link #addUnknownNode(Object)}
    */
   @SuppressWarnings("unchecked")
   public void addUnknownElement(Element element) {
	   addUnknownNode((N) element);
   }

   /**
    * Method lengthKeyName
    *
    * @return the number of the KeyName tags
    */
   public int lengthKeyName() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_KEYNAME);
   }

   /**
    * Method lengthKeyValue
    *
    *@return the number of the KeyValue tags
    */
   public int lengthKeyValue() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_KEYVALUE);
   }

   /**
    * Method lengthMgmtData
    *
    *@return the number of the MgmtData tags
    */
   public int lengthMgmtData() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_MGMTDATA);
   }

   /**
    * Method lengthPGPData
    *
    *@return the number of the PGPDat. tags
    */
   public int lengthPGPData() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_PGPDATA);
   }

   /**
    * Method lengthRetrievalMethod
    *
    *@return the number of the RetrievalMethod tags
    */
   public int lengthRetrievalMethod() {
      return this.length(Constants.SignatureSpecNS,
                         Constants._TAG_RETRIEVALMETHOD);
   }

   /**
    * Method lengthSPKIData
    *
    *@return the number of the SPKIData tags
    */
   public int lengthSPKIData() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_SPKIDATA);
   }

   /**
    * Method lengthX509Data
    *
    *@return the number of the X509Data tags
    */
   public int lengthX509Data() {
	   if (x509Datas!=null) {
		   return x509Datas.size(); 
	   }
      return this.length(Constants.SignatureSpecNS, Constants._TAG_X509DATA);
   }

   /**
    * Method lengthUnknownElement
    * NOTE posibly buggy.
    *@return the number of the UnknownElement tags
    */
   public int lengthUnknownElement() {

      int res = 0;
      for (N current : _model.getChildElements(getElementNode()) ) {
    	  
    	  if (_model.getNamespaceURI(current).equals(Constants.SignatureSpecNS)) {
    		  res++;
    	  }
      }
      return res;
   }

   /**
    * Method itemKeyName
    *
    * @param i
    * @return the asked KeyName element, null if the index is too big
    * @throws XMLSecurityException
    */
   public KeyName<N> itemKeyName(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_KEYNAME,i);

      if (e != null) {
         return new KeyName<N>(_model, e, this._baseURI);
      } 
      return null;      
   }

   /**
    * Method itemKeyValue
    *
    * @param i
    * @return the asked KeyValue element, null if the index is too big
    * @throws XMLSecurityException
    */
   public KeyValue<N> itemKeyValue(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_KEYVALUE,i);

      if (e != null) {
         return new KeyValue<N>(_model, e, this._baseURI);
      } 
      return null;      
   }

   /**
    * Method itemMgmtData
    *
    * @param i
    *@return the asked MgmtData element, null if the index is too big
    * @throws XMLSecurityException
    */
   public MgmtData<N> itemMgmtData(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_MGMTDATA,i);

      if (e != null) {
         return new MgmtData<N>(_model, e, this._baseURI);
      } 
       return null;      
   }

   /**
    * Method itemPGPData
    *
    * @param i
    *@return the asked PGPData element, null if the index is too big
    * @throws XMLSecurityException
    */
   public PGPData<N> itemPGPData(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_PGPDATA,i);

      if (e != null) {
         return new PGPData<N>(_model, e, this._baseURI);
      } 
      return null;      
   }

   /**
    * Method itemRetrievalMethod
    *
    * @param i
    *@return the asked RetrievalMethod element, null if the index is too big
    * @throws XMLSecurityException
    */
   public RetrievalMethod<N> itemRetrievalMethod(int i)
           throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_RETRIEVALMETHOD,i);

      if (e != null) {
         return new RetrievalMethod<N>(m_ctx, e, this._baseURI);
      } 
      return null;
   }

   /**
    * Method itemSPKIData
    *
    * @param i
    *@return the asked SPKIData element, null if the index is too big
    * @throws XMLSecurityException
    */
   public SPKIData<N> itemSPKIData(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_SPKIDATA,i);

      if (e != null) {
         return new SPKIData<N>(_model, e, this._baseURI);
      } 
      return null;     
   }

   /**
    * Method itemX509Data
    *@return the asked X509Data element, null if the index is too big
    * @param i
    *
    * @throws XMLSecurityException
    */
   public X509Data<N> itemX509Data(int i) throws XMLSecurityException {
	   if (x509Datas!=null) {
		   return x509Datas.get(i); 
	   }
      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_X509DATA,i);

      if (e != null) {
         return new X509Data<N>(_model, e, this._baseURI);
      } 
      return null;
   }

   /**
	* Method itemEncryptedKey
	*
	* @param i
	* @return the asked EncryptedKey element, null if the index is too big
	* @throws XMLSecurityException
	*/

	public EncryptedKey<N> itemEncryptedKey(int i) throws XMLSecurityException {
		if (encryptedKeys!=null) {
			return encryptedKeys.get(i);
		}
		N e = 
			XMLUtils.selectXencNode(_model, getFirstChild(),
										  EncryptionConstants._TAG_ENCRYPTEDKEY,i);

		if (e != null) {
			XMLCipher<N> cipher = XMLCipher.getInstance();
			cipher.init(XMLCipher.UNWRAP_MODE, null);
			return cipher.loadEncryptedKey(m_ctx, e);
		}
		return null;
   }

   /**
    * Method itemUnknownElement
    *
    * @param i index
    * @return the element number of the unknown elemens
    */
   public N itemUnknownNode(int i) {

	   int res = 0;
	   for (N current : _model.getChildElements(getElementNode() ) ) {
		   if (_model.getNamespaceURI(current).equals(Constants.SignatureSpecNS) ) {
			   res++;

	            if (res == i) {
	                return current;
	             }
		   }
		   
	   }
	   
	   return null;
   }

   /**
    * Method isEmpty
    *
    * @return true if the element has no descedants.
    */
   public boolean isEmpty() {
      return getFirstChild()==null;
   }

   /**
    * Method containsKeyName
    *
    * @return If the KeyInfo contains a KeyName node
    */
   public boolean containsKeyName() {
      return this.lengthKeyName() > 0;
   }

   /**
    * Method containsKeyValue
    *
    * @return If the KeyInfo contains a KeyValue node
    */
   public boolean containsKeyValue() {
      return this.lengthKeyValue() > 0;
   }

   /**
    * Method containsMgmtData
    *
    * @return If the KeyInfo contains a MgmtData node
    */
   public boolean containsMgmtData() {
      return this.lengthMgmtData() > 0;
   }

   /**
    * Method containsPGPData
    *
    * @return If the KeyInfo contains a PGPData node
    */
   public boolean containsPGPData() {
      return this.lengthPGPData() > 0;
   }

   /**
    * Method containsRetrievalMethod
    *
    * @return If the KeyInfo contains a RetrievalMethod node
    */
   public boolean containsRetrievalMethod() {
      return this.lengthRetrievalMethod() > 0;
   }

   /**
    * Method containsSPKIData
    *
    * @return If the KeyInfo contains a SPKIData node
    */
   public boolean containsSPKIData() {
      return this.lengthSPKIData() > 0;
   }

   /**
    * Method containsUnknownElement
    *
    * @return If the KeyInfo contains a UnknownElement node
    */
   public boolean containsUnknownElement() {
      return this.lengthUnknownElement() > 0;
   }

   /**
    * Method containsX509Data
    *
    * @return If the KeyInfo contains a X509Data node
    */
   public boolean containsX509Data() {
      return this.lengthX509Data() > 0;
   }

   /**
    * This method returns the public key.
    *
    * @return If the KeyInfo contains a PublicKey node
    * @throws KeyResolverException
    */

   public PublicKey getPublicKey() throws KeyResolverException {

      PublicKey pk = this.getPublicKeyFromInternalResolvers();

      if (pk != null) {
         log.debug("I could find a key using the per-KeyInfo key resolvers");

         return pk;
      } 
      log.debug("I couldn't find a key using the per-KeyInfo key resolvers");      

      pk = this.getPublicKeyFromStaticResolvers();

      if (pk != null) {
         log.debug("I could find a key using the system-wide key resolvers");

         return pk;
      }
      log.debug("I couldn't find a key using the system-wide key resolvers");      

      return null;
   }

   /**
    * Searches the library wide KeyResolvers for public keys
    *
    * @return The public key contained in this Node.
    * @throws KeyResolverException
    */
   PublicKey getPublicKeyFromStaticResolvers() throws KeyResolverException {
	  int length=KeyResolver.length();
	  int storageLength=this._storageResolvers.size();
	  Iterator<KeyResolverSpi> it= KeyResolver.iterator();
      for (int i = 0; i < length; i++) {
         KeyResolverSpi keyResolver = it.next();
         N currentChild = getFirstChild();
         String uri= this.getBaseURI();
         while (currentChild!=null)      {       
            if (_model.getNodeKind(currentChild) == NodeKind.ELEMENT) {          	  
                  for (int k = 0; k < storageLength; k++) {
                     StorageResolver storage =
                        (StorageResolver) this._storageResolvers.get(k);

                     PublicKey pk =
                           keyResolver.engineLookupAndResolvePublicKey(m_ctx, currentChild,
                                                       uri,
                                                        storage);

                     if (pk != null) {
                    	 KeyResolver.hit(it);
                         return pk;
                     }                     
                  }                              
            }
            currentChild = _model.getNextSibling(currentChild);
         }      
      }
      return null;
   }

   /**
    * Searches the per-KeyInfo KeyResolvers for public keys
    *
    * @return The public key contained in this Node.
    * @throws KeyResolverException
    */
   PublicKey getPublicKeyFromInternalResolvers() throws KeyResolverException {
	  int length=lengthInternalKeyResolver();
	  int storageLength=this._storageResolvers.size();
      for (int i = 0; i < length; i++) {
         KeyResolverSpi keyResolver = this.itemInternalKeyResolver(i);
         if (log.isDebugEnabled())
         	log.debug("Try " + keyResolver.getClass().getName());

         N currentChild= this.getFirstChild();
         String uri=this.getBaseURI();
         while (currentChild!=null)      {    
            if (_model.getNodeKind(currentChild) == NodeKind.ELEMENT) {               
               for (int k = 0; k < storageLength; k++) {
                   StorageResolver storage =
                      (StorageResolver) this._storageResolvers.get(k);
                   PublicKey pk = keyResolver
                           .engineLookupAndResolvePublicKey(m_ctx, currentChild, uri, storage);

                     if (pk != null) {
                         return pk;
                     }                     
                  }               
            }
            currentChild = _model.getNextSibling(currentChild);
         }
      }

      return null;
   }

   /**
    * Method getX509Certificate
    *
    * @return The certificate contained in this KeyInfo
    * @throws KeyResolverException
    */
   public X509Certificate getX509Certificate() throws KeyResolverException {

      // First search using the individual resolvers from the user
      X509Certificate cert = this.getX509CertificateFromInternalResolvers();

      if (cert != null) {
         log.debug(
            "I could find a X509Certificate using the per-KeyInfo key resolvers");

         return cert;
      } 
      log.debug(
            "I couldn't find a X509Certificate using the per-KeyInfo key resolvers");
      

      // Then use the system-wide Resolvers
      cert = this.getX509CertificateFromStaticResolvers();

      if (cert != null) {
         log.debug(
            "I could find a X509Certificate using the system-wide key resolvers");

         return cert;
      } 
      log.debug(
            "I couldn't find a X509Certificate using the system-wide key resolvers");
      

      return null;
   }

   /**
    * This method uses each System-wide {@link KeyResolver} to search the
    * child elements. Each combination of {@link KeyResolver} and child element
    * is checked against all {@link StorageResolver}s.
    *
    * @return The certificate contined in this KeyInfo
    * @throws KeyResolverException
    */
   X509Certificate getX509CertificateFromStaticResolvers()
           throws KeyResolverException {
      if (log.isDebugEnabled())
      	log.debug("Start getX509CertificateFromStaticResolvers() with "
                + KeyResolver.length() + " resolvers");
      String uri=this.getBaseURI();
      int length= KeyResolver.length();
      int storageLength=this._storageResolvers.size();   
      Iterator<KeyResolverSpi> it = KeyResolver.iterator();
      for (int i = 0; i <length; i++) {
         KeyResolverSpi keyResolver = it.next();
         X509Certificate cert= applyCurrentResolver(uri, storageLength, keyResolver);
         if (cert!=null) {
        	 KeyResolver.hit(it);
        	 return cert;
         }
      }
      return null;
   }

   private X509Certificate applyCurrentResolver(String uri, int storageLength, KeyResolverSpi keyResolver) throws KeyResolverException {
	   N currentChild = getFirstChild();
	   while (currentChild!=null)      {       
		   if (_model.getNodeKind(currentChild) == NodeKind.ELEMENT) {
	       for (int k = 0; k < storageLength; k++) {
	           StorageResolver storage = this._storageResolvers.get(k);

	           X509Certificate cert = keyResolver
	                .engineLookupResolveX509Certificate(m_ctx, currentChild, uri,
	                		storage);

	           if (cert != null) {                	   
	               return cert;
	          }                  
	       }               
	    }
	    currentChild = _model.getNextSibling(currentChild);
	 }
	 return null;
   }

   /**
    * Method getX509CertificateFromInternalResolvers
    *
    * @return The certificate contined in this KeyInfo
    * @throws KeyResolverException
    */
   X509Certificate getX509CertificateFromInternalResolvers()
           throws KeyResolverException {
      if (log.isDebugEnabled())
      	log.debug("Start getX509CertificateFromInternalResolvers() with "
                + this.lengthInternalKeyResolver() + " resolvers");
      String uri=this.getBaseURI();
      int storageLength=this._storageResolvers.size();
      for (int i = 0; i < this.lengthInternalKeyResolver(); i++) {
         KeyResolverSpi keyResolver = this.itemInternalKeyResolver(i);
         if (log.isDebugEnabled())
         	log.debug("Try " + keyResolver.getClass().getName());
         X509Certificate cert= applyCurrentResolver(uri, storageLength, keyResolver);
         if (cert!=null) {        	
        	 return cert;
         }      
      }

      return null;
   }

   /**
    * This method returns a secret (symmetric) key. This is for XML Encryption.
    * @return the secret key contained in this KeyInfo
    * @throws KeyResolverException
    */
   public SecretKey getSecretKey() throws KeyResolverException {
      SecretKey sk = this.getSecretKeyFromInternalResolvers();

      if (sk != null) {
         log.debug("I could find a secret key using the per-KeyInfo key resolvers");

         return sk;
      } 
      log.debug("I couldn't find a secret key using the per-KeyInfo key resolvers");
      

      sk = this.getSecretKeyFromStaticResolvers();

      if (sk != null) {
         log.debug("I could find a secret key using the system-wide key resolvers");

         return sk;
      } 
      log.debug("I couldn't find a secret key using the system-wide key resolvers");
      

      return null;
   }

   /**
    * Searches the library wide KeyResolvers for Secret keys
    *
    * @return the secret key contained in this KeyInfo
    * @throws KeyResolverException
    */

   SecretKey getSecretKeyFromStaticResolvers() throws KeyResolverException {
		  final int length=KeyResolver.length();
		  int storageLength=this._storageResolvers.size();
		  Iterator<KeyResolverSpi> it = KeyResolver.iterator();
      for (int i = 0; i < length; i++) {
         KeyResolverSpi keyResolver = (KeyResolverSpi) it.next();

         String uri=this.getBaseURI();
         for (N currentChild : _model.getChildElements(getElementNode() )) {
             for (int k = 0; k < storageLength; k++) {
                 StorageResolver storage = this._storageResolvers.get(k);

                 SecretKey sk =
                       keyResolver.engineLookupAndResolveSecretKey(m_ctx, currentChild,
                                                    uri,
                                                    storage);

                 if (sk != null) {
                    return sk;
                 }                     
              }               
         }
      }
      return null;
   }

   /**
    * Searches the per-KeyInfo KeyResolvers for secret keys
    *
    * @return the secret key contained in this KeyInfo
    * @throws KeyResolverException
    */

   SecretKey getSecretKeyFromInternalResolvers() throws KeyResolverException {
       int storageLength=this._storageResolvers.size();
      for (int i = 0; i < this.lengthInternalKeyResolver(); i++) {
         KeyResolverSpi keyResolver = this.itemInternalKeyResolver(i);
         if (log.isDebugEnabled())
            log.debug("Try " + keyResolver.getClass().getName());

         N currentChild = getFirstChild();
         String uri=this.getBaseURI();
         while (currentChild!=null)      {    
            if (_model.getNodeKind(currentChild) == NodeKind.ELEMENT) {
               for (int k = 0; k < storageLength; k++) {
                     StorageResolver storage =
                        (StorageResolver) this._storageResolvers.get(k);

                     SecretKey sk = keyResolver
                           .engineLookupAndResolveSecretKey(m_ctx, currentChild, uri, storage);

                     if (sk != null) {
                        return sk;
                     }                    
                }
             }            
            currentChild = _model.getNextSibling(currentChild);
         }
      }

      return null;
   }

   /**
    * This method returns a private key. This is for Key Transport in XML Encryption.
    * @return the private key contained in this KeyInfo
    * @throws KeyResolverException
    */
   public PrivateKey getPrivateKey() throws KeyResolverException {
      PrivateKey pk = this.getPrivateKeyFromInternalResolvers();

      if (pk != null) {
         log.debug("I could find a private key using the per-KeyInfo key resolvers");
         return pk;
      } 
      log.debug("I couldn't find a secret key using the per-KeyInfo key resolvers");

      pk = this.getPrivateKeyFromStaticResolvers();
      if (pk != null) {
         log.debug("I could find a private key using the system-wide key resolvers");
         return pk;
      } 
      log.debug("I couldn't find a private key using the system-wide key resolvers");
      
      return null;
   }

   /**
    * Searches the library wide KeyResolvers for Private keys
    *
    * @return the private key contained in this KeyInfo
    * @throws KeyResolverException
    */
   PrivateKey getPrivateKeyFromStaticResolvers() throws KeyResolverException {
      final int length=KeyResolver.length();
      Iterator<KeyResolverSpi> it = KeyResolver.iterator();
      for (int i = 0; i < length; i++) {
         KeyResolverSpi keyResolver = it.next();

         N currentChild = _model.getFirstChild(getElementNode() );
         String uri=this.getBaseURI();
         while (currentChild!=null)      {    
            if (_model.getNodeKind(currentChild) == NodeKind.ELEMENT) {
                // not using StorageResolvers at the moment
                // since they cannot return private keys
                StorageResolver storage = null;
                PrivateKey pk = keyResolver.engineLookupAndResolvePrivateKey(
                        (Element) currentChild,
                        uri,
                        storage);

                if (pk != null) {
                    return pk;
                }                     
            }
            currentChild = _model.getNextSibling(currentChild);
         }
      }
      return null;
   }

   /**
    * Searches the per-KeyInfo KeyResolvers for private keys
    *
    * @return the private key contained in this KeyInfo
    * @throws KeyResolverException
    */

   PrivateKey getPrivateKeyFromInternalResolvers() throws KeyResolverException {
      for (int i = 0; i < this.lengthInternalKeyResolver(); i++) {
         KeyResolverSpi keyResolver = this.itemInternalKeyResolver(i);
         if (log.isDebugEnabled())
            log.debug("Try " + keyResolver.getClass().getName());

         N currentChild = _model.getFirstChild(getElementNode());
         String uri=this.getBaseURI();
         while (currentChild!=null)      {    
            if (_model.getNodeKind(currentChild) == NodeKind.ELEMENT) {
                // not using StorageResolvers at the moment
                // since they cannot return private keys
                StorageResolver storage = null;
                PrivateKey pk = keyResolver
                       .engineLookupAndResolvePrivateKey((Element) currentChild, uri, storage);

                if (pk != null) {
                   return pk;
                }                    
             }            
            currentChild = _model.getNextSibling(currentChild);
         }
      }

      return null;
   }

   /**
    * Stores the individual (per-KeyInfo) {@link KeyResolver}s
    */
   List<KeyResolverSpi> _internalKeyResolvers = null;

   /**
    * This method is used to add a custom {@link KeyResolverSpi} to a KeyInfo
    * object.
    *
    * @param realKeyResolver
    */
   public void registerInternalKeyResolver(KeyResolverSpi realKeyResolver) {
	   if (_internalKeyResolvers==null) {
		   _internalKeyResolvers=new ArrayList<KeyResolverSpi >();
	   }
      this._internalKeyResolvers.add(realKeyResolver);
   }

   /**
    * Method lengthInternalKeyResolver
    * @return the length of the key
    */
   int lengthInternalKeyResolver() {
	   if (_internalKeyResolvers==null)
		   return 0;
      return this._internalKeyResolvers.size();
   }

   /**
    * Method itemInternalKeyResolver
    *
    * @param i the index
    * @return the KeyResolverSpi for the index.
    */
   KeyResolverSpi itemInternalKeyResolver(int i) {
      return this._internalKeyResolvers.get(i);
   }

   /** Field _storageResolvers */
   List<StorageResolver> _storageResolvers = nullList;

   /**
    * Method addStorageResolver
    *
    * @param storageResolver
    */
   public void addStorageResolver(StorageResolver storageResolver) {
	   if  (_storageResolvers == nullList  ){
	       // Replace the default null StorageResolver
		   _storageResolvers=new ArrayList<StorageResolver>();
	   }      
       this._storageResolvers.add(storageResolver);
   }

   //J-
   static boolean _alreadyInitialized = false;
   /** init the keyinfo (Still needed?)*/
   public static void init() {

      if (!KeyInfo._alreadyInitialized) {
         if (KeyInfo.log == null) {

            /**
             * $todo$ why the hell does the static initialization from the
             *  start not work ?
             */
            KeyInfo.log =
                    org.apache.commons.logging.LogFactory.getLog(KeyInfo.class.getName());

            log.error("Had to assign log in the init() function");
         }

         // KeyInfo._contentHandlerHash = new HashMap(10);
         KeyInfo._alreadyInitialized = true;
      }
   }

   /** @inheritDoc */
   public String getBaseLocalName() {
      return Constants._TAG_KEYINFO;
   }
}
