/*
 * Copyright 1999-2008 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.utils;



import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.xml.security.exceptions.Base64DecodingException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.genxdm.Model;
import org.genxdm.NodeKind;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;
import org.genxdm.compat.DomCompatibility;
import org.genxdm.names.NamespaceBinding;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


/**
 * This is the base class to all Objects which have a direct 1:1 mapping to an
 * Element in a particular namespace.
 *
 * @author $Author: coheigea $
 */
public abstract class ElementProxy<N> {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(ElementProxy.class.getName());
   
   /**
    * Returns the namespace of the Elements of the sub-class.
    *
    * @return the namespace of the Elements of the sub-class.
    */
   public abstract String getBaseNamespace();

   /**
    * Returns the localname of the Elements of the sub-class.
    *
    * @return the localname of the Elements of the sub-class.
    */
   public abstract String getBaseLocalName();

   /**
    * Factory for creating nodes...
    */
   private NodeFactory<N> _nodeFactory = null;
   
   /**
    * What XML element does this ElementProxy instance wrap? 
    */
   private N _wrappedElement = null;

   /** Field _baseURI */
   protected String _baseURI = null;

   private N _wrappedDoc = null; 

   protected final MutableModel<N> _model;
   
   /**
    * Constructor ElementProxy
    *
    */
   public ElementProxy(MutableModel<N> model) {
	   _model = model;
   }

   public ElementProxy(MutableModel<N> model, NodeFactory<N> factory) {
	   this(model);
	   _nodeFactory = factory;
   }
   /**
    * Constructor ElementProxy
    *
    * @param doc
    */
   public ElementProxy(MutableModel<N> model, N doc) {
	   this(model);
	   if (doc == null) {
		   throw new RuntimeException("Document is null");
	   }

	   _wrappedDoc = doc;
      setElementNode(createElementNodeForFamilyLocal(this.getBaseNamespace(),
    		  this.getBaseLocalName()) );      
   }
   
   protected N createElementNodeForFamilyLocal(String namespace,
           String localName) {
	   
	   // new API removes the document parameter for this method, but the must assert that it is not null.
	   NodeFactory<N> nodeFact = getNodeFactory();
	   
	 	  N result = null;
	      if (namespace == null) {
	         result = nodeFact.createElement("", localName, "");
	      } else {
	    	  String baseName=this.getBaseNamespace();
	    	  String prefix=ElementProxy.getDefaultPrefix(baseName);
	         if ((prefix == null) || (prefix.length() == 0)) {
	        	 prefix = "";
	         }
	         result = nodeFact.createElement(namespace, localName, prefix);
	         _model.insertNamespace(result, prefix, namespace);
	      }	      
	      return result;
   }


   protected N createElementNodeForFamilyLocal(NodeFactory<N> nodeFactory, String namespace,
           String localName) {
	   
	 	  N result = null;
	      if (namespace == null) {
	         result = nodeFactory.createElement("", localName, "");
	      } else {
	    	  String baseName=this.getBaseNamespace();
	    	  String prefix=ElementProxy.getDefaultPrefix(baseName);
	         if ((prefix == null) || (prefix.length() == 0)) {
	        	 prefix = "";
	         }
	         result = nodeFactory.createElement(namespace, localName, prefix);
	         _model.insertNamespace(result, prefix, namespace);
	      }	      
	      return result;
   }


   /**
    * This method creates an Element in a given namespace with a given localname.
    * It uses the {@link ElementProxy#getDefaultPrefix} method to decide whether
    * a particular prefix is bound to that namespace.
    * <BR />
    * This method was refactored out of the constructor.
 * @param model TODO
 * @param namespace
 * @param localName
 * @param doc
    *
    * @return The element created.
    */
   public static <N> N createElementForFamily(MutableModel<N> model, NodeFactory<N> nodeFactory,
           String namespace, String localName) {
	   
       //Element nscontext = XMLUtils.createDSctx(doc, "x", namespace);
      N result = null;
      String prefix = ElementProxy.getDefaultPrefix(namespace);

      if (namespace == null) {
    	  result = nodeFactory.createElement("", localName, "");
      } else {
         if ((prefix == null) || (prefix.length() == 0)) {
        	 prefix = "";
         }
 	  	result = nodeFactory.createElement(namespace, localName, prefix);
 	  	model.insertNamespace(result, prefix, namespace);
      }

      return result;
   }

   /**
    * Method setElement
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    * 
    * @deprecated New clients should use {@link #setElementNode(Object, String)}
    */
   	@SuppressWarnings("unchecked")
   	public void setElement(Element element, String BaseURI)
           throws XMLSecurityException {
   		setElementNode((N) element, BaseURI);
   	}

   /**
    * Method setElement
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public void setElementNode(N element, String BaseURI)
           throws XMLSecurityException {

      if (element == null) {
         throw new XMLSecurityException("ElementProxy.nullElement");
      }
      
      if (log.isDebugEnabled()) {
      	log.debug("setElement(" + XMLUtils.getTagName(_model, element) + ", \"" + BaseURI + "\"");
      }
        
      setElementNode( element );
      this._baseURI = BaseURI;
   }

   /**
    * Constructor ElementProxy
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public ElementProxy(MutableModel<N> model, N element, String BaseURI)
           throws XMLSecurityException {
	   this(model);
      if (element == null) {
         throw new XMLSecurityException("ElementProxy.nullElement");
      }
      
      if (log.isDebugEnabled()) {
      	log.debug("setElement(\"" + XMLUtils.getTagName(model, element) + "\", \"" + BaseURI
                + "\")");
      }

      setElementNode( element );
      this._baseURI = BaseURI;

      this.guaranteeThatElementInCorrectSpace();
   }

   /**
    * Returns the Element which was constructed by the Object.
    *
    * @return the Element which was constructed by the Object.
    * 
    * @deprecated New clients should use {@link #getElementNode()}
    */
   public final Element getElement() {
	   if ( !(this._wrappedElement instanceof Element) ) {
		   throw new IllegalStateException("Attempting to use a DOM API for a non-DOM XML tree.");
	   }
      return (Element) this._wrappedElement;
   }

   public Model<N> getModel() {
	   return _model;
   }
   
   /**
    * Returns the Element plus a leading and a trailing CarriageReturn Text node.
    *
    * @return the Element which was constructed by the Object.
    * @deprecated New clients should use {@link #getElementWrappedByReturns()}
    */
   	@SuppressWarnings("unchecked")
   	public final NodeList getElementPlusReturns() {

   		HelperNodeList nl = new HelperNodeList();
   		nl.addAll( (Collection<Node>) getElementWrappedByReturns() );
   		return nl;
   }

   /**
    * Returns the Element plus a leading and a trailing CarriageReturn Text node.
    *
    * @return the Element which was constructed by the Object.
    */
   public final List<N> getElementWrappedByReturns() {

	   List<N> results = new ArrayList<N>(3);
	   results.add( createText("\n") );
	   results.add(getElementNode() );
	   results.add( createText("\n") );

	   return results;
   }

   protected N createText(String text) {
	   NodeFactory<N> nodeFact = getNodeFactory();
	   return nodeFact.createText(text);
   }

   /**
    * Method getDocument
    *
    * @return the Document where this element is contained. 
    * @deprecated New clients should use {@link #getModel()} and/or 
    * {@link #getElementNode()}; code is here because of existing code,  
    * ex. references to (also deprecated) Transforms(XMLSignature) 
    */ 
   public Document getDocument() {//issue 15
      return (Document) getDocumentNode(); 
   } 
   
   /**
    * Method getBaseURI
    *
    * @return the base uri of the namespace of this element
    */
   public String getBaseURI() {
      return this._baseURI;
   }
   
   /**
    * Method guaranteeThatElementInCorrectSpace
    *
    * @throws XMLSecurityException
    */
   void guaranteeThatElementInCorrectSpace()
           throws XMLSecurityException {
	  
	   String expectedLocalName = this.getBaseLocalName();
	      String expectedNamespaceUri = this.getBaseNamespace();
	      
	      String actualLocalName = _model.getLocalName(getElementNode());
	      String actualNamespaceUri = _model.getNamespaceURI(getElementNode());
	      
	      if(!expectedNamespaceUri.equals(actualNamespaceUri) && !expectedLocalName.equals(actualLocalName)) {      
	         Object exArgs[] = { actualNamespaceUri +":"+ actualLocalName, 
	           expectedNamespaceUri +":"+ expectedLocalName};
	         throw new XMLSecurityException("xml.WrongElement", exArgs);
	      }
      
   }

   /**
    * Method setVal
    *
    * @param bi
    * @param localname
    */
   public void addBigIntegerElement(BigInteger bi, String localname) {

      if (bi != null) {
    	  NodeFactory<N> factory = getNodeFactory();
         N e = XMLUtils.createElementInSignatureSpace(factory,
                        localname);

         Base64.fillElementWithBigInteger(_model, e, bi);
         appendSelf(e);
         addReturnToSelf();
      }
   }

	protected void addReturnToSelf() {
		XMLUtils.addReturnToElement( _model, getElementNode());
	}

   /**
    * Method addBase64Element
    *
    * @param bytes
    * @param localname
    */
   public void addBase64Element(byte[] bytes, String localname) {

      if (bytes != null) {

         N e = Base64.encodeToElement(_model, getNodeFactory(), localname, bytes);

         appendSelf(e);
         if (!XMLUtils.ignoreLineBreaks()) {
            appendSelf(createText("\n"));
         }
      }
   }

   /**
    * Method addTextElement
    *
    * @param text
    * @param localname
    */
   public void addTextElement(String text, String localname) {

      N e = XMLUtils.createElementInSignatureSpace(getNodeFactory(), localname);
      N t = createText(text);

      appendOther(e, t);
      appendSelf(e);
      addReturnToSelf();
   }

   /**
    * Method addBase64Text
    *
    * @param bytes
    */
   public void addBase64Text(byte[] bytes) {

      if (bytes != null) {
         N t = XMLUtils.ignoreLineBreaks() 
             ? createText(Base64.encode(bytes))
             : createText("\n" + Base64.encode(bytes) + "\n");
         appendSelf(t);
      }
   }

   protected void appendSelf(N toAppend) {
	   _model.appendChild(getElementNode(), toAppend);
   }
   
   protected void appendOther(N parent, N toAppend) {
	   _model.appendChild(parent, toAppend);
   }
   
   /**
    * Method addText
    *
    * @param text
    */
   public void addText(String text) {

      if (text != null) {
         N t = createText(text);

         appendSelf(t);
      }
   }

   /**
    * Method getVal
    *
    * @param localname
    * @param namespace
    * @return The big integer contained in the given element
 * @throws Base64DecodingException
    */
   public BigInteger getBigIntegerFromChildElement(
           String localname, String namespace) throws Base64DecodingException {
   	    
   		return Base64.decodeBigIntegerFromText(_model,
   				XMLUtils.selectNodeText(_model, getFirstChild(),
   						namespace,localname,0));

   }

   /**
    * Method getTextFromChildElement
    *
    * @param localname
    * @param namespace
    * @return the Text of the textNode
    */
   public String getTextFromChildElement(String localname, String namespace) {

       N textParent = XMLUtils.selectNode(_model,
               getFirstChild(),
               namespace,
               localname,
               0);
       
       N textChild = _model.getFirstChild(textParent);
       StringBuffer text = new StringBuffer();

       while (textChild != null) {
           if (_model.getNodeKind(textChild) == NodeKind.TEXT) {
               text.append( _model.getStringValue(textChild) );
           }
           textChild = _model.getNextSibling(textChild);
       }
       
       return text.toString(); 
   }

   /**
    * Method getBytesFromTextChild
    *
    * @return The base64 bytes from the text children of this element
    * @throws XMLSecurityException
    */
   public byte[] getBytesFromTextChild() throws XMLSecurityException {
      return Base64.decode(getTextFromTextChild() );
   }

   /**
    * Method getTextFromTextChild
    *
    * @return the Text obtained by concatenating all the text nodes of this 
    *    element
    */
   public String getTextFromTextChild() {
      return XMLUtils.getFullTextChildrenFromElement(_model, getElementNode() );
   }

   /**
    * Method length
    *
    * @param namespace
    * @param localname
    * @return the number of elements {namespace}:localname under this element
    */
   public int length(String namespace, String localname) {
   	    int number=0;
   	    
   	    Iterator<N> iter = _model.getChildElementsByName(getElementNode(), namespace, localname).iterator();
   	    while (iter.hasNext()) {
   	    	iter.next();
   	    	number++;
   	    }
   	    return number;
     }

   /**
    * Adds an xmlns: definition to the Element. This can be called as follows:
    *
    * <PRE>
    * // set namespace with ds prefix
    * xpathContainer.setXPathNamespaceContext("ds", "http://www.w3.org/2000/09/xmldsig#");
    * xpathContainer.setXPathNamespaceContext("xmlns:ds", "http://www.w3.org/2000/09/xmldsig#");
    * </PRE>
    *
    * @param prefix
    * @param uri
    * @throws XMLSecurityException
    */
   public void setXPathNamespaceContext(String prefix, String uri)
           throws XMLSecurityException {

      if ((prefix == null) || (prefix.length() == 0)) {
       throw new XMLSecurityException("defaultNamespaceCannotBeSetHere");
      } else if (prefix.equals("xmlns")) {
        throw new XMLSecurityException("defaultNamespaceCannotBeSetHere");
      } else if (prefix.startsWith("xmlns:")) {
         prefix = prefix.substring(6);	// skip xmlns:
      }
      
      NamespaceBinding found = null;
      
      for (NamespaceBinding nsBinding : _model.getNamespaceBindings( getElementNode() )) {
    	  if (nsBinding.getPrefix().equals(prefix)) {
    		  found = nsBinding;
    		  break;
    	  }
      }
      
      if (found != null && !found.getNamespaceURI().equals(uri)) {
          Object exArgs[] = { prefix,
                  found.getNamespaceURI() };

          throw new XMLSecurityException("namespacePrefixAlreadyUsedByOtherURI",
                             exArgs);
    	  
      }
      else {
    	  _model.insertNamespace(getElementNode(), prefix, uri);
      }
   }

   /** Field _prefixMappings */
   static HashMap<String, String> _prefixMappings = new HashMap<String, String>();
   static HashMap<String, String> _prefixMappingsBindings = new HashMap<String, String>();

    /**
     * Method setDefaultPrefix
     *
     * @param namespace
     * @param prefix
     * @throws XMLSecurityException
     */
    public static void setDefaultPrefix(String namespace, String prefix)
        throws XMLSecurityException {
    
	if (ElementProxy._prefixMappings.containsValue(prefix)) {
        
	    Object storedNamespace=ElementProxy._prefixMappings.get(namespace);
            if (!storedNamespace.equals(prefix)) {
         	Object exArgs[] = { prefix, namespace, storedNamespace };

         	throw new XMLSecurityException("prefix.AlreadyAssigned", exArgs);
            }
        }
   	if (Constants.SignatureSpecNS.equals(namespace)) {
   	    XMLUtils.dsPrefix=prefix;
   	}
   	if (EncryptionConstants.EncryptionSpecNS.equals(namespace)) {
   	    XMLUtils.xencPrefix=prefix;
   	}
        ElementProxy._prefixMappings.put(namespace, prefix.intern());
	if (prefix.length() == 0) {
            ElementProxy._prefixMappingsBindings.put(namespace, "xmlns");
	} else {
            ElementProxy._prefixMappingsBindings.put(namespace, ("xmlns:"+prefix).intern());
	}
   }

    /**
     * Method getDefaultPrefix
     *
     * @param namespace
     * @return the default prefix bind to this element.
     */
    public static String getDefaultPrefix(String namespace) {
        return ElementProxy._prefixMappings.get(namespace);
    }

    public static String getDefaultPrefixBindings(String namespace) {
	return ElementProxy._prefixMappingsBindings.get(namespace);
    }
    
    /**
     * <p>Returns the XML element node wrapped by this "element proxy".
     *  
     * @return The wrapped element
     * 
     * @see #setElementNode(Object)
     */
    public N getElementNode() {
    	return _wrappedElement;
    }

    /**
     * New value for the wrapped XML element that this object is a proxy for.
     * 
     * @param elem	New element
     * 
     * @see #getWrappedElement()
     */
	protected void setElementNode(N elem) {
    	_wrappedElement = elem;
    }
    
    /**
     * This method exists as a somewhat bizarre work-around to let existing
     * extensions of the ElementProxy class to continue operating by using
     * the _doc member directly.
     * 
     * <p>However, every new implementation should use this method to get
     * the wrapped document, so that it can first synchronize the two before use.
     * </p>
     * 
     * @return The wrapped document
     */
	protected N getDocumentNode() {
		if (_wrappedDoc == null) {
			_wrappedDoc = _model.getRoot(_wrappedElement);
		}
    	return _wrappedDoc;
    }
    
    /**
     * Set a new value for the wrapped document that this object is a proxy for.
     * 
     * @param doc New document object being wrapped.
     * 
     * @see #getWrappedDocument()
     */
	protected void setDocumentNode(N doc) {
    	_wrappedDoc = doc;
    }
    
    protected String getLocalAttribute(String attrName) {
        return _model.getAttributeStringValue( getElementNode(), "", attrName);
    }
    
    protected void setLocalAttribute(String attrName, String value) {
    	
    	DomCompatibility.setAttribute(_model, getElementNode(), "", attrName, "", value);
    }
    
    protected N getFirstChild() {
    	return _model.getFirstChild(getElementNode());
    }
    
    protected NodeFactory<N> getNodeFactory() {
    	if (_nodeFactory == null) {
    		N elem = getElementNode();
    		N refNode = elem != null ? elem : _wrappedDoc;
    		_nodeFactory = _model.getFactory(refNode);
    	}
    	
    	return _nodeFactory;
    }
}
