package org.apache.xml.security.utils;

import javax.xml.parsers.DocumentBuilderFactory;

import org.genxdm.Model;
import org.genxdm.io.DocumentHandlerFactory;
import org.genxdm.mutable.MutableModel;
import org.genxdm.bridge.dom.DomDocumentHandlerFactory;
import org.genxdm.bridge.dom.DomModelMutable;
import org.w3c.dom.Node;

/**
 * This provides the context for using XML within the security library.
 * 
 * @param <N>
 */
public class XmlContext<N> {

	public XmlContext(DocumentHandlerFactory<N> docHandlerFactory, MutableModel<N> model) {
		this.model = model;
		this.mutableModel = model;
		this.docHandlerFactory = docHandlerFactory;	}
	
	/**
	 * This member can be used for parsing documents.
	 */
	public final DocumentHandlerFactory<N> docHandlerFactory;
	
	/**
	 * Model to be used for reading of XML.
	 */
	public final Model<N> model;

	/**
	 * Model to be used for mutating XML.
	 */
	public final MutableModel<N> mutableModel;
	
	//=========================================================================
	// Static methods to support backwards compatibility with DOM APIs.
	//=========================================================================
	
	private static final DomModelMutable sm_domBr = new DomModelMutable();

	public static MutableModel<Node> getDomModel() {
		return XmlContext.sm_domBr;
	}
	
	private static DocumentBuilderFactory sm_dbf;
	
	static {
		sm_dbf = DocumentBuilderFactory.newInstance();
	    sm_dbf.setValidating(false);        
	    sm_dbf.setNamespaceAware(true);
	}

	private static final XmlContext<Node> sm_domCtx = new XmlContext<Node>(
		new DomDocumentHandlerFactory(sm_dbf), sm_domBr);

	public static XmlContext<Node> getContext() {
		return sm_domCtx;
	}
}
