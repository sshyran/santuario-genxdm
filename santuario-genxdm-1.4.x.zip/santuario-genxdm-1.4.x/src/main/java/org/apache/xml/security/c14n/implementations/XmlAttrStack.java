package org.apache.xml.security.c14n.implementations;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.genxdm.Model;

class XmlAttrStack {
	int currentLevel = 0;
	int lastlevel = 0;
	XmlsStackElement cur;

	static class XmlsStackElement {
		int level;
		boolean rendered = false;
		List<AttrInfo> nodes = new ArrayList<AttrInfo>();
	};

	List<XmlsStackElement> levels = new ArrayList<XmlsStackElement>();

	void push(int level) {
		currentLevel = level;
		if (currentLevel == -1)
			return;
		cur = null;
		while (lastlevel >= currentLevel) {
			levels.remove(levels.size() - 1);
			if (levels.size() == 0) {
				lastlevel = 0;
				return;
			}
			lastlevel = levels.get(levels.size() - 1).level;
		}
	}

	<N> void addXmlnsAttr(Model<N> model, N n) {
		if (cur == null) {
			cur = new XmlsStackElement();
			cur.level = currentLevel;
			levels.add(cur);
			lastlevel = currentLevel;
		}
		cur.nodes.add(AttrInfo.createAttribute(model, n));
	}

	<N> void getXmlnsAttr(Model<N> bridge, Collection<AttrInfo> col) {
		int size = levels.size() - 1;
		if (cur == null) {
			cur = new XmlsStackElement();
			cur.level = currentLevel;
			lastlevel = currentLevel;
			levels.add(cur);
		}
		boolean parentRendered = false;
		XmlsStackElement e = null;
		if (size == -1) {
			parentRendered = true;
		} else {
			e = levels.get(size);
			if (e.rendered && e.level + 1 == currentLevel)
				parentRendered = true;

		}
		if (parentRendered) {
			col.addAll(cur.nodes);
			cur.rendered = true;
			return;
		}

		Map<String, AttrInfo> loa = new HashMap<String, AttrInfo>();
		for (; size >= 0; size--) {
			e = levels.get(size);
			for (AttrInfo n : e.nodes) {
				String name = n.getLocalName();
				if (!loa.containsKey(name))
					loa.put(name, n);
			}
			// if (e.rendered)
			// break;

		}
		;
		// cur.nodes.clear();
		// cur.nodes.addAll(loa.values());
		cur.rendered = true;
		col.addAll(loa.values());
	}

}