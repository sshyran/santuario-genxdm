/*
 * Copyright  1999-2010 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.utils;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.WeakHashMap;

import org.genxdm.NodeKind;
import org.genxdm.Model;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 * Purpose of this class is to enable the XML Parser to keep track of ID
 * attributes. This is done by 'registering' attributes of type ID at the
 * IdResolver. This is necessary if we create a document from scratch and we
 * sign some resources with a URI using a fragment identifier...
 * <BR />
 * The problem is that if you do not validate a document, you cannot use the
 * <CODE>getElementByID</CODE> functionality. So this modules uses some implicit
 * knowledge on selected Schemas and DTDs to pick the right Element for a given
 * ID: We know that all <CODE>@Id</CODE> attributes in an Element from the XML
 * Signature namespace are of type <CODE>ID</CODE>.
 *
 * @author $Author: coheigea $
 * @see <A HREF="http://www.xml.com/lpt/a/2001/11/07/id.html">"Identity Crisis" on xml.com</A>
 */
public class IdResolver {

    /** {@link org.apache.commons.logging} logging facility */
    private static org.apache.commons.logging.Log log =
        org.apache.commons.logging.LogFactory.getLog(IdResolver.class.getName());

    private static WeakHashMap<Object, WeakHashMap<String, WeakReference<Object>>> docMap =
    	new WeakHashMap<Object, WeakHashMap<String, WeakReference<Object> >>();
    
    /**
     * Constructor IdResolver
     *
     */
    private IdResolver() {
       // we don't allow instantiation
    }

    /**
     * Method registerElementById
     *
     * @param element the element to register
     * @param idValue the value of the ID attribute
     * 
     * @deprecated New clients should use {@link #registerElementById(Model, Object, Object, String)}
     */
    public static void registerElementById(Element element, String idValue) {
    	registerElementById(XmlContext.getDomModel(), element.getOwnerDocument(), element, idValue);
    }

    /**
     * Method registerElementById
     *
     * @param element the element to register
     * @param idValue the value of the ID attribute
     */
    public static <N> void registerElementById(Model<N> model, N doc, N element, String idValue) {
    	if (doc == null) {
        	//N doc = model.getRoot(element);
        	doc = model.getRoot(element);
        	if (element instanceof Element) {
        		Document domDoc = ((Element) element).getOwnerDocument();
        		if (domDoc != doc) {
        			throw new IllegalStateException("Got a scenario where owner != root");
        		}
        	}
    	}
        WeakHashMap<String, WeakReference<Object> > elementMap;
        synchronized (docMap) {
            elementMap = docMap.get(doc);
            if (elementMap == null) {
                elementMap = new WeakHashMap<String, WeakReference<Object> >();
                docMap.put(doc, elementMap);
            }
        }
        elementMap.put(idValue, new WeakReference<Object>(element));
    }
    
    /**
     * Force a removal of a registered document. Any element id associated
     * with this document will be removed from the weak reference map.
     * 
     * @param doc the DOM document that is to be removed from the map.
     */
    public static void unregisterDocument(Document doc) {
        synchronized (docMap) {
            docMap.remove(doc);
        }
    }

    /**
     * Method registerElementById
     *
     * @param element the element to register
     * @param id the ID attribute
     * 
     * @deprecated See {@link #registerElementById(Model, Object, Object, String)}
     */
    public static void registerElementById(Element element, Attr id) {
        IdResolver.registerElementById(element, id.getNodeValue());
    }

    /**
     * Method getElementById
     *
     * @param doc the document
     * @param id the value of the ID 
     * @return the element obtained by the id, or null if it is not found.
     * 
     * @deprecated See {@link #getElementById(Model, Object, String)}
     */
    public static Element getElementById(Document doc, String id) {
    	return (Element) getElementById(XmlContext.getDomModel(), doc, id);
    }
   

    /**
     * Method getElementById
     *
     * @param doc the document
     * @param id the value of the ID 
     * @return the element obtained by the id, or null if it is not found.
     */
    public static <N> N getElementById(MutableModel<N> model, N doc, String id) {

        N result = IdResolver.getElementByIdType(model, doc, id);

        if (result != null) {
            log.debug(
            "I could find an Element using the simple getElementByIdType method: "
            + XMLUtils.getTagName(model, result) );

            return result;
        }

        result = IdResolver.getElementByIdUsingDOM(model, doc, id);

        if (result != null) {
            log.debug(
             "I could find an Element using the simple getElementByIdUsingDOM method: "
            + XMLUtils.getTagName(model, result));

            return result;
        }
        // this must be done so that Xalan can catch ALL namespaces
        //XMLUtils.circumventBug2650(doc);
        result = IdResolver.getElementBySearching(model, doc, id);

        if (result != null) {
        	String idVal = model.getStringValue(result);
        	IdResolver.registerElementById(model, doc, result, idVal);

            return result;
        }

        return null;
    }
   

    /**
     * Method getElementByIdUsingDOM
     *
     * @param doc the document
     * @param id the value of the ID
     * @return the element obtained by the id, or null if it is not found.
     */
    private static <N> N getElementByIdUsingDOM(Model<N> model, N doc, String id) {
        if (log.isDebugEnabled())
       	    log.debug("getElementByIdUsingDOM() Search for ID " + id);
        return model.getElementById(doc, id);
    }

    /**
     * Method getElementByIdType
     *
     * @param doc the document
     * @param id the value of the ID
     * @return the element obtained by the id, or null if it is not found.
     */
    private static <N> N getElementByIdType(Model<N> model, N doc, String id) {
        if (log.isDebugEnabled())
	    log.debug("getElementByIdType() Search for ID " + id);
        WeakHashMap<String, WeakReference<Object> > elementMap;
        synchronized (docMap) {
            elementMap = docMap.get(doc);
        }
        if (elementMap != null) {
            WeakReference<Object> weakReference = elementMap.get(id);
            if (weakReference != null) {
            	// this cast should be OK, in that first the "doc" object is used to
            	// look up the map to elements, the particular underlying tree implementation
            	// is almost certainly a 1-1 correlation with the implementation of the Model
            	// interface
            	@SuppressWarnings("unchecked")
				N result = (N) weakReference.get(); 
                return result;   
            }
        }
        return null;
    }
    
    private static List<String> names;
    private static int namesLength;
    static {
	String namespaces[]={ 
	    Constants.SignatureSpecNS,
	    EncryptionConstants.EncryptionSpecNS,
	    "http://schemas.xmlsoap.org/soap/security/2000-12",
	    "http://www.w3.org/2002/03/xkms#",
	    "urn:oasis:names:tc:SAML:1.0:assertion",
	    "urn:oasis:names:tc:SAML:1.0:protocol"
	};
	names = Arrays.asList(namespaces);
	namesLength = names.size();
    }
   

    private static <N> N getElementBySearching(Model<N> model, N root, String id) {
        List<N> els = new ArrayList<N>(namesLength + 1);
        for (int i = 0 ; i <= namesLength ; i++) {
        	els.add(null);
        }
        
        // TODO - the logic here is silly, in that to find a single element, we
        // keep an array to get a single answer.
        getEl(model, root, id, els);
        for (int i=0;i<els.size();i++) {
	    	if (els.get(i) != null) {
	    		return els.get(i);
	    	}
		}
		return null;
    }

    private static <N> void getEl(Model<N> model, N currentNode,String id, List<N> els) {
    	N sibling = null;
    	N parentNode = null;    	
    	do {
    		switch (model.getNodeKind(currentNode) ) {    		
    		//case Node.DOCUMENT_FRAGMENT_NODE :
    		case DOCUMENT :
    			sibling = model.getFirstChild(currentNode);
    			break;
    			
    			
    		case ELEMENT :
    			N currentElement = currentNode;
    			if (isElement(model, currentElement, id, els)==1)
    				return;
    			sibling= model.getFirstChild(currentNode); 
    			if (sibling==null) {
    			    if (parentNode != null) {
       			    		sibling= model.getNextSibling(currentNode);
				    }
    			} else {
    				parentNode=currentElement;
    			}
    			break;
    	} while (sibling==null  && parentNode!=null) {    		      		      			
    			sibling=model.getNextSibling(parentNode);
    			parentNode=model.getParent(parentNode);   
    			if (parentNode != null && NodeKind.ELEMENT != model.getNodeKind(parentNode)) {
    				parentNode=null;
    			}    			
    		}      
    		if (sibling==null)
    			return;
    		currentNode=sibling;      
    		sibling=model.getNextSibling(currentNode);  
    	} while(true);

    }

    public static <N> int isElement(Model<N> model, N el, String id, List<N> els) {
    	if (!model.hasAttributes(el)) {
    		return 0;
    	}
    	int elementIndex=names.indexOf(model.getNamespaceURI(el));
	    elementIndex=(elementIndex<0) ? namesLength : elementIndex;
    	
    	for (N attr : model.getAttributeAxis(el, false)) {
    		
    		String s= model.getNamespaceURI(attr);
    		
		    int index = (s == null) ? elementIndex : names.indexOf(s);
		    index=(index<0) ? namesLength : index;
		    String name=model.getLocalName(attr);
		    // With version 1.4.4, XML Security library added lines checking for null name.
		    // However, not needed with GenXDM, spec'd not to return null.
		    if (name.length()>2)
		    	continue;
		    String value=model.getStringValue(attr);
		    if (name.charAt(0)=='I') {
		    	char ch=name.charAt(1);		    
		    	if (ch=='d' && value.equals(id)) {				   		    
		    		els.set(index, el);
		        	if (index==0) {
		        		return 1;
		        	}
		    	} else if (ch=='D' &&value.endsWith(id)) {
		    		if (index!=3) {
			            index=namesLength;
			        }
		    		els.set(index, el);
		    	}
		    } else if ( "id".equals(name) && value.equals(id) ) {
		    	if (index!=2) {
		    		index=namesLength;
		        }
		    	els.set(index, el);
		    } 
    	}
    	
    	//For an element namespace search for importants
    	if ((elementIndex==3)&&(
		    model.getAttributeStringValue(el, "", "OriginalRequestID").equals(id) ||
		    model.getAttributeStringValue(el, "", "RequestID").equals(id) ||
		    model.getAttributeStringValue(el, "", "ResponseID").equals(id))) {
		    els.set(3, el);				   		    
    	} else if ((elementIndex==4)&&(
    		id.equals(model.getAttributeStringValue(el, "", "AssertionID"))) ) {
		    els.set(4, el);				   
    	} else if ((elementIndex==5)&&(
    		model.getAttributeStringValue(el, "", "RequestID").equals(id) ||
    		model.getAttributeStringValue(el, "", "ResponseID").equals(id))) {
		    els.set(5, el);				   
		 }		
    	return 0;
    }
}
