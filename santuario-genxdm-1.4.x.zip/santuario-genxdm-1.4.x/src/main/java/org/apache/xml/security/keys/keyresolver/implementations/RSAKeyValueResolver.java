
/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.keys.keyresolver.implementations;



import java.security.PublicKey;
import java.security.cert.X509Certificate;


import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.keyvalues.RSAKeyValue;
import org.apache.xml.security.keys.keyresolver.GxKeyResolverSpi;
import org.apache.xml.security.keys.storage.StorageResolver;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;


/**
 *
 * @author $Author: raul $
 */
public class RSAKeyValueResolver extends GxKeyResolverSpi {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(
                        RSAKeyValueResolver.class.getName());

   /** Field _rsaKeyElement */
   

   /** @inheritDoc */
   public <N> PublicKey engineLookupAndResolvePublicKey(XmlContext<N> ctx,
           N element, String BaseURI, StorageResolver storage) {
	   if (log.isDebugEnabled())
		 	log.debug("Can I resolve " + ctx.model.getLocalName(element));
      if (element == null) {
         return null;
      }

	  boolean isKeyValue = XMLUtils.elementIsInSignatureSpace(ctx.model, element,
		                              Constants._TAG_KEYVALUE);
	  N rsaKeyElement=null;
	  if (isKeyValue) {
		  	rsaKeyElement = ctx.model.getFirstChildElementByName(element,
		  			Constants.SignatureSpecNS, Constants._TAG_RSAKEYVALUE);
	  } else if (XMLUtils.elementIsInSignatureSpace(ctx.model, element,
              Constants._TAG_RSAKEYVALUE)) {
         // this trick is needed to allow the RetrievalMethodResolver to eat a
         // ds:RSAKeyValue directly (without KeyValue)
         rsaKeyElement = element;		  
	  }

      
      if (rsaKeyElement == null) {
         return null;         
      }

      try {
         RSAKeyValue<N> rsaKeyValue = new RSAKeyValue<N>(ctx.mutableModel, rsaKeyElement,
                                                   BaseURI);

         return rsaKeyValue.getPublicKey();
      } catch (XMLSecurityException ex) {
         log.debug("XMLSecurityException", ex);
      }

      return null;
   }

   /** @inheritDoc */
   public <N> X509Certificate engineLookupResolveX509Certificate(XmlContext<N> ctx,
           N element, String BaseURI, StorageResolver storage) {
      return null;
   }

   /** @inheritDoc */
   public <N> javax.crypto.SecretKey engineLookupAndResolveSecretKey(XmlContext<N> ctx,
           N element, String BaseURI, StorageResolver storage) {
      return null;
   }
}
