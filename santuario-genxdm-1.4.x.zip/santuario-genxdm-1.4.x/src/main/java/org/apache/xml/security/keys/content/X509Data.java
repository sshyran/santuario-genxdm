/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.keys.content;



import java.math.BigInteger;
import java.security.cert.X509Certificate;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.x509.XMLX509CRL;
import org.apache.xml.security.keys.content.x509.XMLX509Certificate;
import org.apache.xml.security.keys.content.x509.XMLX509IssuerSerial;
import org.apache.xml.security.keys.content.x509.XMLX509SKI;
import org.apache.xml.security.keys.content.x509.XMLX509SubjectName;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.NodeKind;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


/**
 *
 * @author $Author: raul $
 */
public class X509Data<N> extends SignatureElementProxy<N> implements KeyInfoContent {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(X509Data.class.getName());

   /**
    * Constructor X509Data
    *
    * @param doc
    * 
    * @deprecated New clients should use {@link #X509Data(XmlContext, Object)}
    */
   @SuppressWarnings("unchecked")
   public X509Data(Document doc) {
	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc);
   }

   /**
    * Constructor X509Data
    *
    * @param doc
    */
   public X509Data(MutableModel<N> model, N doc) {

      super(model, doc);
      addReturnToSelf();
   }

   /**
    * Constructor X509Data
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    * 
    * @deprecated New clients should use {@link #X509Data(XmlContext, Object, String)}
    */
   @SuppressWarnings("unchecked")
   public X509Data(Element element, String BaseURI)
           throws XMLSecurityException {

	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) element, BaseURI);
   }

   /**
    * Constructor X509Data
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public X509Data(MutableModel<N> model, N element, String BaseURI)
           throws XMLSecurityException {

      super(model, element, BaseURI);
      N aChild = _model.getFirstChildElement(getElementNode());
      if (aChild == null) {
          /* No Elements found */
          Object exArgs[] = { "Elements", Constants._TAG_X509DATA };
          throw new XMLSecurityException("xml.WrongContent", exArgs);
      }
   }

   /**
    * Method addIssuerSerial
    *
    * @param X509IssuerName
    * @param X509SerialNumber
    */
   public void addIssuerSerial(String X509IssuerName,
                               BigInteger X509SerialNumber) {
      this.add(new XMLX509IssuerSerial<N>(_model, getDocumentNode(), X509IssuerName,
                                       X509SerialNumber));
   }

   /**
    * Method addIssuerSerial
    *
    * @param X509IssuerName
    * @param X509SerialNumber
    */
   public void addIssuerSerial(String X509IssuerName, String X509SerialNumber) {
      this.add(new XMLX509IssuerSerial<N>(_model, getDocumentNode(), X509IssuerName,
                                       X509SerialNumber));
   }

   /**
    * Method addIssuerSerial
    *
    * @param X509IssuerName
    * @param X509SerialNumber
    */
   public void addIssuerSerial(String X509IssuerName, int X509SerialNumber) {
      this.add(new XMLX509IssuerSerial<N>(_model, getDocumentNode(), X509IssuerName,
                                       X509SerialNumber));
   }

   /**
    * Method add
    *
    * @param xmlX509IssuerSerial
    */
   public void add(XMLX509IssuerSerial<N> xmlX509IssuerSerial) {

	   	appendSelf(xmlX509IssuerSerial.getElementNode());
         addReturnToSelf();
   }

   /**
    * Method addSKI
    *
    * @param skiBytes
    */
   public void addSKI(byte[] skiBytes) {
      this.add(new XMLX509SKI<N>(_model, getDocumentNode(), skiBytes));
   }

   /**
    * Method addSKI
    *
    * @param x509certificate
    * @throws XMLSecurityException
    */
   public void addSKI(X509Certificate x509certificate)
           throws XMLSecurityException {
      this.add(new XMLX509SKI<N>(_model, getDocumentNode(), x509certificate));
   }

   /**
    * Method add
    *
    * @param xmlX509SKI
    */
   public void add(XMLX509SKI<N> xmlX509SKI) {
	   	appendSelf(xmlX509SKI.getElementNode());
         addReturnToSelf();
   }

   /**
    * Method addSubjectName
    *
    * @param subjectName
    */
   public void addSubjectName(String subjectName) {
      this.add(new XMLX509SubjectName<N>(_model, getDocumentNode(), subjectName, false));
   }

   /**
    * Method addSubjectName
    *
    * @param x509certificate
    */
   public void addSubjectName(X509Certificate x509certificate) {
      this.add(new XMLX509SubjectName<N>(_model, getDocumentNode(), x509certificate));
   }

   /**
    * Method add
    *
    * @param xmlX509SubjectName
    */
   public void add(XMLX509SubjectName<N> xmlX509SubjectName) {
	   appendSelf(xmlX509SubjectName.getElementNode());
       addReturnToSelf();
   }

   /**
    * Method addCertificate
    *
    * @param x509certificate
    * @throws XMLSecurityException
    */
   public void addCertificate(X509Certificate x509certificate)
           throws XMLSecurityException {
      this.add(new XMLX509Certificate<N>(_model, getDocumentNode(), x509certificate));
   }

   /**
    * Method addCertificate
    *
    * @param x509certificateBytes
    */
   public void addCertificate(byte[] x509certificateBytes) {
      this.add(new XMLX509Certificate<N>(_model, getDocumentNode(), x509certificateBytes));
   }

   /**
    * Method add
    *
    * @param xmlX509Certificate
    */
   	public void add(XMLX509Certificate<N> xmlX509Certificate) {
		appendSelf(xmlX509Certificate.getElementNode());
        addReturnToSelf();
   }

   /**
    * Method addCRL
    *
    * @param crlBytes
    */
   public void addCRL(byte[] crlBytes) {
      this.add(new XMLX509CRL<N>(_model, getDocumentNode(), crlBytes));
   }

   /**
    * Method add
    *
    * @param xmlX509CRL
    */
   public void add(XMLX509CRL<N> xmlX509CRL) {
	   	appendSelf(xmlX509CRL.getElementNode());
         addReturnToSelf();
   }

   /**
    * Method addUnknownElement
    *
    * @param element
    */
   public void addUnknownElement(N element) {
	   	appendSelf(element);
         addReturnToSelf();
   }

   /**
    * Method lengthIssuerSerial
    *
    * @return the number of IssuerSerial elements in this X509Data
    */
   public int lengthIssuerSerial() {
      return this.length(Constants.SignatureSpecNS,
                         Constants._TAG_X509ISSUERSERIAL);
   }

   /**
    * Method lengthSKI
    *
    * @return the number of SKI elements in this X509Data
    */
   public int lengthSKI() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_X509SKI);
   }

   /**
    * Method lengthSubjectName
    *
    * @return the number of SubjectName elements in this X509Data
    */
   public int lengthSubjectName() {
      return this.length(Constants.SignatureSpecNS,
                         Constants._TAG_X509SUBJECTNAME);
   }

   /**
    * Method lengthCertificate
    *
    * @return the number of Certificate elements in this X509Data
    */
   public int lengthCertificate() {
      return this.length(Constants.SignatureSpecNS,
                         Constants._TAG_X509CERTIFICATE);
   }

   /**
    * Method lengthCRL
    *
    * @return the number of CRL elements in this X509Data
    */
   public int lengthCRL() {
      return this.length(Constants.SignatureSpecNS, Constants._TAG_X509CRL);
   }

   /**
    * Method lengthUnknownElement
    *
    * @return the number of UnknownElement elements in this X509Data
    */
   public int lengthUnknownElement() {
      
      int result = 0;
      N n = getFirstChild();
      while (n!=null){         

         if (( _model.getNodeKind(n) == NodeKind.ELEMENT)
                 &&! _model.getNamespaceURI(n).equals(Constants.SignatureSpecNS)) {
            result += 1;
         }
         n= _model.getNextSibling(n);
      }
      
      return result;
   }

   /**
    * Method itemIssuerSerial
    *
    * @param i
    * @return the X509IssuerSerial, null if not present
    * @throws XMLSecurityException
    */
   public XMLX509IssuerSerial<N> itemIssuerSerial(int i)
           throws XMLSecurityException {

      N e =
        XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                       Constants._TAG_X509ISSUERSERIAL,i);

      if (e != null) {
         return new XMLX509IssuerSerial<N>(_model, e, this._baseURI);
      } 
      return null;
   }

   /**
    * Method itemSKI
    *
    * @param i
    * @return the X509SKI, null if not present
    * @throws XMLSecurityException
    */
   public XMLX509SKI<N> itemSKI(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_X509SKI,i);

      if (e != null) {
         return new XMLX509SKI<N>(_model, e, this._baseURI);
      }
      return null;
   }

   /**
    * Method itemSubjectName
    *
    * @param i
    * @return the X509SubjectName, null if not present
    * @throws XMLSecurityException
    */
   public XMLX509SubjectName<N> itemSubjectName(int i)
           throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_X509SUBJECTNAME,i);

      if (e != null) {
         return new XMLX509SubjectName<N>(_model, e, this._baseURI);
      } 
       return null;
   }

   /**
    * Method itemCertificate
    *
    * @param i
    * @return the X509Certifacte, null if not present
    * @throws XMLSecurityException
    */
   public XMLX509Certificate<N> itemCertificate(int i)
           throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_X509CERTIFICATE,i);

      if (e != null) {
         return new XMLX509Certificate<N>(_model, e, this._baseURI);
      } 
       return null;
   }

   /**
    * Method itemCRL
    *
    * @param i
    * @return the X509CRL, null if not present
    * @throws XMLSecurityException
    */
   public XMLX509CRL<N> itemCRL(int i) throws XMLSecurityException {

      N e = XMLUtils.findNthDigSigChild(_model, getElementNode(),
                                                Constants._TAG_X509CRL,i);

      if (e != null) {
         return new XMLX509CRL<N>(_model, e, this._baseURI);
      } 
       return null;
   }

   /**
    * Method itemUnknownElement
    *
    * @param i
    * @return the Unknown Element at i
    * TODO implement
    **/
   public Element itemUnknownElement(int i) {
	  log.debug("itemUnknownElement not implemented:"+i);
      return null;
   }

   /**
    * Method containsIssuerSerial
    *
    * @return true if this X509Data contains a IssuerSerial
    */
   public boolean containsIssuerSerial() {
      return this.lengthIssuerSerial() > 0;
   }

   /**
    * Method containsSKI
    *
    * @return true if this X509Data contains a SKI
    */
   public boolean containsSKI() {
      return this.lengthSKI() > 0;
   }

   /**
    * Method containsSubjectName
    *
    * @return true if this X509Data contains a SubjectName
    */
   public boolean containsSubjectName() {
      return this.lengthSubjectName() > 0;
   }

   /**
    * Method containsCertificate
    *
    * @return true if this X509Data contains a Certificate
    */
   public boolean containsCertificate() {
      return this.lengthCertificate() > 0;
   }

   /**
    * Method containsCRL
    *
    * @return true if this X509Data contains a CRL
    */
   public boolean containsCRL() {
      return this.lengthCRL() > 0;
   }

   /**
    * Method containsUnknownElement
    *
    * @return true if this X509Data contains an UnknownElement
    */
   public boolean containsUnknownElement() {
      return this.lengthUnknownElement() > 0;
   }

   /** @inheritDoc */
   public String getBaseLocalName() {
      return Constants._TAG_X509DATA;
   }
}
