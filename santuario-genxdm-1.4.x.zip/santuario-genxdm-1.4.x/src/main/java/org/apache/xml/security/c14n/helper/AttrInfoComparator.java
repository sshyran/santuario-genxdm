package org.apache.xml.security.c14n.helper;

import org.apache.xml.security.c14n.implementations.AttrInfo;

public class AttrInfoComparator extends AttrCompareBase<AttrInfo> {

	private static final long serialVersionUID = 1L;
	
	public AttrInfoComparator() {
		super( new AttrInfoAccessor() );
	}
    public static class AttrInfoAccessor implements Accessor<AttrInfo> {

    	public AttrInfoAccessor() {
    	}
    	
		public String getLocalName(AttrInfo item) {
			return item.getLocalName();
		}

		public String getNamespace(AttrInfo item) {
			return item.getNamespace();
		}

		public boolean isNamespace(AttrInfo item) {
			return item.isNamespace();
		}
    	
    };
    
}
