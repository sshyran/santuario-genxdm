/*
 * Copyright 1999-2009 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.transforms;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.apache.xml.security.exceptions.AlgorithmAlreadyRegisteredException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.ClassLoaderUtils;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;
import org.genxdm.compat.DomCompatibility;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Implements the behaviour of the <code>ds:Transform</code> element.
 *
 * This <code>Transform</code>(Factory) class acts as the Factory and Proxy of
 * the implementing class that supports the functionality of <a
 * href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>a Transform
 * algorithm</a>.
 * Implements the Factory and Proxy pattern for ds:Transform algorithms.
 *
 * @author Christian Geuer-Pollmann
 * @see Transforms
 * @see TransformSpi
 */
public final class Transform<N> extends SignatureElementProxy<N> {

    /** {@link org.apache.commons.logging} logging facility */
    private static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(Transform.class.getName());

    /** Field _alreadyInitialized */
    private static boolean alreadyInitialized = false;

    /** All available Transform classes are registered here */
    private static HashMap<String, Class<TransformSpi>> transformClassHash = null;
   
    private static HashMap<String, TransformSpi> transformSpiHash = new HashMap<String, TransformSpi>();	      

    private TransformSpi transformSpi = null;

    /**
     * Constructs {@link Transform}
     *
     * @param doc the {@link Document} in which <code>Transform</code> will be 
     * placed
     * @param algorithmURI URI representation of 
     * <code>Transform algorithm</code> which will be specified as parameter of 
     * {@link #getInstance(Document, String)}, when generated. </br>
     * @param contextNodes the child node list of <code>Transform</code> element
     * @throws InvalidTransformException
     */
    @SuppressWarnings("unchecked")
	public Transform(Document doc, String algorithmURI, NodeList contextNodes)
        throws InvalidTransformException {

    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, algorithmURI, (List<N>) XMLUtils.nodeListToList(contextNodes));
    }

    /**
     * Constructs {@link Transform}
     *
     * @param doc the {@link Document} in which <code>Transform</code> will be 
     * placed
     * @param algorithmURI URI representation of 
     * <code>Transform algorithm</code> which will be specified as parameter of 
     * {@link #getInstance(Document, String)}, when generated. </br>
     * @param contextNodes the child node list of <code>Transform</code> element
     * @throws InvalidTransformException
     */
    public Transform(MutableModel<N> model, N doc, String algorithmURI, Iterable<N> contextNodes)
        throws InvalidTransformException {

        super(model, doc);

        DomCompatibility.setAttribute(model, getElementNode(), "", Constants._ATT_ALGORITHM, "", algorithmURI);

        transformSpi = getTransformSpi(algorithmURI);
        if (transformSpi == null) {
            Object exArgs[] = { algorithmURI };
            throw new InvalidTransformException(
                "signature.Transform.UnknownTransform", exArgs);
        }

        if (log.isDebugEnabled()) {
       	    log.debug("Create URI \"" + algorithmURI + "\" class \""
                   + transformSpi.getClass() + "\"");
       	    log.debug("The NodeList is " + contextNodes);
        }

        // give it to the current document
        if (contextNodes != null) {
        	for (N node : contextNodes) {
        		appendSelf( model.copyNode(node, true));
        	}
         }
    }

    /**
     * This constructor can only be called from the {@link Transforms} object,
     * so it's protected.
     *
     * @param element <code>ds:Transform</code> element
     * @param BaseURI the URI of the resource where the XML instance was stored
     * @throws InvalidTransformException
     * @throws TransformationException
     * @throws XMLSecurityException
     */
    @SuppressWarnings("unchecked")
	public Transform(Element element, String BaseURI)
        throws InvalidTransformException, TransformationException,
               XMLSecurityException {

    	this( (MutableModel<N>) XmlContext.getDomModel(), (N) element, BaseURI);
    }

    /**
     * This constructor can only be called from the {@link Transforms} object,
     * so it's protected.
     *
     * @param element <code>ds:Transform</code> element
     * @param BaseURI the URI of the resource where the XML instance was stored
     * @throws InvalidTransformException
     * @throws TransformationException
     * @throws XMLSecurityException
     */
    public Transform(MutableModel<N> model, N element, String BaseURI)
        throws InvalidTransformException, TransformationException,
               XMLSecurityException {

        super(model, element, BaseURI);

        // retrieve Algorithm Attribute from ds:Transform
        String algorithmURI = model.getAttributeStringValue(element, "", Constants._ATT_ALGORITHM);

        if (algorithmURI == null || algorithmURI.length() == 0) {
            Object exArgs[] = { Constants._ATT_ALGORITHM,
                                Constants._TAG_TRANSFORM };
            throw new TransformationException("xml.WrongContent", exArgs);
        }

     
        transformSpi = getTransformSpi(algorithmURI);
        if (transformSpi == null) {
            Object exArgs[] = { algorithmURI };
            throw new InvalidTransformException(
	        "signature.Transform.UnknownTransform", exArgs);
        }
    }

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     *
     * @param algorithmURI <code>Transform algorithm</code> URI representation, 
     * such as specified in 
     * <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>Transform algorithm </a>
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     * 
     * @deprecated New clients should use {@link #getInstance(XmlContext, Object, String)}
     */
    public static Transform<Node> getInstance(
        Document doc, String algorithmURI) throws InvalidTransformException {
        return getInstance(XmlContext.getDomModel(), doc, algorithmURI);
    }

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     *
     * @param algorithmURI <code>Transform algorithm</code> URI representation, 
     * such as specified in 
     * <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>Transform algorithm </a>
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     * 
     */
    public static <N> Transform<N > getInstance(MutableModel<N> model,
        N doc, String algorithmURI) throws InvalidTransformException {
        return getInstance(model, doc, algorithmURI, (List<N>) null);
    }

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     *
     * @param algorithmURI <code>Transform algorithm</code> URI representation, 
     * such as specified in 
     * <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>Transform algorithm </a>
     * @param contextChild the child element of <code>Transform</code> element
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     * 
     * @deprecated New clients should use {@link #getInstance(XmlContext, Object, String, Object)}
     */
    public static Transform<Node> getInstance(
        Document doc, String algorithmURI, Element contextChild)
        throws InvalidTransformException {
    	
    	return getInstance(XmlContext.getDomModel(), doc, algorithmURI, contextChild);
    }

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     *
     * @param algorithmURI <code>Transform algorithm</code> URI representation, 
     * such as specified in 
     * <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>Transform algorithm </a>
     * @param contextChild the child element of <code>Transform</code> element
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     */
    public static <N> Transform<N> getInstance(
        MutableModel<N> model, N doc, String algorithmURI, N contextChild)
        throws InvalidTransformException {

    	NodeFactory<N> factory = model.getFactory(doc);
    	List<N> nodes = null;
    	
        if (contextChild != null) {
			nodes = new ArrayList<N>();
	    	maybeAddReturn(factory, nodes);
	    	nodes.add(contextChild);
	    	maybeAddReturn(factory, nodes);
        }

        return getInstance(model, doc, algorithmURI, nodes);
    }

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     * @param ctx Context for accessing XML tree.
     * @param doc Document node that is target of the transform.
     * @param algorithmURI <code>Transform algorithm</code> URI representation, 
     * such as specified in 
     * <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>Transform algorithm </a>
     * @param contextChild the child element of <code>Transform</code> element
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     */
    public static <N> Transform<N> getInstance(
        MutableModel<N> model, N doc, NodeFactory<N> factory, String algorithmURI, N contextChild)
        throws InvalidTransformException {

    	List<N> nodes = new ArrayList<N>();
    	
    	maybeAddReturn(factory, nodes);
    	nodes.add(contextChild);
    	maybeAddReturn(factory, nodes);
    	
        return getInstance(model, doc, algorithmURI, nodes);
    }

	private static <N> void maybeAddReturn(NodeFactory<N> factory,
			List<N> nodes) {
		if (!XMLUtils.ignoreLineBreaks()) {
    		nodes.add( factory.createText("\n"));
    	}
	}

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     *
     * @param algorithmURI <code>Transform algorithm</code> URI form, such as 
     * specified in <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>
     * Transform algorithm </a>
     * @param contextNodes the child node list of <code>Transform</code> element
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     * 
     * @deprecated New clients should use {@link #getInstance(XmlContext, Object, String, List)}
     */
    public static Transform<Node> getInstance(
        Document doc, String algorithmURI, NodeList contextNodes)
        throws InvalidTransformException {
    	return getInstance(XmlContext.getDomModel(), doc, algorithmURI, XMLUtils.nodeListToList(contextNodes) );
    }

    /**
     * Generates a Transform object that implements the specified 
     * <code>Transform algorithm</code> URI.
     *
     * @param algorithmURI <code>Transform algorithm</code> URI form, such as 
     * specified in <a href=http://www.w3.org/TR/xmldsig-core/#sec-TransformAlg>
     * Transform algorithm </a>
     * @param contextNodes the child node list of <code>Transform</code> element
     * @param doc the proxy {@link Document}
     * @return <code>{@link Transform}</code> object
     * @throws InvalidTransformException
     */
    public static <N> Transform<N> getInstance(
        MutableModel<N> model, N doc, String algorithmURI, Iterable<N> contextNodes)
        throws InvalidTransformException {
        return new Transform<N>(model, doc, algorithmURI, contextNodes);
    }

    /**
     * Initalizes for this {@link Transform}.
     */
    public static void init() {
        if (!alreadyInitialized) {
            transformClassHash = new HashMap<String, Class<TransformSpi>>(10);
            alreadyInitialized = true;
        }
    }

    /**
     * Registers implementing class of the Transform algorithm with algorithmURI
     *
     * @param algorithmURI algorithmURI URI representation of 
     * <code>Transform algorithm</code> will be specified as parameter of 
     * {@link #getInstance(Document, String)}, when generate. </br>
     * @param implementingClass <code>implementingClass</code> the implementing 
     * class of {@link TransformSpi}
     * @throws AlgorithmAlreadyRegisteredException if specified algorithmURI 
     * is already registered
     */
    public static void register(String algorithmURI, String implementingClass)
        throws AlgorithmAlreadyRegisteredException {

        // are we already registered?
        Class<TransformSpi> registeredClass = getImplementingClass(algorithmURI);
        if ((registeredClass != null) ) {
            Object exArgs[] = { algorithmURI, registeredClass };
            throw new AlgorithmAlreadyRegisteredException(
               "algorithm.alreadyRegistered", exArgs);
        }

        try {
        	Class<TransformSpi> implClass = ClassLoaderUtils.loadClass(implementingClass, Transform.class);
    	    transformClassHash.put(algorithmURI, implClass);
	} catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Returns the URI representation of Transformation algorithm
     *
     * @return the URI representation of Transformation algorithm
     */
    public String getURI() {
        return getLocalAttribute(Constants._ATT_ALGORITHM);
    }

    /**
     * Transforms the input, and generates {@link XMLSignatureInput} as output.
     *
     * @param input input {@link XMLSignatureInput} which can supplied Octet 
     * Stream and NodeSet as Input of Transformation
     * @return the {@link XMLSignatureInput} class as the result of 
     * transformation
     * @throws CanonicalizationException
     * @throws IOException
     * @throws InvalidCanonicalizerException
     * @throws TransformationException
     */
    public XMLSignatureInput<N> performTransform(XMLSignatureInput<N> input)
        throws IOException, CanonicalizationException,
               InvalidCanonicalizerException, TransformationException {

        XMLSignatureInput<N> result = null;

        try {
            result = transformSpi.enginePerformTransform(input, this);
        } catch (ParserConfigurationException ex) {
            Object exArgs[] = { this.getURI(), "ParserConfigurationException" };
            throw new CanonicalizationException(
                "signature.Transform.ErrorDuringTransform", exArgs, ex);
        } catch (SAXException ex) {
            Object exArgs[] = { this.getURI(), "SAXException" };
            throw new CanonicalizationException(
                "signature.Transform.ErrorDuringTransform", exArgs, ex);
        }

        return result;
    }
   
    /**
     * Transforms the input, and generates {@link XMLSignatureInput} as output.
     *
     * @param input input {@link XMLSignatureInput} which can supplied Octect 
     * Stream and NodeSet as Input of Transformation
     * @param os where to output the result of the last transformation
     * @return the {@link XMLSignatureInput} class as the result of 
     * transformation
     * @throws CanonicalizationException
     * @throws IOException
     * @throws InvalidCanonicalizerException
     * @throws TransformationException
     */
    public XMLSignatureInput<N> performTransform(XMLSignatureInput<N> input, 
        OutputStream os) throws IOException, CanonicalizationException,
        InvalidCanonicalizerException, TransformationException {

        XMLSignatureInput<N> result = null;

        try {
       	    result = transformSpi.enginePerformTransform(input, os, this);
        } catch (ParserConfigurationException ex) {
       	    Object exArgs[] = { this.getURI(), "ParserConfigurationException" };
   	    throw new CanonicalizationException(
   	   	"signature.Transform.ErrorDuringTransform", exArgs, ex);
        } catch (SAXException ex) {
       	    Object exArgs[] = { this.getURI(), "SAXException" };
   	    throw new CanonicalizationException(
   	   	"signature.Transform.ErrorDuringTransform", exArgs, ex);
        }

        return result;
    }

    /**
     * Method getImplementingClass
     *
     * @param URI
     * @return The name of the class implementing the URI.
     */
    private static Class<TransformSpi> getImplementingClass(String URI) {
        return transformClassHash.get(URI);
    }

    private static TransformSpi getTransformSpi(String URI) 
        throws InvalidTransformException {
        try {
        	TransformSpi value = transformSpiHash.get(URI);
    	    if (value != null) {
    	    	return value;
    	    }
    	    Class<TransformSpi> cl = transformClassHash.get(URI);
    	    if (cl != null) {
    	        TransformSpi tr = cl.newInstance();
    	        transformSpiHash.put(URI, tr);
    	        return tr;
    	    } 
	} catch (InstantiationException ex) {
	    Object exArgs[] = { URI };
            throw new InvalidTransformException(
                "signature.Transform.UnknownTransform", exArgs, ex);      
	} catch (IllegalAccessException ex) {
	    Object exArgs[] = { URI };
            throw new InvalidTransformException(
                "signature.Transform.UnknownTransform", exArgs, ex);      
	}
	return null;	
    }
   
    /** @inheritDoc */
    public String getBaseLocalName() {
        return Constants._TAG_TRANSFORM;
    }
}
