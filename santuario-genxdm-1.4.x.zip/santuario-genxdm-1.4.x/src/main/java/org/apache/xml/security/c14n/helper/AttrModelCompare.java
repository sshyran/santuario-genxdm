package org.apache.xml.security.c14n.helper;

import org.genxdm.Model;

/**
 * Compare attributes based on GenXDM access directly to the underlying
 * model.
 *
 * @param <N>
 */
public class AttrModelCompare<N> extends AttrCompareBase<N> {

	public AttrModelCompare(Model<N> model) {
		super( new AttrAccessor<N>( model) );
	}
	
    public static class AttrAccessor<N> implements Accessor<N> {

	    private Model<N> m_bridge;
	    
    	public AttrAccessor(Model<N> model) {
    		m_bridge = model;
    	}
    	
		public String getLocalName(N item) {
			return m_bridge.getLocalName(item);
		}

		public String getNamespace(N item) {
			return m_bridge.getNamespaceURI(item);
		}

		public boolean isNamespace(N item) {
			return m_bridge.isNamespace(item);
		}
    	
    };
   
	private static final long serialVersionUID = 1L;

}
