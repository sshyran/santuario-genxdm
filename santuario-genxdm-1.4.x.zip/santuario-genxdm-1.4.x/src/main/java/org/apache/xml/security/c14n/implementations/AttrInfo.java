package org.apache.xml.security.c14n.implementations;

import javax.xml.XMLConstants;

import org.genxdm.Model;
import org.w3c.dom.Attr;

/**
 * In doing canonicalizaton, it is sometimes necessary to mutate the
 * value of attributes during the canonicalization process (xml:base), and
 * sometimes create attributes where none existed (xmlns=).
 * 
 * <p>This class solves both those scenarios by defining the very data needed
 * for canonicalization without resorting to an underlying mutable data model.
 * </p>
 */
public final class AttrInfo {

	private static final AttrInfo nullNsDecl = createNamespace(null, "", "");
	
	public static AttrInfo getEmptyDefaultNamespaceDecl() {
		return nullNsDecl;
	}
	
	public static <N> AttrInfo createNamespace(N attr, String nsPrefixDecl, String namespace) {
		return new AttrInfo( attr, nsPrefixDecl, namespace);
	}

	public static <N> AttrInfo createAttribute(N attr, String namespace, String localName, String prefix, String value) {
		return new AttrInfo( attr, namespace, localName, prefix, value);
	}
	
	public static <N> AttrInfo createAttribute(Model<N> model, N attr) {
		if (attr == null) {
			// this is a proxy for the empty namespace definition
			return new AttrInfo( null, "", "");
		}
		if (model.isNamespace(attr)) {
			String namespace = model.getStringValue(attr);
			String prefix = model.getLocalName(attr);
			return new AttrInfo( attr, prefix, namespace);
		}
		else {
			String namespace = model.getNamespaceURI(attr);
			String prefix = model.getPrefix(attr);
			String localName = model.getLocalName(attr);
			String value = model.getStringValue(attr);
			return new AttrInfo( attr, namespace, localName, prefix, value);
		}
	}
	
	/**
	 * 
	 * @param attr	Expect this to be <code>null</code> except when using DOM, for backwards
	 * compatibility.
	 * @param nsPrefixDecl
	 * @param namespace
	 */
	private AttrInfo(Object attr, String nsPrefixDecl, String namespace) {
		m_namespace = XMLConstants.XMLNS_ATTRIBUTE_NS_URI;
		m_wrapped = attr;
		if ("".equals(nsPrefixDecl)) {
			m_prefix = "";
			m_localName = XMLConstants.XMLNS_ATTRIBUTE;
		}
		else {
			m_prefix = XMLConstants.XMLNS_ATTRIBUTE;
			m_localName = nsPrefixDecl;
		}
		m_value = namespace;
	}
	
	private AttrInfo(Object attr, String namespace, String localName, String prefix, String value) {
		m_namespace = namespace != null ? namespace : "";
		m_prefix = prefix != null ? prefix : "";
		m_localName = localName;
		m_value = value;
		m_wrapped = attr;
	}
	
	/**
	 * For namespace declarations, always returns {@link XMLConstants#XMLNS_ATTRIBUTE_NS_URI},
	 * otherwise, returns the namespace associated with an attribute.
	 * 
	 * @return 
	 */
	public String getNamespace() {
		return m_namespace;
	}
	
	/**
	 * Get the tag name for a particular attribute.
	 * @return
	 */
	public String getTagName() {
		if ("".equals(m_prefix)) {
			return m_localName;
		}
		else {
			StringBuilder sb = new StringBuilder(m_prefix);
			sb.append(':');
			sb.append(m_localName);
			return sb.toString();
		}
	}

	public String getValue() {
		return m_value;
	}

	public void setValue(String value) {
		m_value = value;
	}
	
	public boolean isNamespace() {
		return m_namespace.equals(XMLConstants.XMLNS_ATTRIBUTE_NS_URI);
	}
	
	public String getLocalName() {
		return m_localName;
	}
	
	/**
	 * This exists to satisfy some existing test cases that need an actual
	 * wrapped Attr.
	 * 
	 * @return The attribute, if any.
	 * 
	 * @deprecated Shouldn't be used, except for testing.
	 */
	public Attr getAttr() {
		return (Attr)m_wrapped;
	}
	
	/**
	 * For testing support, returns the wrapped node.
	 * @return
	 * 
	 * @deprecated Shouldn't be used except for testing.
	 */
	public Object getWrappedNode() {
		return m_wrapped;
	}
	
	/**
	 * This is here to enable support for the deprecated APIs that the test cases
	 * use.
	 * 
	 * @deprecated
	 */
	private Object m_wrapped;
	
	private String m_namespace;
	
	private String m_prefix;
	
	private String m_localName;
	
	private String m_value;
	
}
