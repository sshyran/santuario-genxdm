package org.apache.xml.security.c14n.helper;

import java.io.Serializable;
import java.util.Comparator;

/**
 * Base comparator class that follows the C14n specification.
 * 
 * <p>This class exists because the test cases use the original AttrCompare
 * class, so the generic form of this had to fit "underneath" the existing
 * implementation</p>
 * 
 * <UL>
 * <LI>Namespace nodes have a lesser document order position than attribute 
 *   nodes.
 * <LI> An element's namespace nodes are sorted lexicographically by
 *   local name (the default namespace node, if one exists, has no
 *   local name and is therefore lexicographically least).
 * <LI> An element's attribute nodes are sorted lexicographically with
 *   namespace URI as the primary key and local name as the secondary
 *   key (an empty namespace URI is lexicographically least).
 * </UL>
 * 
 * TODO - why is this serializable?
 *
 */
public class AttrCompareBase<I> implements Comparator<I>, Serializable{

	private static final long serialVersionUID = 1L;
	
	private final static int ATTR0_BEFORE_ATTR1 = -1;
    private final static int ATTR1_BEFORE_ATTR0 = 1;

    /**
     * This uses the Accessor interface, so that we can equally well compare
     * either nodes directly, or wrappers around those nodes (when we need to
     * support the possibility of a marker "null" node.
     * 
     * <p>The additional layer of indirection is annoying, but it lets the
     * original XML Security test cases pass without modification.</p>
     *
     * @param <I>
     */
    public static interface Accessor<I> {
    	
    	boolean isNamespace(I item);
    	
    	String getNamespace(I item);
    	
    	String getLocalName(I item);
    }
    
    public AttrCompareBase(Accessor<I> accessor) {
		m_accessor = accessor;
	}
	
    /**
     * Compares two attributes based on the C14n specification.
     *
     * <UL>
     * <LI>Namespace nodes have a lesser document order position than 
     *   attribute nodes.
     * <LI> An element's namespace nodes are sorted lexicographically by
     *   local name (the default namespace node, if one exists, has no
     *   local name and is therefore lexicographically least).
     * <LI> An element's attribute nodes are sorted lexicographically with
     *   namespace URI as the primary key and local name as the secondary
     *   key (an empty namespace URI is lexicographically least).
     * </UL>
     *
     * @param obj0 casted Attr
     * @param obj1 casted Attr
     * @return returns a negative integer, zero, or a positive integer as 
     *   obj0 is less than, equal to, or greater than obj1
     *
     */
    public int compare(I attr0, I attr1) {

        boolean isNamespaceAttr0 = m_accessor.isNamespace(attr0);
        boolean isNamespaceAttr1 = m_accessor.isNamespace(attr1);

        if (isNamespaceAttr0) {
            if (isNamespaceAttr1) {
                // both are namespaces
                String localname0 = m_accessor.getLocalName(attr0);
                String localname1 = m_accessor.getLocalName(attr1);

                if (localname0.equals("xmlns")) {
                    localname0 = "";
                }

                if (localname1.equals("xmlns")) {
                    localname1 = "";
                }

                return localname0.compareTo(localname1);
            }
            // attr0 is a namespace, attr1 is not
            return ATTR0_BEFORE_ATTR1;
        } 

        if (isNamespaceAttr1) {
            // attr1 is a namespace, attr0 is not
            return ATTR1_BEFORE_ATTR0;
        } 

        String namespaceURI0 = m_accessor.getNamespace(attr0);      
        String namespaceURI1 = m_accessor.getNamespace(attr1);
      
  		String name0 = m_accessor.getLocalName(attr0);
  		String name1 = m_accessor.getLocalName(attr1);

  		// none is a namespace
        if (namespaceURI0 == null) {
      	    if (namespaceURI1 == null) {
	      		return name0.compareTo(name1);
      	    }
      	    return ATTR0_BEFORE_ATTR1;
        } 

        if (namespaceURI1 == null) {
        	return ATTR1_BEFORE_ATTR0;
        } 

        int a = namespaceURI0.compareTo(namespaceURI1);
        if (a != 0) {
      	    return a;
        }
      
        return name0.compareTo(name1);
    }
    
    private Accessor<I> m_accessor;
}
