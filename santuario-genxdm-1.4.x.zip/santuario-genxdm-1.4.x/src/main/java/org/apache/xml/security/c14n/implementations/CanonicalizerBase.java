/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.c14n.implementations;



import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.CanonicalizerSpi;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.utils.UnsyncByteArrayOutputStream;
import org.apache.xml.security.utils.XMLUtils;
import org.genxdm.NodeKind;
import org.genxdm.Model;
import org.xml.sax.SAXException;


/**
 * Abstract base class for canonicalization algorithms.
 *
 * @author Christian Geuer-Pollmann <geuerp@apache.org>
 * @version $Revision: 1094513 $
 */
public abstract class CanonicalizerBase extends CanonicalizerSpi {
   //Constants to be outputed, In char array form, so
   //less garbage is generate when outputed.
   private static final byte[] _END_PI = {'?','>'};
   private static final byte[] _BEGIN_PI = {'<','?'};
   private static final byte[] _END_COMM = {'-','-','>'};
   private static final byte[] _BEGIN_COMM = {'<','!','-','-'};
   private static final byte[] __XA_ = {'&','#','x','A',';'};
   private static final byte[] __X9_ = {'&','#','x','9',';'};
   private static final byte[] _QUOT_ = {'&','q','u','o','t',';'};
   private static final byte[] __XD_ = {'&','#','x','D',';'};
   private static final byte[] _GT_ = {'&','g','t',';'};
   private static final byte[] _LT_ = {'&','l','t',';'};
   private static final byte[] _END_TAG = {'<','/'};
   private static final byte[] _AMP_ = {'&','a','m','p',';'};

   final static String XML="xml";
   final static String XMLNS="xmlns";
   final static byte[] equalsStr= {'=','\"'};
   static final int NODE_BEFORE_DOCUMENT_ELEMENT = -1;
   static final int NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT = 0;
   static final int NODE_AFTER_DOCUMENT_ELEMENT = 1;
   
   /**
    * Whether or not a canonicalizer includes comments is determined by the constructor.
    */
   final boolean _includeComments;
   
   OutputStream _writer = new UnsyncByteArrayOutputStream();//null;

   /**
    * Constructor CanonicalizerBase
    *
    * @param includeComments
    */
   public CanonicalizerBase(boolean includeComments) {
      this._includeComments = includeComments;
   }

   /**
    * Method engineCanonicalizeSubTree
    * @inheritDoc
    * @param rootNode
    * @throws CanonicalizationException
    */
   @Override
   public <N> byte[] engineCanonicalizeSubTree(Model<N> bridge, N rootNode)
           throws CanonicalizationException {
   		return engineCanonicalizeSubTree(bridge,rootNode, (N) null, this._includeComments, null, null);
   }
   
   /**
    * Method engineCanonicalizeXPathNodeSet
    * @inheritDoc
    * @param xpathNodeSet
    * @throws CanonicalizationException
    */
   public <N> byte[] engineCanonicalizeXPathNodeSet(Model<N> bridge, Set<N> xpathNodeSet)
           throws CanonicalizationException {
	   return engineCanonicalizeXPathNodeSetInternal(bridge, XMLUtils.getOwnerDocument(bridge, xpathNodeSet),
			   this._includeComments, xpathNodeSet, null);
   }

   /**
    * Canonicalizes a Subtree node.
    * @param input the root of the subtree to canicalize
    * @return The canonicalize stream.
    * @throws CanonicalizationException
    */
    public <N> byte[] engineCanonicalize(XMLSignatureInput<N> input)
    throws CanonicalizationException {
    	
    	return engineCanonicalizeInternal(input);
   }

    /**
     * Canonicalizes a Subtree node.
     * @param input the root of the subtree to canicalize
     * @return The canonicalize stream.
     * @throws CanonicalizationException
     */
     protected <N> byte[] engineCanonicalizeInternal(XMLSignatureInput<N> input)
     throws CanonicalizationException {
     	try {
     		boolean includeComments = this._includeComments;
     		if (input.isExcludeComments())
     			includeComments = false;
 			byte[] bytes;
 			if (input.isOctetStream()) {
 				return engineCanonicalize(input.getBytes());
 			}
 			Model<N> model = input.getContext().model;
 			if (input.isElement()) {
 				bytes = engineCanonicalizeSubTree(model, input.getSubNodeN(), input
 						.getExcludeNode(), includeComments, null, null);
 				return bytes;
 			} else if (input.isNodeSet()) {
                                 
                 circumventBugIfNeeded(input);
 				
 				if (input.getSubNodeN() != null) {
 				    bytes = engineCanonicalizeXPathNodeSetInternal(model, input.getSubNodeN(),
 				    		includeComments, null, input.getNodeFilters());
 				} else {
 				    Set<N> xpathNodeSet = input.getNodeSet();
 					 bytes = engineCanonicalizeXPathNodeSetInternal(model, XMLUtils.getOwnerDocument(model, xpathNodeSet),
 							   includeComments, xpathNodeSet, null);
 				}
 				return bytes;

 			}
 			return null;
 		} catch (CanonicalizationException ex) {
 			throw new CanonicalizationException("empty", ex);
 		} catch (ParserConfigurationException ex) {
 			throw new CanonicalizationException("empty", ex);
 		} catch (IOException ex) {
 			throw new CanonicalizationException("empty", ex);
 		} catch (SAXException ex) {
 			throw new CanonicalizationException("empty", ex);
 		}
    }
    /**
    * @param _writer The _writer to set.
    */
    public void setWriter(OutputStream _writer) {
    	this._writer = _writer;
    }

    /**
	 * Canonicalizes a Subtree node.
     * @param rootNode
	 *            the root of the subtree to canicalize
     * @param excludeNode
	 *            a node to be excluded from the canicalize operation
     * @param includeComments Should comments be included in canonicalization.
     * @param xpathNodeSet Set of nodes to be included in canonicalization.
     * @param nodeFilter What filters, if any, to apply on the nodes for canonicalization.
     * 
     * @return The canonicalize stream.
	 * @throws CanonicalizationException
	 */
    <N> byte[] engineCanonicalizeSubTree(Model<N> bridge, N rootNode, N excludeNode, boolean includeComments,
    		Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter)
    throws CanonicalizationException {
        try {
         NameSpaceSymbTable<N> ns=new NameSpaceSymbTable<N>();
         int nodeLevel=NODE_BEFORE_DOCUMENT_ELEMENT;
         if (rootNode != null && NodeKind.ELEMENT == bridge.getNodeKind(rootNode)) {
         	//Fills the nssymbtable with the definitions of the parent of the root subnode
         	getParentNameSpaces(bridge, rootNode,ns);
         	nodeLevel=NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT;
         }         
         this.canonicalizeSubTree(bridge, rootNode,ns,rootNode,nodeLevel, includeComments, excludeNode, xpathNodeSet, nodeFilter);
         this._writer.close();
         if (this._writer instanceof ByteArrayOutputStream) {
            byte []result=((ByteArrayOutputStream)this._writer).toByteArray();
            if (reset) {
                ((ByteArrayOutputStream)this._writer).reset();        
            }
         	return result;
         }  else if (this._writer instanceof UnsyncByteArrayOutputStream) {
        	 byte []result=((UnsyncByteArrayOutputStream)this._writer).toByteArray();
             if (reset) {
                 ((UnsyncByteArrayOutputStream)this._writer).reset();        
             }
          	 return result;
         }
         return null;
         
      } catch (UnsupportedEncodingException ex) {
         throw new CanonicalizationException("empty", ex);
      } catch (IOException ex) {
         throw new CanonicalizationException("empty", ex);
      } 
   }
 
    /**
     * Method canonicalizeSubTree, this function is a recursive one.
     * @param currentNode
     * @param ns 
     * @param endnode 
     * @param includeComments Should comments be included in the canonicalization
     * @param excludeNode Which node should be excluded from canonicalization
     * @param xpathNodeSet Which nodes should be included, if no filters are passed.
     * @param nodeFilter How to filter the nodes.
     * @throws CanonicalizationException
     * @throws IOException
     */
     final <N> void canonicalizeSubTree(Model<N> bridge, N currentNode, NameSpaceSymbTable<N> ns,N endnode,
     		int documentLevel, boolean includeComments, N excludeNode, Set<N> xpathNodeSet,
     		List<NodeFilter<N>> nodeFilter)
     throws CanonicalizationException, IOException {
     	if (isVisibleInt(bridge, currentNode, xpathNodeSet, nodeFilter)==-1)
     		return;
     	N sibling=null;
     	N parentNode=null;    	
     	final OutputStream writer=this._writer;    
     	Map<String, byte[]> cache=new HashMap<String, byte[]>();
     	do {
     		switch (bridge.getNodeKind(currentNode)) {
     		
     		//case Node.DOCUMENT_TYPE_NODE :
     		default :
     			break;
     		
     		case ATTRIBUTE :
     			// illegal node type during traversal
     			throw new CanonicalizationException("empty");

            //case Node.DOCUMENT_FRAGMENT_NODE :
     		case DOCUMENT :
     			ns.outputNodePush();
     			sibling = bridge.getFirstChild(currentNode);
     			break;
     			
     		case COMMENT :
     			if (includeComments) {
     				outputCommentToWriter(bridge, currentNode, writer, documentLevel);
     			}
     			break;
     			
     		case PROCESSING_INSTRUCTION :
     			outputPItoWriter(bridge, currentNode, writer, documentLevel);
     			break;
     			
     		case TEXT :
     			outputTextToWriter(bridge.getStringValue(currentNode), writer);
     			break;
     			
     		case ELEMENT :
     			documentLevel=NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT;
     			if (currentNode==excludeNode) {
     				break;
     			}      
     			N currentElement = currentNode;
     			//Add a level to the nssymbtable. So latter can be pop-back.
     			ns.outputNodePush();
     			writer.write('<');
     			String name= XMLUtils.getTagName(bridge, currentElement);
     			UtfHelpper.writeByte(name,writer,cache);
     			
     			Iterable<AttrInfo> attrs = this.handleAttributesSubtree(bridge, currentElement,ns);
     			if (attrs!=null) {
     				//we output all Attrs which are available
     				for (AttrInfo attr : attrs) {
     					outputAttrToWriter( attr.getTagName(), attr.getValue(), writer, cache);
     				}
     			}
     			writer.write('>');        
     			sibling= bridge.getFirstChild(currentNode); 
     			if (sibling==null) {
     				writer.write(_END_TAG);
     				UtfHelpper.writeStringToUtf8(name,writer);        
         			writer.write('>');
         			//We fineshed with this level, pop to the previous definitions.
         			ns.outputNodePop();
 				    if (parentNode != null) {
        			    		sibling= bridge.getNextSibling(currentNode);
 				    }
     			} else {
     				parentNode=currentElement;
     			}
     			break;
     		}
     		while (sibling==null  && parentNode!=null) {    		      		      			
     			writer.write(_END_TAG);
     			UtfHelpper.writeByte(XMLUtils.getTagName(bridge, parentNode),writer,cache);        
     			writer.write('>');
     			//We fineshed with this level, pop to the previous definitions.
     			ns.outputNodePop();
     			if (parentNode==endnode)
     				return;
     			sibling=bridge.getNextSibling(parentNode);
     			parentNode=bridge.getParent(parentNode);
     			if (parentNode == null || bridge.getNodeKind(parentNode) != NodeKind.ELEMENT) {
     				documentLevel=NODE_AFTER_DOCUMENT_ELEMENT;
     				parentNode=null;
     			}    			
     		}      
     		if (sibling==null)
     			return;
     		currentNode=sibling;      
     		sibling=bridge.getNextSibling(currentNode);  
     	} while(true);
     }

     
     protected <N> byte[] engineCanonicalizeXPathNodeSetInternal(Model<N> bridge, N doc, boolean includeComments,
    		 Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter)
     throws CanonicalizationException {   

    	 try { 
    		 this.canonicalizeXPathNodeSet(bridge, doc,doc, includeComments, xpathNodeSet, nodeFilter);
    		 this._writer.close();
    		 if (this._writer instanceof ByteArrayOutputStream) {
    			 byte [] sol=((ByteArrayOutputStream)this._writer).toByteArray();
    			 if (reset) {
    				 ((ByteArrayOutputStream)this._writer).reset();
    			 }
    			 return sol;
    		 }  else if (this._writer instanceof UnsyncByteArrayOutputStream) {
    			 byte []result=((UnsyncByteArrayOutputStream)this._writer).toByteArray();
    			 if (reset) {
    				 ((UnsyncByteArrayOutputStream)this._writer).reset();        
    			 }
    			 return result;
    		 }
    		 return null;
    	 } catch (UnsupportedEncodingException ex) {
    		 throw new CanonicalizationException("empty", ex);
    	 } catch (IOException ex) {
    		 throw new CanonicalizationException("empty", ex);
    	 } 
     }

   /**
    * Canoicalizes all the nodes included in the currentNode and contained in the 
	* _xpathNodeSet field.
 * @param currentNode What's the current node to canonicalize?
 * @param endnode Which nodes should the processing stop on
 * @param includeComments Should comment nodes be included in canonicalization?
 * @param xpathNodeSet These nodes are included in results.
 * @param nodeFilter These are applied to filter the nodes to be included.
 * @throws CanonicalizationException
    * @throws IOException
    */
   final <N> void canonicalizeXPathNodeSet(Model<N> bridge, N currentNode,N endnode, boolean includeComments, Set<N> xpathNodeSet,
		   List<NodeFilter<N>> nodeFilter )
           throws CanonicalizationException, IOException {
   	if (isVisibleInt(bridge, currentNode, xpathNodeSet, nodeFilter)==-1)
		return;
	boolean currentNodeIsVisible = false;	  
	NameSpaceSymbTable<N> ns=new  NameSpaceSymbTable<N>();
	if (currentNode != null && NodeKind.ELEMENT == bridge.getNodeKind(currentNode))
		getParentNameSpaces(bridge, currentNode,ns);
  	N sibling=null;
	N parentNode=null;	
	OutputStream writer=this._writer;
	int documentLevel=NODE_BEFORE_DOCUMENT_ELEMENT;
	Map<String, byte[]> cache=new HashMap<String, byte[]>();
	do {
		switch ( bridge.getNodeKind(currentNode)) {
		
		//case Node.DOCUMENT_TYPE_NODE :
		default :
			break;
		
		//case Node.ENTITY_NODE :
		//case Node.NOTATION_NODE :
		case ATTRIBUTE:
			// illegal node type during traversal
			throw new CanonicalizationException("empty");

        //case Node.DOCUMENT_FRAGMENT_NODE :
		case DOCUMENT:
			ns.outputNodePush();
			//currentNode = currentNode.getFirstChild();  
			sibling= bridge.getFirstChild(currentNode);
			break;
			
		case COMMENT :			
			if (includeComments && (isVisibleDO(bridge, currentNode,ns.getLevel(), xpathNodeSet, nodeFilter)==1)) {
				outputCommentToWriter(bridge, currentNode, writer, documentLevel);
			}
			break;
			
		case PROCESSING_INSTRUCTION:
			if (isVisible(bridge, currentNode, xpathNodeSet, nodeFilter))
				outputPItoWriter(bridge, currentNode, writer, documentLevel);
			break;
			
		case TEXT:
		//case Node.CDATA_SECTION_NODE :
			if (isVisible(bridge, currentNode, xpathNodeSet, nodeFilter)) {
			outputTextToWriter(bridge.getStringValue(currentNode), writer);
			for (N nextSibling = bridge.getNextSibling(currentNode);
                    (nextSibling != null)
                    && (bridge.getNodeKind(nextSibling) == NodeKind.TEXT);
                    nextSibling = bridge.getNextSibling(nextSibling)) {
               outputTextToWriter(bridge.getStringValue(nextSibling), writer);
               currentNode=nextSibling;
               sibling=bridge.getNextSibling(currentNode);
            }
			
			}
			break;
			
		case ELEMENT :
			documentLevel=NODE_NOT_BEFORE_OR_AFTER_DOCUMENT_ELEMENT;
			//Add a level to the nssymbtable. So latter can be pop-back.
			String name=null;
			int i=isVisibleDO(bridge, currentNode,ns.getLevel(), xpathNodeSet, nodeFilter);
			if (i==-1) {
				sibling= bridge.getNextSibling(currentNode);
				break;
			}
			currentNodeIsVisible=(i==1);
			if (currentNodeIsVisible) {
				ns.outputNodePush();
				writer.write('<');
				name=XMLUtils.getTagName(bridge, currentNode);
				UtfHelpper.writeByte(name,writer,cache);
			} else {
				ns.push();
			}
			
			Iterable<AttrInfo > attrs = handleAttributes(bridge, currentNode,ns, xpathNodeSet, nodeFilter);
			if (attrs!=null) {
				//we output all Attrs which are available
				for (AttrInfo attr : attrs) {
					outputAttrToWriter(attr.getTagName(), attr.getValue(), writer,cache);
				}
			}
			if (currentNodeIsVisible) {
				writer.write('>');
			}
			sibling= bridge.getFirstChild(currentNode); 
		
			if (sibling==null) {
				if (currentNodeIsVisible) {
					writer.write(_END_TAG);
					UtfHelpper.writeByte(name,writer,cache);        
					writer.write('>');
					//We fineshed with this level, pop to the previous definitions.
					ns.outputNodePop();
				} else {
					ns.pop();
				}				
				if (parentNode != null) {
    					sibling= bridge.getNextSibling(currentNode);
				}
			} else {
				parentNode=currentNode;
			}			
			break;
		}
		while (sibling==null  && parentNode!=null) {    
			if (isVisible(bridge, parentNode, xpathNodeSet, nodeFilter)) {
				writer.write(_END_TAG);
				UtfHelpper.writeByte(XMLUtils.getTagName(bridge, parentNode),writer,cache);        
				writer.write('>');
				//We fineshed with this level, pop to the previous definitions.
				ns.outputNodePop();
			} else {
				ns.pop();
			}
			if (parentNode==endnode)
				return;
			sibling=bridge.getNextSibling(parentNode);
			parentNode=bridge.getParent(parentNode);   
			if (parentNode == null || NodeKind.ELEMENT != bridge.getNodeKind(parentNode)) {
				parentNode=null;
				documentLevel=NODE_AFTER_DOCUMENT_ELEMENT;
			}    			
		}      
		if (sibling==null)
			return;
		currentNode=sibling;      
		sibling=bridge.getNextSibling(currentNode);  
	} while(true);
   }
   
   <N> int isVisibleDO(Model<N> bridge, N currentNode,int level, Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter) {
	   if (nodeFilter!=null) {
	   		Iterator<NodeFilter<N>> it=nodeFilter.iterator();
	   		while (it.hasNext()) {   	
	   			int i=it.next().isNodeIncludeDO(bridge, currentNode,level);
	   			if (i!=1)
	   				return i;
	   		}
		   }
	   if ((xpathNodeSet!=null) && !xpathNodeSet.contains(currentNode))
  			return 0;
	   return 1;
   }

   <N> int isVisibleInt(Model<N> bridge, N currentNode, Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter) {
	   if (nodeFilter!=null) {
   		Iterator<NodeFilter<N> > it=nodeFilter.iterator();
   		while (it.hasNext()) {   			
   			int i=it.next().isNodeInclude(bridge, currentNode);
   			if (i!=1)
   				return i;
   		}
	   }
   		if ((xpathNodeSet!=null) && !xpathNodeSet.contains(currentNode))
   			return 0;
   		return 1;
   	}
   
   <N> boolean isVisible(Model<N> bridge, N currentNode, Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter) {
	   if (nodeFilter!=null) {
   		Iterator<NodeFilter<N> > it=nodeFilter.iterator();
   		while (it.hasNext()) {   			
   			if (it.next().isNodeInclude(bridge, currentNode)!=1)
   				return false;
   		}
	   }
   		if ((xpathNodeSet!=null) && !xpathNodeSet.contains(currentNode))
   			return false;
   		return true;
   	}

	<N> void handleParent(Model<N> bridge, N e,NameSpaceSymbTable<N> ns) {
		   if (!bridge.hasNamespaces(e) && "".equals(bridge.getNamespaceURI(e)) ) {
				return;
		   }
		   for (N nsDecl : bridge.getNamespaceAxis(e, false)) {

				String NName=bridge.getLocalName(nsDecl);
				String NValue=bridge.getStringValue(nsDecl);
				if (XML.equals(NName)
	               && XMLConstants.XML_NS_URI.equals(NValue)) {
						continue;
				}            
				ns.addMapping(bridge, NName, NValue, nsDecl);             
		   }

		   if (!"".equals(bridge.getNamespaceURI(e))) {
		       ns.addMapping(bridge, bridge.getPrefix(e), bridge.getNamespaceURI(e), null);
		   }
	   }

	/**
	 * Adds to ns the definitons from the parent elements of el
	 * @param el
	 * @param ns
   	 */
   	final <N> void getParentNameSpaces(Model<N> bridge, N el,NameSpaceSymbTable<N> ns)  {
   		List<N> parents=new ArrayList<N>(10);
   		N n1 = bridge.getParent(el);
   		if (n1 == null || bridge.getNodeKind(n1) != NodeKind.ELEMENT) {
   			return;
   		}
   		
   		//Obtain all the parents of the elemnt
   		N parent= n1;
   		while (parent!=null) {
   			parents.add(parent);
   			N n = bridge.getParent(parent);
   			if (n == null || NodeKind.ELEMENT != bridge.getNodeKind(n) ) {
   				break;
   			}
   			parent=n;
   		}
   		//Visit them in reverse order.
   		ListIterator<N> it=parents.listIterator(parents.size());
   		while (it.hasPrevious()) {
   			N ele=it.previous();
   			handleParent(bridge, ele, ns);
      	}
   		
        AttrInfo nsprefix;
        if (((nsprefix=ns.getMappingWithoutRendered(""))!=null) 
                && "".equals(nsprefix.getValue())) {
             ns.addMappingAndRenderAttr(bridge, "","", null);
        }
   	}

   	/**
    * Obtain the attributes to output for this node in XPathNodeSet c14n. 
   	 * @param ns
   	 * @param xpathNodeSet Set of attributes to be included in canonicalization.
   	 * @param nodeFilter Set of filters to apply during canonicalization.
   	 * @param N The type of node being processed.
   	 * 
   	 * @return the attributes nodes to output.
    * @throws CanonicalizationException
    */
   abstract <N> Iterable<AttrInfo> handleAttributes(Model<N> bridge, N elem, NameSpaceSymbTable<N> ns,
		  Set<N> xpathNodeSet, List<NodeFilter<N>> nodeFilter)
   throws CanonicalizationException;

   /**
    * Obtain the attributes to output for this node in a Subtree c14n.
 * @param E
 * @param ns
 * @return the attributes nodes to output.
    * @throws CanonicalizationException
    */
   abstract <N> Iterable<AttrInfo> handleAttributesSubtree(Model<N> bridge, N E, NameSpaceSymbTable<N> ns)
   throws CanonicalizationException;

   abstract <N> void circumventBugIfNeeded(XMLSignatureInput<N> input) throws CanonicalizationException, ParserConfigurationException, IOException, SAXException;
   
   /**
	    * Outputs an Attribute to the internal Writer.
	    *
	    * The string value of the node is modified by replacing
	    * <UL>
	    * <LI>all ampersands (&) with <CODE>&amp;amp;</CODE></LI>
	    * <LI>all open angle brackets (<) with <CODE>&amp;lt;</CODE></LI>
	    * <LI>all quotation mark characters with <CODE>&amp;quot;</CODE></LI>
	    * <LI>and the whitespace characters <CODE>#x9</CODE>, #xA, and #xD, with character
	    * references. The character references are written in uppercase
	    * hexadecimal with no leading zeroes (for example, <CODE>#xD</CODE> is represented
	    * by the character reference <CODE>&amp;#xD;</CODE>)</LI>
	    * </UL>
	    *
	    * @param name
	    * @param value
	    * @param writer 
	    * @throws IOException
	    */
	   static final void outputAttrToWriter(final String name, final String value, final OutputStream writer,
			   	final Map<String, byte[]> cache) throws IOException {
	      writer.write(' ');
	      UtfHelpper.writeByte(name,writer,cache);
	      writer.write(equalsStr);
	      byte  []toWrite;
	      final int length = value.length();
	      int i=0;
	      while (i < length) {        
	         char c = value.charAt(i++);
	
	         switch (c) {
	
	         case '&' :
	         	toWrite=_AMP_;
	            break;
	
	         case '<' :
	         	toWrite=_LT_;
	            break;
	
	         case '"' :
	         	toWrite=_QUOT_;
	            break;
	
	         case 0x09 :    // '\t'
	         	toWrite=__X9_;
	            break;
	
	         case 0x0A :    // '\n'
	         	toWrite=__XA_;
	            break;
	
	         case 0x0D :    // '\r'
	         	toWrite=__XD_;
	            break;
	
	         default :
	        	if (c < 0x80 ) {
	        		writer.write(c);
	        	} else {
	        		UtfHelpper.writeCharToUtf8(c,writer);
	        	};
	            continue;
	         }
	         writer.write(toWrite);
	      }
	
	      writer.write('\"');
	   }

	/**
	    * Outputs a PI to the internal Writer.
	    *
	    * @param currentPI
	    * @param writer where to write the things
	    * @throws IOException
	    */
	   static final <N>  void outputPItoWriter(Model<N> bridge, N currentPI, OutputStream writer,int position) throws IOException {   	  
	
	      if (position == NODE_AFTER_DOCUMENT_ELEMENT) {
	        writer.write('\n');
	      }
	      writer.write(_BEGIN_PI);
	
	      final String target = bridge.getLocalName(currentPI);
	      int length = target.length();
	
	      for (int i = 0; i < length; i++) {         
	      	 char c=target.charAt(i);
	         if (c==0x0D) {
	            writer.write(__XD_);
	         } else {
	        	 if (c < 0x80)  {
	         		writer.write(c);
	         	} else {
	         		UtfHelpper.writeCharToUtf8(c,writer);
	         	};           
	         }
	      }
	
	      final String data = bridge.getStringValue(currentPI);
	     
	      length = data.length();
	
	      if (length > 0) {
	         writer.write(' ');
	
	         for (int i = 0; i < length; i++) {            
	         	char c=data.charAt(i);
	            if (c==0x0D) {
	               writer.write(__XD_);
	            } else {
	            	UtfHelpper.writeCharToUtf8(c,writer);               
	            }
	         }
	      }
	
	      writer.write(_END_PI);
	      if (position == NODE_BEFORE_DOCUMENT_ELEMENT) {
	        writer.write('\n');
	     }
	   }

	   /**
	    * Method outputCommentToWriter
	    *
	    * @param currentComment
	    * @param writer writer where to write the things
	    * @throws IOException
	    */
	   static final <N> void outputCommentToWriter(Model<N> bridge, N currentComment, OutputStream writer,int position) throws IOException {   	  
	   	  if (position == NODE_AFTER_DOCUMENT_ELEMENT) {
	   		writer.write('\n');
	   	  }
	      writer.write(_BEGIN_COMM);
	
	      final String data = bridge.getStringValue(currentComment);
	      final int length = data.length();      
	
	      for (int i = 0; i < length; i++) {         
	         char c=data.charAt(i);
	         if (c==0x0D) {
	            writer.write(__XD_);
	         } else {
	        	 if (c < 0x80)  {
	         		writer.write(c);
	         	} else {
	         		UtfHelpper.writeCharToUtf8(c,writer);
	         	};               
	         }      
	      }
	
	      writer.write(_END_COMM);
	      if (position == NODE_BEFORE_DOCUMENT_ELEMENT) {
			writer.write('\n');
		 }
	   }

	   /**
	    * Outputs a Text of CDATA section to the internal Writer.
	    *
	    * @param text
	    * @param writer writer where to write the things
	    * @throws IOException
	    */
	   static final void outputTextToWriter(final String text, final OutputStream writer) throws IOException {
	      final int length = text.length();
	      byte []toWrite;
	      for (int i = 0; i < length; i++) {
	         char c = text.charAt(i);
	
	         switch (c) {
	
	         case '&' :
	         	toWrite=_AMP_;
	            break;
	
	         case '<' :
	         	toWrite=_LT_;
	            break;
	
	         case '>' :
	         	toWrite=_GT_;
	            break;
	
	         case 0xD :
	         	toWrite=__XD_;
	            break;
	
	         default :
	        	 if (c < 0x80) {
	        		 writer.write(c);
	        	 } else {
	        		 UtfHelpper.writeCharToUtf8(c,writer);
	        	 };
	            continue;
	         }
	         writer.write(toWrite);
	      }
	   }
     
}
