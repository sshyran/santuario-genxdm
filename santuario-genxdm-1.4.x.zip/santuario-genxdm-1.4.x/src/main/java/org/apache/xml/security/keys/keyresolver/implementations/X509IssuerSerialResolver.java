
/*
 * Copyright  1999-2010 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.keys.keyresolver.implementations;



import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Iterator;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.keys.content.X509Data;
import org.apache.xml.security.keys.content.x509.XMLX509IssuerSerial;
import org.apache.xml.security.keys.keyresolver.GxKeyResolverSpi;
import org.apache.xml.security.keys.keyresolver.KeyResolverException;
import org.apache.xml.security.keys.storage.StorageResolver;
import org.apache.xml.security.signature.XMLSignatureException;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.XmlContext;


/**
 *
 * @author $Author: coheigea $
 */
public class X509IssuerSerialResolver extends GxKeyResolverSpi {

   /** {@link org.apache.commons.logging} logging facility */
    static org.apache.commons.logging.Log log = 
        org.apache.commons.logging.LogFactory.getLog(
                    X509IssuerSerialResolver.class.getName());

  
   /** @inheritDoc */
   public <N> PublicKey engineLookupAndResolvePublicKey(XmlContext<N> ctx,
           N element, String BaseURI, StorageResolver storage)
              throws KeyResolverException {

      X509Certificate cert = this.engineLookupResolveX509Certificate(ctx, element,
                                BaseURI, storage);

      if (cert != null) {
         return cert.getPublicKey();
      }

      return null;
   }

   /** @inheritDoc */
   public <N> X509Certificate engineLookupResolveX509Certificate(XmlContext<N> ctx,
           N element, String BaseURI, StorageResolver storage)
              throws KeyResolverException {
	 if (log.isDebugEnabled())
	   	log.debug("Can I resolve " + ctx.model.getLocalName(element) + "?");

	  X509Data<N> x509data = null;
	  try {
	     x509data = new X509Data<N>(ctx.mutableModel, element, BaseURI);
	   } catch (XMLSignatureException ex) {
	      log.debug("I can't");
         return null;
	   } catch (XMLSecurityException ex) {
	      log.debug("I can't");
          return null;
	   }

	   if (!x509data.containsIssuerSerial()) {
	            return null;
	   }
      try {
         if (storage == null) {
            Object exArgs[] = { Constants._TAG_X509ISSUERSERIAL };
            KeyResolverException ex =
               new KeyResolverException("KeyResolver.needStorageResolver",
                                        exArgs);

            log.info("", ex);
            throw ex;
         }
         
         int noOfISS = x509data.lengthIssuerSerial();

         Iterator<Certificate> storageIterator = storage.getIterator();
         while (storageIterator.hasNext()) {
            X509Certificate cert = (X509Certificate)storageIterator.next();
            XMLX509IssuerSerial<N> certSerial = new XMLX509IssuerSerial<N>(ctx.mutableModel, ctx.mutableModel.getRoot(element), cert);

            if (log.isDebugEnabled()) {
            	log.debug("Found Certificate Issuer: "
                      + certSerial.getIssuerName());
            	log.debug("Found Certificate Serial: "
                      + certSerial.getSerialNumber().toString());
            }

            for (int i=0; i<noOfISS; i++) {
               XMLX509IssuerSerial<N> xmliss = x509data.itemIssuerSerial(i);

               if (log.isDebugEnabled()) {
               	    log.debug("Found Element Issuer:     "
                         + xmliss.getIssuerName());
               	    log.debug("Found Element Serial:     "
                         + xmliss.getSerialNumber().toString());
               }

               if (certSerial.equals(xmliss)) {
                  log.debug("match !!! ");

                  return cert;
               } 
                log.debug("no match...");               
            }
         }

         return null;
      } catch (XMLSecurityException ex) {
         log.debug("XMLSecurityException", ex);

         throw new KeyResolverException("generic.EmptyMessage", ex);
      }
   }

   /** @inheritDoc */
   public <N> javax.crypto.SecretKey engineLookupAndResolveSecretKey(XmlContext<N> ctx,
           N element, String BaseURI, StorageResolver storage) {
      return null;
   }
}
