/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.transforms.implementations;



import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.security.c14n.CanonicalizationException;
import org.apache.xml.security.c14n.InvalidCanonicalizerException;
import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.signature.NodeFilter;
import org.apache.xml.security.signature.XMLSignatureInput;
import org.apache.xml.security.transforms.Transform;
import org.apache.xml.security.transforms.TransformSpi;
import org.apache.xml.security.transforms.TransformationException;
import org.apache.xml.security.transforms.Transforms;
import org.apache.xml.security.transforms.params.XPath2FilterContainer;
import org.apache.xml.security.utils.XMLUtils;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.Model;
import org.genxdm.xpath.v10.ExprContextDynamicArgs;
import org.genxdm.xpath.v10.ExprContextStatic;
import org.genxdm.xpath.v10.ExprException;
import org.genxdm.xpath.v10.ExprParseException;
import org.genxdm.xpath.v10.NodeIterator;
import org.genxdm.xpath.v10.NodeSetExpr;
import org.genxdm.xpath.v10.XPathCompiler;
import org.genxdm.xpath.v10.XPathToolkit;
import org.w3c.dom.DOMException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Implements the <I>XML Signature XPath Filter v2.0</I>
 *
 * @author $Author: coheigea $
 * @see <A HREF="http://www.w3.org/TR/xmldsig-filter2/">XPath Filter v2.0 (TR)</A>
 * @see <a HREF="http://www.w3.org/Signature/Drafts/xmldsig-xfilter2/">XPath Filter v2.0 (editors copy)</a>
 */
public class TransformXPath2Filter extends TransformSpi {

   /** {@link org.apache.commons.logging} logging facility */
//    static org.apache.commons.logging.Log log = 
//        org.apache.commons.logging.LogFactory.getLog(
//                            TransformXPath2Filter.class.getName());

   /** Field implementedTransformURI */
   public static final String implementedTransformURI =
      Transforms.TRANSFORM_XPATH2FILTER;
   //J-
   // contains the type of the filter   

   // contains the node set
  
   /**
    * Method engineGetURI
    *
    * @inheritDoc
    */
   protected String engineGetURI() {
      return implementedTransformURI;
   }



   /**
    * Method enginePerformTransform
    * @inheritDoc
    * @param input
    *
    * @throws TransformationException
    */
   	protected <N> XMLSignatureInput<N> enginePerformTransform(XMLSignatureInput<N> input, Transform<N> _transformObject)
   		throws TransformationException {
	   
   		XmlContext<N> ctx = input.getContext();
   		XPathToolkit toolkit = XPathHelper.getXPathToolkitWithHereFunction();
   		
   		try {
   			Set<N> unionNodes=new HashSet<N>();
   			Set<N> substractNodes=new HashSet<N>();
   			Set<N> intersectNodes=new HashSet<N>();

   			List<N> xpathElements = XMLUtils.selectNodes(ctx.model,
   					ctx.model.getFirstChild(_transformObject.getElementNode()),
   					XPath2FilterContainer.XPathFilter2NS,
   					XPath2FilterContainer._TAG_XPATH2);

   			if (xpathElements.size() == 0) {
   				Object exArgs[] = { Transforms.TRANSFORM_XPATH2FILTER, "XPath" };

   				throw new TransformationException("xml.WrongContent", exArgs);
   			}

   			N inputDoc = null;
   			if (input.getSubNodeN() != null) {   
   				inputDoc = XMLUtils.getOwnerDocument(ctx.model, input.getSubNodeN());
   			} else {
   				inputDoc = XMLUtils.getOwnerDocument(ctx.model, input.getNodeSet());
   			}

   			for (N xpathElement : xpathElements) {
   				XPath2FilterContainer<N> xpathContainer =
   					XPath2FilterContainer.newInstance(ctx.mutableModel, xpathElement,
                                                   	input.getSourceURI());

   	    		XPathCompiler compiler = toolkit.newXPathCompiler();
   	    		ExprContextStatic staticArgs = toolkit.newExprContextStaticArgs();
   	    		
   	    		XPathHelper.declareNamespacesFromContextNode(ctx.model, xpathElement, staticArgs);
   	    		ExprContextDynamicArgs<N> dynArgs = toolkit.newExprContextDynamicArgs();

   	    		XPathHelper.bindHereNode(ctx.model, xpathElement, dynArgs);
   	    		
   	    		String expr = XMLUtils.getStrFromNode(ctx.model, xpathContainer.getXPathFilterTextN() );

   	    		NodeSetExpr nodeSetExpr = compiler.compileNodeSetExpr(expr, staticArgs ); 
   	    		NodeIterator<N> resultIterator = nodeSetExpr.nodeIterator(ctx.model, inputDoc, dynArgs.build());
   	    		List<N> results = XPathHelper.nodeIteratorIntoCollection(resultIterator, new ArrayList<N>() );
   	    		
//   	    		NodeList subtreeRoots = xPathFuncHereAPI.selectNodeList(inputDoc,
//                                       xpathContainer.getXPathFilterTextN(),
//                                       expr,
//                                       xpathContainer.getElementNode());
//   	    		List<N> subtreeRootsList = (List<N>) XMLUtils.nodeListToList(subtreeRoots);
//   	    		if (subtreeRootsList.size() != results.size() ) {
//   	    			throw new IllegalStateException("Expected to have a size match.");
//   	    		}
   	    		List<N> toAdd = results;
   	    		
   	    		if (xpathContainer.isIntersect()) {
   	    			intersectNodes.addAll(toAdd);
   	    		} else if (xpathContainer.isSubtract()) {
   	    			substractNodes.addAll(toAdd);
   	    		} else if (xpathContainer.isUnion()) {
   	    			unionNodes.addAll(toAdd);
   	    		} 
   			}

         
   			input.addNodeFilter(new XPath2NodeFilter<N>(unionNodes, substractNodes,intersectNodes));
   			input.setNodeSet(true);
   			return input;
//      } catch (TransformerException ex) {
//         throw new TransformationException("empty", ex);
      } catch (DOMException ex) {
         throw new TransformationException("empty", ex);
      } catch (CanonicalizationException ex) {
         throw new TransformationException("empty", ex);
      } catch (InvalidCanonicalizerException ex) {
         throw new TransformationException("empty", ex);
      } catch (XMLSecurityException ex) {
         throw new TransformationException("empty", ex);
      } catch (SAXException ex) {
         throw new TransformationException("empty", ex);
      } catch (IOException ex) {
         throw new TransformationException("empty", ex);
      } catch (ParserConfigurationException ex) {
         throw new TransformationException("empty", ex);
      } catch (ExprParseException ex) {
          throw new TransformationException("empty", ex);
      } catch (ExprException ex) {
          throw new TransformationException("empty", ex);
	} 
   }
   	
   static Set<Node> convertNodeListToSet(List<NodeList> l){
	   Set<Node> result=new HashSet<Node>();
	   for (int j=0;j<l.size();j++) {
		   NodeList rootNodes = l.get(j);	   
	       int length = rootNodes.getLength();

	       for (int i = 0; i < length; i++) {
	            Node rootNode = rootNodes.item(i);
	            result.add(rootNode);
	            
	         }
	         
	   }
	   return result;
   }
}

class XPath2NodeFilter<N> implements NodeFilter<N> {
	boolean hasUnionNodes;
	boolean hasSubstractNodes;
	boolean hasIntersectNodes;
	XPath2NodeFilter(Set<N> unionNodes, Set<N> substractNodes,
			Set<N> intersectNodes) {
		this.unionNodes=unionNodes;
		hasUnionNodes=!unionNodes.isEmpty();
		this.substractNodes=substractNodes;
		hasSubstractNodes=!substractNodes.isEmpty();
		this.intersectNodes=intersectNodes;
		hasIntersectNodes=!intersectNodes.isEmpty();
	}
	Set<N> unionNodes;
	Set<N> substractNodes;
	Set<N> intersectNodes;


   /**
    * @see org.apache.xml.security.signature.NodeFilter#isNodeInclude(org.w3c.dom.Node)
    */
   public int isNodeInclude(Model<N> bridge, N currentNode) {	 
	   int result=1;
	   
	   if (hasSubstractNodes && rooted(bridge, currentNode, substractNodes)) {
		      result = -1;
	   } else if (hasIntersectNodes && !rooted(bridge, currentNode, intersectNodes)) {
		   result = 0;
	   }
	   	   
	  //TODO OPTIMIZE
      if (result==1)     	        
    	  return 1;
      if (hasUnionNodes) { 
    	  if (rooted(bridge, currentNode, unionNodes)) {
		   return 1;
    	  }
    	  result=0;
      }    	
      return result;

   }
   int inSubstract=-1;
   int inIntersect=-1;
   int inUnion=-1;
   public int isNodeIncludeDO(Model<N> bridge, N n, int level) {
	   int result=1;
	   if (hasSubstractNodes) {
		   if ((inSubstract==-1) || (level<=inSubstract)) {
			   if (inList(n,  substractNodes)) {
				   inSubstract=level;
			   } else {
				   inSubstract=-1;   			   
			   }		   
		   } 
		   if (inSubstract!=-1){
			   result=-1;
		   }
	   } 
	   if (result!=-1){ 
		   if (hasIntersectNodes) {
		   if ((inIntersect==-1) || (level<=inIntersect)) {
			   if (!inList(n,  intersectNodes)) {
				   inIntersect=-1;
				   result=0;
			   } else {
				   inIntersect=level;   			   
			   }		   
		   }
		   }
	   }
	   	   
	  if (level<=inUnion)
		   inUnion=-1;
      if (result==1)     	        
    	  return 1;
      if (hasUnionNodes) {
    	  if ((inUnion==-1) && inList(n,  unionNodes)) {
    		  inUnion=level;
    	  }
    	  if (inUnion!=-1)
    		  return 1;
    	  result=0;
      }
		      
      return result;
   }

   /**
    * Method rooted
    * @param currentNode 
    * @param nodeList 
    *
    * @return if rooted bye the rootnodes
    */
   static <N> boolean  rooted(Model<N> bridge, N currentNode, Set<N> nodeList ) {
	   if (nodeList.contains(currentNode)) {
		   return true;
	   }
	   Iterator<N> it=nodeList.iterator();
	   while (it.hasNext()) {
	   		N rootNode = it.next();
			if (XMLUtils.isDescendantOrSelf(bridge, rootNode,currentNode)) {
				   return true;
			}
	   }
	   return false;
   }
   
      /**
       * Method rooted
       * @param currentNode 
       * @param nodeList 
       *
       * @return if rooted bye the rootnodes
       */
      static <N> boolean  inList(N currentNode, Set<N> nodeList ) {
   	      return nodeList.contains(currentNode);
      }
}
