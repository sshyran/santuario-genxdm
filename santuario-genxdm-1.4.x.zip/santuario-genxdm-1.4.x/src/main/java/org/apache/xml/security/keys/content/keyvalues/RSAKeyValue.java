/*
 * Copyright  1999-2004 The Apache Software Foundation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */
package org.apache.xml.security.keys.content.keyvalues;

import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;

import org.apache.xml.security.exceptions.XMLSecurityException;
import org.apache.xml.security.utils.Constants;
import org.apache.xml.security.utils.I18n;
import org.apache.xml.security.utils.SignatureElementProxy;
import org.apache.xml.security.utils.XmlContext;
import org.genxdm.mutable.MutableModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author $Author: mullan $
 */
public class RSAKeyValue<N> extends SignatureElementProxy<N>
        implements KeyValueContent {

   /**
    * Constructor RSAKeyValue
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    * 
    * @deprecated New clients should use {@link #RSAKeyValue(XmlContext, Object, String)}
    */
   @SuppressWarnings("unchecked")
   public RSAKeyValue(Element element, String BaseURI)
           throws XMLSecurityException {
	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) element, BaseURI);
   }

   /**
    * Constructor RSAKeyValue
    *
    * @param element
    * @param BaseURI
    * @throws XMLSecurityException
    */
   public RSAKeyValue(MutableModel<N> model, N element, String BaseURI)
           throws XMLSecurityException {
	   super(model, element, BaseURI);
   }

   /**
    * Constructor RSAKeyValue
    *
    * @param doc
    * @param modulus
    * @param exponent
    * 
    * @deprecated New clients should use {@link #RSAKeyValue(XmlContext, Object, BigInteger, BigInteger)}
    */
   @SuppressWarnings("unchecked")
   public RSAKeyValue(Document doc, BigInteger modulus, BigInteger exponent) {

	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, modulus, exponent);
   }

   /**
    * Constructor RSAKeyValue
    *
    * @param doc
    * @param modulus
    * @param exponent
    */
   public RSAKeyValue(MutableModel<N> model, N doc, BigInteger modulus, BigInteger exponent) {

      super(model, doc);

      addReturnToSelf();
      this.addBigIntegerElement(modulus, Constants._TAG_MODULUS);
      this.addBigIntegerElement(exponent, Constants._TAG_EXPONENT);
   }

   /**
    * Constructor RSAKeyValue
    *
    * @param doc
    * @param key
    * @throws IllegalArgumentException
    * 
    * @deprecated New clients should use {@link #RSAKeyValue(XmlContext, Object, Key)}
    */
   @SuppressWarnings("unchecked")
   public RSAKeyValue(Document doc, Key key) throws IllegalArgumentException {

	   this( (MutableModel<N>) XmlContext.getDomModel(), (N) doc, key);
   }

   /**
    * Constructor RSAKeyValue
    *
    * @param doc
    * @param key
    * @throws IllegalArgumentException
    */
   public RSAKeyValue(MutableModel<N> model, N doc, Key key) throws IllegalArgumentException {

	   super(model, doc);

	   addReturnToSelf();

      if (key instanceof java.security.interfaces.RSAPublicKey ) {
         this.addBigIntegerElement(((RSAPublicKey) key).getModulus(),
                                   Constants._TAG_MODULUS);
         this.addBigIntegerElement(((RSAPublicKey) key).getPublicExponent(),
                                   Constants._TAG_EXPONENT);
      } else {
         Object exArgs[] = { Constants._TAG_RSAKEYVALUE,
                             key.getClass().getName() };

         throw new IllegalArgumentException(I18n
            .translate("KeyValue.IllegalArgument", exArgs));
      }
   }

   /** @inheritDoc */
   public PublicKey getPublicKey() throws XMLSecurityException {

      try {
         KeyFactory rsaFactory = KeyFactory.getInstance("RSA");

         // KeyFactory rsaFactory = KeyFactory.getInstance(JCE_RSA);
         RSAPublicKeySpec rsaKeyspec =
            new RSAPublicKeySpec(this
               .getBigIntegerFromChildElement(Constants._TAG_MODULUS, Constants
               .SignatureSpecNS), this
                  .getBigIntegerFromChildElement(Constants
                     ._TAG_EXPONENT, Constants.SignatureSpecNS));
         PublicKey pk = rsaFactory.generatePublic(rsaKeyspec);

         return pk;
      } catch (NoSuchAlgorithmException ex) {
         throw new XMLSecurityException("empty", ex);
      } catch (InvalidKeySpecException ex) {
         throw new XMLSecurityException("empty", ex);
      }
   }

   /** @inheritDoc */
   public String getBaseLocalName() {
      return Constants._TAG_RSAKEYVALUE;
   }
}
